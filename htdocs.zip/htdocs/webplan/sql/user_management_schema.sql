-- WebPlan Database Schema với User Management
-- Tạo database và tables cho hệ thống quản lý user

-- Tạo bảng departments (phòng ban)
CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department_code VARCHAR(10) NOT NULL UNIQUE,
    department_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chèn dữ liệu departments
INSERT INTO departments (department_code, department_name, description) VALUES
('PLAN', 'Planning', 'Phòng ban lập kế hoạch sản xuất'),
('AH', 'Approval/Handle', 'Phòng ban duyệt và xử lý đơn hàng'),
('SM', 'Sewing Management', 'Phòng ban quản lý may'),
('CMD', 'Complete Management', 'Phòng ban quản lý hoàn thành'),
('SAMPLE', 'Sample Development', 'Phòng ban phát triển mẫu');

-- Tạo bảng users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    department_id INT,
    role ENUM('admin', 'manager', 'user') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- Tạo bảng user_activity_logs (log hoạt động user)
CREATE TABLE IF NOT EXISTS user_activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    details TEXT,
    user_ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Cập nhật bảng activity_logs để liên kết với user
ALTER TABLE activity_logs ADD COLUMN user_id INT AFTER order_id;
ALTER TABLE activity_logs ADD FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;

-- Cập nhật bảng orders để theo dõi user thực hiện thay đổi
ALTER TABLE orders 
ADD COLUMN created_by INT AFTER display_order,
ADD COLUMN updated_by INT AFTER created_by,
ADD FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
ADD FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

-- Thêm user admin mặc định
INSERT INTO users (username, password_hash, full_name, email, department_id, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@sps.com', 1, 'admin');
-- Password mặc định: "password"

-- Thêm một số user mẫu
INSERT INTO users (username, password_hash, full_name, email, department_id, role) VALUES
('plan_manager', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Planning Manager', 'plan@sps.com', 1, 'manager'),
('ah_manager', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'AH Manager', 'ah@sps.com', 2, 'manager'),
('sm_manager', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'SM Manager', 'sm@sps.com', 3, 'manager'),
('cmd_manager', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CMD Manager', 'cmd@sps.com', 4, 'manager'),
('plan_user', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Planning User', 'plan_user@sps.com', 1, 'user'),
('ah_user', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'AH User', 'ah_user@sps.com', 2, 'user');

-- Tạo index để tối ưu performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_department ON users(department_id);
CREATE INDEX idx_user_activity_user ON user_activity_logs(user_id);
CREATE INDEX idx_user_activity_action ON user_activity_logs(action);
CREATE INDEX idx_orders_created_by ON orders(created_by);
CREATE INDEX idx_orders_updated_by ON orders(updated_by);
