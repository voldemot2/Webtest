-- Tạo database
CREATE DATABASE IF NOT EXISTS webplan_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tạo user (chạy với quyền root)
CREATE USER IF NOT EXISTS 'webplan_user'@'localhost' IDENTIFIED BY 'Kukumalu@113';
GRANT ALL PRIVILEGES ON webplan_db.* TO 'webplan_user'@'localhost';
FLUSH PRIVILEGES;

-- Sử dụng database
USE webplan_db;

-- Tạo bảng orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_short_name VARCHAR(100) NOT NULL,
    go_no VARCHAR(50) NOT NULL,
    style_no VARCHAR(100) NOT NULL,
    jo_no VARCHAR(50) NOT NULL,
    color_code VARCHAR(20) NOT NULL,
    product_category VARCHAR(50) NOT NULL,
    wash_type VARCHAR(50) NOT NULL,
    plan_qty INT NOT NULL DEFAULT 0,
    target_output INT NOT NULL DEFAULT 0,
    delivery_date DATE NULL,
    marker_date DATE NULL,
    cut_start_date DATE NULL,
    sewing_start_date DATE NULL,
    sample_type VARCHAR(20) NULL,
    ah_date DATE NULL,
    sm_date DATE NULL,
    remark TEXT NULL,
    order_status VARCHAR(20) NOT NULL DEFAULT 'New',
    display_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tạo index cho các trường thường xuyên tìm kiếm
CREATE INDEX idx_orders_status ON orders(order_status);
CREATE INDEX idx_orders_customer ON orders(customer_short_name);
CREATE INDEX idx_orders_go_no ON orders(go_no);
CREATE INDEX idx_orders_display_order ON orders(display_order);

-- Tạo bảng ah_data (cho tab AH)
CREATE TABLE IF NOT EXISTS ah_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    ah_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    ah_notes TEXT NULL,
    ah_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng sm_data (cho tab SM)
CREATE TABLE IF NOT EXISTS sm_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    sm_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    sm_notes TEXT NULL,
    sm_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng cmd_data (cho tab CMD)
CREATE TABLE IF NOT EXISTS cmd_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    cmd_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    cmd_notes TEXT NULL,
    cmd_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng sample_data (cho tab SAMPLE)
CREATE TABLE IF NOT EXISTS sample_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    sample_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    sample_notes TEXT NULL,
    sample_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng logs để theo dõi các thay đổi
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NULL,
    action VARCHAR(50) NOT NULL,
    old_value TEXT NULL,
    new_value TEXT NULL,
    user_ip VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
);
