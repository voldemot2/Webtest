-- Script SQL cho XAMPP localhost
-- Tạo database
CREATE DATABASE IF NOT EXISTS webplan_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Sử dụng database
USE webplan_db;

-- Tạo bảng departments (phòng ban)
CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department_code VARCHAR(10) NOT NULL UNIQUE,
    department_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chèn dữ liệu departments
INSERT INTO departments (department_code, department_name, description) VALUES
('PLAN', 'Planning', 'Phòng ban lập kế hoạch sản xuất'),
('AH', 'Account holder', 'Phòng ban xử lý đơn hàng'),
('SM', 'Sub material', 'Phòng ban quản lý Phụ liệu'),
('CMD', 'Computer maker', 'Phòng ban vẽ mẫu'),
('SAMPLE', 'Sample Development', 'Phòng ban phát triển mẫu');

-- Tạo bảng users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    department_id INT,
    role ENUM('admin', 'manager', 'user') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- Tạo user admin mặc định (password: admin123)
INSERT INTO users (username, password_hash, full_name, email, department_id, role) VALUES
('admin', '$2y$10$YourHashedPasswordHere', 'Administrator', 'admin@company.com', 1, 'admin');

-- Tạo bảng orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_short_name VARCHAR(100) NOT NULL,
    go_no VARCHAR(50) NOT NULL,
    style_no VARCHAR(100) NOT NULL,
    jo_no VARCHAR(50) NOT NULL,
    color_code VARCHAR(20) NOT NULL,
    product_category VARCHAR(50) NOT NULL,
    wash_type VARCHAR(50) NOT NULL,
    plan_qty INT NOT NULL DEFAULT 0,
    target_output INT NOT NULL DEFAULT 0,
    delivery_date DATE NULL,
    marker_date DATE NULL,
    cut_start_date DATE NULL,
    sewing_start_date DATE NULL,
    sample_type VARCHAR(20) NULL,
    ah_date DATE NULL,
    sm_date DATE NULL,
    remark TEXT NULL,
    order_status VARCHAR(20) NOT NULL DEFAULT 'New',
    display_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tạo index cho các trường thường xuyên tìm kiếm
CREATE INDEX idx_orders_status ON orders(order_status);
CREATE INDEX idx_orders_customer ON orders(customer_short_name);
CREATE INDEX idx_orders_go_no ON orders(go_no);
CREATE INDEX idx_orders_display_order ON orders(display_order);

-- Tạo bảng ah_data (cho tab AH)
CREATE TABLE IF NOT EXISTS ah_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    ah_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    ah_notes TEXT NULL,
    ah_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng sm_data (cho tab SM)
CREATE TABLE IF NOT EXISTS sm_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    sm_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    sm_notes TEXT NULL,
    sm_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng cmd_data (cho tab CMD)
CREATE TABLE IF NOT EXISTS cmd_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    cmd_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    cmd_notes TEXT NULL,
    cmd_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng sample_data (cho tab SAMPLE)
CREATE TABLE IF NOT EXISTS sample_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    sample_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    sample_notes TEXT NULL,
    sample_completed_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Tạo bảng user_activity_logs (log hoạt động user)
CREATE TABLE IF NOT EXISTS user_activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    details TEXT,
    user_ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tạo bảng logs để theo dõi các thay đổi
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NULL,
    user_id INT NULL,
    action VARCHAR(50) NOT NULL,
    old_value TEXT NULL,
    new_value TEXT NULL,
    user_ip VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Chèn một số dữ liệu mẫu để test
INSERT INTO orders (customer_short_name, go_no, style_no, jo_no, color_code, product_category, wash_type, plan_qty, target_output, delivery_date) VALUES
('ACME', 'GO001', 'ST001', 'JO001', 'BLU', 'Jeans', 'Stone Wash', 1000, 800, '2025-08-15'),
('BETA', 'GO002', 'ST002', 'JO002', 'BLK', 'Shirt', 'Normal', 500, 450, '2025-08-20'),
('GAMMA', 'GO003', 'ST003', 'JO003', 'WHT', 'T-Shirt', 'Soft Wash', 2000, 1800, '2025-08-25');
