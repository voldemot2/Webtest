<?php
// Chỉ start session nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra đăng nhập
function checkLogin() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_data'])) {
        header('Location: login.php');
        exit();
    }
    return $_SESSION['user_data'];
}

// Kiểm tra user đã đăng nhập chưa (không redirect)
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_data']);
}

// Kiểm tra quyền truy cập
function checkPermission($permission) {
    if (!isset($_SESSION['user_data']) || !isset($_SESSION['user_id'])) {
        return false;
    }
    
    try {
        require_once 'models/UserModel.php';
        $userModel = new UserModel();
        return $userModel->hasPermission($_SESSION['user_id'], $permission);
    } catch (Exception $e) {
        error_log("Permission check error: " . $e->getMessage());
        return false;
    }
}

// Đăng xuất
function logout() {
    // Xóa tất cả dữ liệu session
    $_SESSION = array();
    
    // Xóa session cookie nếu có
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Hủy session
    session_destroy();
}

// Lấy thông tin user hiện tại
function getCurrentUser() {
    return isset($_SESSION['user_data']) ? $_SESSION['user_data'] : null;
}

// Ghi log hoạt động user
function logUserActivity($action, $details = null) {
    if (!isset($_SESSION['user_id'])) return false;
    
    try {
        require_once 'models/UserModel.php';
        $userModel = new UserModel();
        return $userModel->logUserActivity($_SESSION['user_id'], $action, $details);
    } catch (Exception $e) {
        error_log("User activity log error: " . $e->getMessage());
        return false;
    }
}

// Kiểm tra role admin
function isAdmin() {
    $user = getCurrentUser();
    return $user && $user['role'] === 'admin';
}

// Kiểm tra role manager
function isManager() {
    $user = getCurrentUser();
    return $user && in_array($user['role'], ['admin', 'manager']);
}

// Lấy department code của user hiện tại
function getUserDepartment() {
    $user = getCurrentUser();
    return $user ? $user['department_code'] : null;
}

// Kiểm tra user thuộc department cụ thể
function isUserInDepartment($department_code) {
    return getUserDepartment() === $department_code;
}
?>
