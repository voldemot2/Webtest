<?php
require_once __DIR__ . '/../config/database.php';

class OrderModel {
    private $conn;
    private $table_name = "orders";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Getter method để truy cập database connection
    public function getConnection() {
        return $this->conn;
    }

    // Lấy tất cả orders
    public function getAllOrders() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY display_order ASC, id ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lấy order theo ID
    public function getOrderById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Tạo order mới
    public function createOrder($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (customer_short_name, go_no, style_no, jo_no, color_code, product_category, 
                   wash_type, plan_qty, target_output, delivery_date, marker_date, 
                   cut_start_date, sewing_start_date, sample_type, ah_date, sm_date, 
                   remark, order_status, display_order) 
                  VALUES 
                  (:customer_short_name, :go_no, :style_no, :jo_no, :color_code, :product_category, 
                   :wash_type, :plan_qty, :target_output, :delivery_date, :marker_date, 
                   :cut_start_date, :sewing_start_date, :sample_type, :ah_date, :sm_date, 
                   :remark, :order_status, :display_order)";
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        $stmt->bindParam(':customer_short_name', $data['customer_short_name']);
        $stmt->bindParam(':go_no', $data['go_no']);
        $stmt->bindParam(':style_no', $data['style_no']);
        $stmt->bindParam(':jo_no', $data['jo_no']);
        $stmt->bindParam(':color_code', $data['color_code']);
        $stmt->bindParam(':product_category', $data['product_category']);
        $stmt->bindParam(':wash_type', $data['wash_type']);
        $stmt->bindParam(':plan_qty', $data['plan_qty']);
        $stmt->bindParam(':target_output', $data['target_output']);
        $stmt->bindParam(':delivery_date', $data['delivery_date']);
        $stmt->bindParam(':marker_date', $data['marker_date']);
        $stmt->bindParam(':cut_start_date', $data['cut_start_date']);
        $stmt->bindParam(':sewing_start_date', $data['sewing_start_date']);
        $stmt->bindParam(':sample_type', $data['sample_type']);
        $stmt->bindParam(':ah_date', $data['ah_date']);
        $stmt->bindParam(':sm_date', $data['sm_date']);
        $stmt->bindParam(':remark', $data['remark']);
        $stmt->bindParam(':order_status', $data['order_status']);
        $stmt->bindParam(':display_order', $data['display_order']);
        
        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    // Cập nhật order
    public function updateOrder($id, $data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  customer_short_name = :customer_short_name,
                  go_no = :go_no,
                  style_no = :style_no,
                  jo_no = :jo_no,
                  color_code = :color_code,
                  product_category = :product_category,
                  wash_type = :wash_type,
                  plan_qty = :plan_qty,
                  target_output = :target_output,
                  delivery_date = :delivery_date,
                  marker_date = :marker_date,
                  cut_start_date = :cut_start_date,
                  sewing_start_date = :sewing_start_date,
                  sample_type = :sample_type,
                  ah_date = :ah_date,
                  sm_date = :sm_date,
                  remark = :remark,
                  order_status = :order_status,
                  display_order = :display_order
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':customer_short_name', $data['customer_short_name']);
        $stmt->bindParam(':go_no', $data['go_no']);
        $stmt->bindParam(':style_no', $data['style_no']);
        $stmt->bindParam(':jo_no', $data['jo_no']);
        $stmt->bindParam(':color_code', $data['color_code']);
        $stmt->bindParam(':product_category', $data['product_category']);
        $stmt->bindParam(':wash_type', $data['wash_type']);
        $stmt->bindParam(':plan_qty', $data['plan_qty']);
        $stmt->bindParam(':target_output', $data['target_output']);
        $stmt->bindParam(':delivery_date', $data['delivery_date']);
        $stmt->bindParam(':marker_date', $data['marker_date']);
        $stmt->bindParam(':cut_start_date', $data['cut_start_date']);
        $stmt->bindParam(':sewing_start_date', $data['sewing_start_date']);
        $stmt->bindParam(':sample_type', $data['sample_type']);
        $stmt->bindParam(':ah_date', $data['ah_date']);
        $stmt->bindParam(':sm_date', $data['sm_date']);
        $stmt->bindParam(':remark', $data['remark']);
        $stmt->bindParam(':order_status', $data['order_status']);
        $stmt->bindParam(':display_order', $data['display_order']);
        
        return $stmt->execute();
    }

    // Cập nhật một trường cụ thể
    public function updateOrderField($id, $field, $value) {
        $allowed_fields = ['customer_short_name', 'go_no', 'style_no', 'jo_no', 'color_code', 
                          'product_category', 'wash_type', 'plan_qty', 'target_output', 
                          'delivery_date', 'marker_date', 'cut_start_date', 'sewing_start_date', 
                          'sample_type', 'ah_date', 'sm_date', 'remark', 'order_status', 'display_order'];
        
        if (!in_array($field, $allowed_fields)) {
            return false;
        }
        
        $query = "UPDATE " . $this->table_name . " SET " . $field . " = :value WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':value', $value);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    // Cập nhật nhiều trường
    public function updateOrderFields($id, $fields) {
        $allowed_fields = ['customer_short_name', 'go_no', 'style_no', 'jo_no', 'color_code', 
                          'product_category', 'wash_type', 'plan_qty', 'target_output', 
                          'delivery_date', 'marker_date', 'cut_start_date', 'sewing_start_date', 
                          'sample_type', 'ah_date', 'sm_date', 'remark', 'order_status', 'display_order'];
        
        $set_clauses = [];
        $params = [':id' => $id];
        
        foreach ($fields as $field => $value) {
            if (in_array($field, $allowed_fields)) {
                $set_clauses[] = $field . " = :" . $field;
                $params[':' . $field] = $value;
            }
        }
        
        if (empty($set_clauses)) {
            return false;
        }
        
        $query = "UPDATE " . $this->table_name . " SET " . implode(', ', $set_clauses) . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        
        return $stmt->execute($params);
    }

    // Cập nhật thứ tự hiển thị
    public function updateOrderSequence($order_ids) {
        $this->conn->beginTransaction();
        
        try {
            foreach ($order_ids as $index => $order_id) {
                $query = "UPDATE " . $this->table_name . " SET display_order = :display_order WHERE id = :id";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':display_order', $index);
                $stmt->bindParam(':id', $order_id);
                $stmt->execute();
            }
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }

    // Xóa order
    public function deleteOrder($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Tìm kiếm orders
    public function searchOrders($search_term) {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE customer_short_name LIKE :search 
                  OR go_no LIKE :search 
                  OR style_no LIKE :search 
                  OR jo_no LIKE :search 
                  OR color_code LIKE :search
                  ORDER BY display_order ASC, id ASC";
        
        $stmt = $this->conn->prepare($query);
        $search_param = '%' . $search_term . '%';
        $stmt->bindParam(':search', $search_param);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Ghi log hoạt động
    public function logActivity($order_id, $action, $old_value = null, $new_value = null) {
        $query = "INSERT INTO activity_logs (order_id, action, old_value, new_value, user_ip) 
                  VALUES (:order_id, :action, :old_value, :new_value, :user_ip)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':old_value', $old_value);
        $stmt->bindParam(':new_value', $new_value);
        $stmt->bindParam(':user_ip', $_SERVER['REMOTE_ADDR']);
        
        return $stmt->execute();
    }

    // Ghi log hoạt động với user_id
    public function logActivityWithUser($order_id, $action, $old_value = null, $new_value = null, $user_id = null) {
        $query = "INSERT INTO activity_logs (order_id, user_id, action, old_value, new_value, user_ip) 
                  VALUES (:order_id, :user_id, :action, :old_value, :new_value, :user_ip)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':old_value', $old_value);
        $stmt->bindParam(':new_value', $new_value);
        $stmt->bindParam(':user_ip', $_SERVER['REMOTE_ADDR']);
        
        return $stmt->execute();
    }
}
?>
