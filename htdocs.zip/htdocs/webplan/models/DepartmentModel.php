<?php
require_once __DIR__ . '/../config/database.php';

class DepartmentModel {
    private $conn;
    private $table_name = "departments";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Lấy tất cả departments
    public function getAllDepartments() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY id ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lấy department theo ID
    public function getDepartmentById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Lấy department theo code
    public function getDepartmentByCode($code) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE department_code = :code";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':code', $code);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Tạo department mới
    public function createDepartment($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (department_code, department_name, description) 
                  VALUES 
                  (:department_code, :department_name, :description)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':department_code', $data['department_code']);
        $stmt->bindParam(':department_name', $data['department_name']);
        $stmt->bindParam(':description', $data['description']);
        
        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    // Cập nhật department
    public function updateDepartment($id, $data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  department_code = :department_code,
                  department_name = :department_name,
                  description = :description
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':department_code', $data['department_code']);
        $stmt->bindParam(':department_name', $data['department_name']);
        $stmt->bindParam(':description', $data['description']);
        
        return $stmt->execute();
    }

    // Xóa department
    public function deleteDepartment($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Thống kê số user trong mỗi department
    public function getDepartmentStats() {
        $query = "SELECT d.*, COUNT(u.id) as user_count 
                  FROM " . $this->table_name . " d 
                  LEFT JOIN users u ON d.id = u.department_id AND u.status = 'active'
                  GROUP BY d.id 
                  ORDER BY d.id ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
