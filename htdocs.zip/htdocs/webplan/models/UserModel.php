<?php
require_once __DIR__ . '/../config/database.php';

class UserModel {
    private $conn;
    private $table_name = "users";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Lấy tất cả users
    public function getAllUsers() {
        $query = "SELECT u.*, d.department_name, d.department_code 
                  FROM " . $this->table_name . " u 
                  LEFT JOIN departments d ON u.department_id = d.id 
                  ORDER BY u.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lấy user theo ID
    public function getUserById($id) {
        $query = "SELECT u.*, d.department_name, d.department_code 
                  FROM " . $this->table_name . " u 
                  LEFT JOIN departments d ON u.department_id = d.id 
                  WHERE u.id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Lấy user theo username
    public function getUserByUsername($username) {
        $query = "SELECT u.*, d.department_name, d.department_code 
                  FROM " . $this->table_name . " u 
                  LEFT JOIN departments d ON u.department_id = d.id 
                  WHERE u.username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Tạo user mới
    public function createUser($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (username, password_hash, full_name, email, department_id, role, status) 
                  VALUES 
                  (:username, :password_hash, :full_name, :email, :department_id, :role, :status)";
        
        $stmt = $this->conn->prepare($query);
        
        // Hash password
        $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
        
        $stmt->bindParam(':username', $data['username']);
        $stmt->bindParam(':password_hash', $password_hash);
        $stmt->bindParam(':full_name', $data['full_name']);
        $stmt->bindParam(':email', $data['email']);
        $stmt->bindParam(':department_id', $data['department_id']);
        $stmt->bindParam(':role', $data['role']);
        $stmt->bindParam(':status', $data['status']);
        
        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    // Cập nhật user
    public function updateUser($id, $data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  username = :username,
                  full_name = :full_name,
                  email = :email,
                  department_id = :department_id,
                  role = :role,
                  status = :status,
                  updated_at = CURRENT_TIMESTAMP
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':username', $data['username']);
        $stmt->bindParam(':full_name', $data['full_name']);
        $stmt->bindParam(':email', $data['email']);
        $stmt->bindParam(':department_id', $data['department_id']);
        $stmt->bindParam(':role', $data['role']);
        $stmt->bindParam(':status', $data['status']);
        
        return $stmt->execute();
    }

    // Cập nhật password
    public function updatePassword($id, $new_password) {
        $query = "UPDATE " . $this->table_name . " SET 
                  password_hash = :password_hash,
                  updated_at = CURRENT_TIMESTAMP
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':password_hash', $password_hash);
        
        return $stmt->execute();
    }

    // Xác thực đăng nhập
    public function authenticate($username, $password) {
        $user = $this->getUserByUsername($username);
        
        if ($user && $user['status'] === 'active' && password_verify($password, $user['password_hash'])) {
            // Cập nhật last_login
            $this->updateLastLogin($user['id']);
            return $user;
        }
        
        return false;
    }

    // Cập nhật last login
    public function updateLastLogin($user_id) {
        $query = "UPDATE " . $this->table_name . " SET 
                  last_login = CURRENT_TIMESTAMP 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $user_id);
        return $stmt->execute();
    }

    // Xóa user
    public function deleteUser($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Lấy users theo department
    public function getUsersByDepartment($department_id) {
        $query = "SELECT u.*, d.department_name, d.department_code 
                  FROM " . $this->table_name . " u 
                  LEFT JOIN departments d ON u.department_id = d.id 
                  WHERE u.department_id = :department_id AND u.status = 'active'
                  ORDER BY u.full_name ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':department_id', $department_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Kiểm tra quyền truy cập
    public function hasPermission($user_id, $permission) {
        $user = $this->getUserById($user_id);
        if (!$user || !isset($user['role'])) return false;

        // Admin có toàn quyền
        if ($user['role'] === 'admin') return true;

        // Kiểm tra department_id có hợp lệ
        $department_id = isset($user['department_id']) ? (int)$user['department_id'] : 0;
        if ($department_id <= 0) return false;

        // Manager có quyền đọc/ghi trong phòng ban
        if ($user['role'] === 'manager') {
            $dept_permissions = [
                1 => ['planning_read', 'planning_write'], // Planning Department
                2 => ['ah_read', 'ah_write'], // AH Department
                3 => ['sm_read', 'sm_write'], // SM Department
                4 => ['cmd_read', 'cmd_write'], // CMD Department
                5 => ['sample_read', 'sample_write'] // Sample Department
            ];
            
            if (isset($dept_permissions[$department_id])) {
                return in_array($permission, $dept_permissions[$department_id]);
            }
        }

        // User chỉ có quyền đọc trong phòng ban
        if ($user['role'] === 'user') {
            $dept_permissions = [
                1 => ['planning_read'], // Planning Department
                2 => ['ah_read'], // AH Department
                3 => ['sm_read'], // SM Department
                4 => ['cmd_read'], // CMD Department
                5 => ['sample_read'] // Sample Department
            ];
            
            if (isset($dept_permissions[$department_id])) {
                return in_array($permission, $dept_permissions[$department_id]);
            }
        }

        return false;
    }

    // Ghi log hoạt động user
    public function logUserActivity($user_id, $action, $details = null) {
        $query = "INSERT INTO user_activity_logs (user_id, action, details, user_ip) 
                  VALUES (:user_id, :action, :details, :user_ip)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':details', $details);
        $stmt->bindParam(':user_ip', $_SERVER['REMOTE_ADDR']);
        
        return $stmt->execute();
    }
}
?>
