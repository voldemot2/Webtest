<?php
// setup_database.php
// Script để setup database với user management

require_once 'config/database.php';

echo "<h2>🛠️ WebPlan Database Setup with User Management</h2>\n";
echo "<div style='font-family: monospace; background: #f5f5f5; padding: 20px; border-radius: 8px;'>\n";

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    echo "✅ Database connection successful!<br>\n";
    
    // Đọc và thực thi SQL file
    $sqlFile = 'sql/user_management_schema.sql';
    
    if (!file_exists($sqlFile)) {
        throw new Exception("SQL file not found: $sqlFile");
    }
    
    $sql = file_get_contents($sqlFile);
    $statements = explode(';', $sql);
    
    $successCount = 0;
    $totalCount = 0;
    
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if (empty($statement)) continue;
        
        $totalCount++;
        try {
            $conn->exec($statement);
            $successCount++;
            
            // Hiển thị thông tin ngắn gọn
            if (stripos($statement, 'CREATE TABLE') !== false) {
                preg_match('/CREATE TABLE[^`]*`?([^`\s]+)`?\s*\(/i', $statement, $matches);
                $tableName = $matches[1] ?? 'Unknown';
                echo "📋 Created table: <strong>$tableName</strong><br>\n";
            } elseif (stripos($statement, 'INSERT INTO') !== false) {
                preg_match('/INSERT INTO[^`]*`?([^`\s]+)`?\s*/i', $statement, $matches);
                $tableName = $matches[1] ?? 'Unknown';
                echo "📝 Inserted data into: <strong>$tableName</strong><br>\n";
            } elseif (stripos($statement, 'ALTER TABLE') !== false) {
                preg_match('/ALTER TABLE[^`]*`?([^`\s]+)`?\s*/i', $statement, $matches);
                $tableName = $matches[1] ?? 'Unknown';
                echo "🔧 Altered table: <strong>$tableName</strong><br>\n";
            } elseif (stripos($statement, 'CREATE INDEX') !== false) {
                preg_match('/CREATE INDEX[^`]*`?([^`\s]+)`?\s*/i', $statement, $matches);
                $indexName = $matches[1] ?? 'Unknown';
                echo "🗂️ Created index: <strong>$indexName</strong><br>\n";
            }
            
        } catch (PDOException $e) {
            echo "❌ Error executing statement: " . substr($statement, 0, 50) . "...<br>\n";
            echo "   Error: " . $e->getMessage() . "<br>\n";
        }
    }
    
    echo "<br>📊 <strong>Summary:</strong><br>\n";
    echo "   • Total statements: $totalCount<br>\n";
    echo "   • Successful: $successCount<br>\n";
    echo "   • Failed: " . ($totalCount - $successCount) . "<br>\n";
    
    // Kiểm tra các bảng đã được tạo
    echo "<br>🔍 <strong>Verifying tables:</strong><br>\n";
    $tables = ['departments', 'users', 'user_activity_logs', 'orders', 'activity_logs'];
    
    foreach ($tables as $table) {
        try {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM $table");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "   ✅ Table <strong>$table</strong>: {$result['count']} records<br>\n";
        } catch (PDOException $e) {
            echo "   ❌ Table <strong>$table</strong>: Not found or error<br>\n";
        }
    }
    
    // Hiển thị thông tin user mặc định
    echo "<br>👥 <strong>Default Users Created:</strong><br>\n";
    try {
        $stmt = $conn->query("SELECT u.username, u.full_name, u.role, d.department_name 
                              FROM users u 
                              LEFT JOIN departments d ON u.department_id = d.id 
                              ORDER BY u.id");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($users as $user) {
            $roleColor = [
                'admin' => '#dc2626',
                'manager' => '#2563eb', 
                'user' => '#16a34a'
            ];
            $color = $roleColor[$user['role']] ?? '#6b7280';
            
            echo "   👤 <strong style='color: $color'>{$user['username']}</strong> - {$user['full_name']} ({$user['role']}) - {$user['department_name']}<br>\n";
        }
        
        echo "<br>🔑 <strong>Login Info:</strong><br>\n";
        echo "   • All users have password: <strong>password</strong><br>\n";
        echo "   • You can login with any username above<br>\n";
        
    } catch (PDOException $e) {
        echo "   ❌ Error fetching users: " . $e->getMessage() . "<br>\n";
    }
    
    echo "<br>🎉 <strong>Setup completed successfully!</strong><br>\n";
    echo "<br>📱 <strong>Next Steps:</strong><br>\n";
    echo "   1. Go to <a href='login.php'>login.php</a> to login<br>\n";
    echo "   2. Use admin/password to access admin panel<br>\n";
    echo "   3. Test different user roles and permissions<br>\n";
    echo "   4. Check <a href='admin.php'>admin.php</a> for user management<br>\n";
    
} catch (Exception $e) {
    echo "❌ <strong>Error:</strong> " . $e->getMessage() . "<br>\n";
    echo "Please check your database configuration and try again.<br>\n";
}

echo "</div>\n";
echo "<style>body { font-family: Arial, sans-serif; margin: 40px; background: #f0f4f8; }</style>\n";
?>
