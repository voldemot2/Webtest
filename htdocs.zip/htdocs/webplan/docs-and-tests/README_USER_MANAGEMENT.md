# 🚀 WebPlan V19 - Production Management System với User Management

## 📋 Tổng quan

WebPlan V19 là hệ thống quản lý sản xuất được nâng cấp với **hệ thống quản lý user và phân quyền theo phòng ban**. Hệ thống hỗ trợ 5 phòng ban chính: Planning, AH, SM, CMD, và Sample với quy trình workflow hoàn chỉnh từ tạo đơn hàng đến hoàn thành sản xuất.

## ✨ Tính năng mới

### 🔐 User Management System
- **Multi-user authentication** với session management
- **Role-based access control**: Admin, Manager, User
- **Department-based permissions**: Mỗi user thuộc một phòng ban cụ thể
- **Activity logging**: Theo dõi tất cả hoạt động của user
- **Security features**: Password hashing, session protection

### 👥 Phân quyền theo phòng ban

| Department | Code | Permissions | Chức năng |
|-----------|------|-------------|-----------|
| Planning | PLAN | planning_read, planning_write | Lập kế hoạch sản xuất, quản lý timeline |
| AH (Approval/Handle) | AH | ah_read, ah_write | Tạo và xử lý đơn hàng, duyệt đơn |
| SM (Sewing Management) | SM | sm_read, sm_write | Quản lý quy trình may |
| CMD (Complete Management) | CMD | cmd_read, cmd_write | Hoàn thành sản xuất, đánh dấu "Marked" |
| Sample Development | SAMPLE | sample_read, sample_write | Kiểm tra chất lượng, chuyển trạng thái "Check/Complete" |

### 🎭 Roles và quyền hạn

| Role | Quyền hạn | Mô tả |
|------|-----------|-------|
| **Admin** | Toàn quyền | Quản lý toàn hệ thống, user management |
| **Manager** | Read + Write trong phòng ban | Quản lý công việc trong phòng ban |
| **User** | Chỉ Read trong phòng ban | Xem thông tin, không chỉnh sửa |

## 🔄 Order Status Workflow

### Quy trình trạng thái đơn hàng:
```
Open/ReOpen → Submit → Loaded → Check → Marked → Sewing → Complete
     ↑                   ↓
     ← ← ← ← Request ← ← ←
```

### Chi tiết từng trạng thái:

| Status | Department | Quyền thay đổi | Mô tả |
|--------|------------|----------------|-------|
| **Open** | AH | ah_write | Đơn hàng mới tạo, chưa được submit |
| **ReOpen** | AH | ah_write | Đơn hàng được mở lại từ Request |
| **Submit** | AH | ah_write | Đơn hàng đã submit, chờ lên kế hoạch |
| **Request** | Planning | planning_write | Yêu cầu mở lại đơn hàng từ AH gửi Plan |
| **Loaded** | Planning | planning_write | Đơn hàng đã được lên kế hoạch sản xuất |
| **Sewing** | SM | sm_write | Đang trong quá trình may |
| **Check** | Sample | sample_write | Kiểm tra đầu vào |
| **Marked** | CMD | cmd_write | Đã hoàn thành Marker |
| **Complete** | Sample | sample_write | Hoàn thành toàn bộ |


### Logic cập nhật trạng thái:

#### 1. **AH Department (Approval/Handle)**
```javascript
// Tạo đơn hàng mới
status: "Open" 

// Submit đơn hàng (cần validation)
requireFields: ['plan_qty', 'sample_type', 'ah_date', 'delivery_date']
status: "Open" → "Submit"

// Xử lý Request từ Planning
status: "Request" → "ReOpen"
```

#### 2. **Planning Department**
```javascript
// Thêm vào kế hoạch sản xuất
status: "Submit" → "Loaded"
autoUpdate: ['marker_date', 'cut_start_date', 'sewing_start_date']

// Yêu cầu mở lại đơn hàng
status: "Loaded" → "Request"

// Đơn hàng trong ma trận planning
displayFilter: ['Loaded', 'Marked', 'Check', 'Sewing']
orderCount: includes ['Loaded', 'Check', 'Sewing'] in "Order on Plan"
```

#### 3. **SM Department (Sewing Management)**  
```javascript
// Chuyển sang trạng thái may
status: "Loaded" → "Sewing"
tracking: sewing process management
```

#### 4. **Sample Department**
```javascript
// Kiểm tra chất lượng
status: "Sewing" → "Check"
status: "Check" → "Complete"
permissions: only sample_write can change to Check/Complete
```

#### 5. **CMD Department (Complete Management)**
```javascript
// Hoàn thành sản xuất  
status: "Complete" → "Marked"
finalStatus: production completed
```

## 📊 Modules và Chức năng

### 🗓️ **Planning Module** (`plan.js`)
- **Ma trận sản xuất**: Hiển thị timeline theo ngày
- **Drag & Drop**: Kéo thả để thay đổi lịch sản xuất
- **Order on Plan Counter**: Đếm số đơn hàng cùng ngày marker
- **Submit Orders Popup**: Thêm đơn hàng vào kế hoạch
- **Request Orders Popup**: Xử lý yêu cầu mở lại
- **Columns**: Status, Customer, GO No, Style, Sample, Plan Qty, Daily Qty, Sewing Start, Marker Date, Sewing End, Delivery Date + Daily timeline

### 📋 **AH Module** (`ah.js`)  
- **Order Management**: Tạo, sửa, xóa đơn hàng
- **Status Filtering**: Open Orders, On Plan, Marked Orders
- **Multiple Order Import**: Import từ Excel với template
- **Context Menu**: Chi tiết, Copy order, Submit, Cancel, Request Open
- **Validation**: Kiểm tra required fields khi Submit

### 🧵 **SM Module** (`sm.js`)
- **Sewing Process Management**: Quản lý quy trình may
- **Status Tracking**: Theo dõi tiến độ may
- **Department Filter**: Chỉ hiển thị đơn liên quan SM

### ✅ **CMD Module** (`cmd.js`)
- **Production Completion**: Đánh dấu hoàn thành sản xuất
- **Final Status**: Chuyển trạng thái "Complete" → "Marked"
- **Quality Control**: Kiểm tra cuối cùng

### 🔬 **Sample Module** (`sample.js`)
- **Quality Check**: Kiểm tra chất lượng sản phẩm
- **Status Transition**: "Sewing" → "Check" → "Complete"
- **Filter Options**: All Sample Status, Check, Loaded, Marked, Sewing

## 🗄️ Database Schema

### Bảng chính:
- **`departments`**: Quản lý phòng ban (PLAN, AH, SM, CMD, SAMPLE)
- **`users`**: Thông tin user và phân quyền
- **`orders`**: Đơn hàng với tracking user và display_order
- **`activity_logs`**: Log hoạt động với user_id 
- **`user_activity_logs`**: Log hoạt động user riêng biệt

### Cấu trúc bảng `orders`:
```sql
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_short_name VARCHAR(100),
    go_no VARCHAR(50),
    style_no VARCHAR(50), 
    jo_no VARCHAR(50),
    color_code VARCHAR(50),
    product_category VARCHAR(100),
    wash_type VARCHAR(50),
    plan_qty INT,
    target_output INT DEFAULT 1,
    delivery_date DATE,
    marker_date DATE,
    cut_start_date DATE,
    sewing_start_date DATE,
    sample_type VARCHAR(100),
    ah_date DATE,
    sm_date DATE,
    remark TEXT,
    order_status ENUM('Open','ReOpen','Submit','Request','Loaded','Sewing','Check','Complete','Marked','Cancel') DEFAULT 'Open',
    display_order INT DEFAULT 0,
    created_by INT,
    updated_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## 🛠️ API Endpoints (`process.php`)

### Core API Actions:
- **`get_orders`**: Lấy danh sách đơn hàng
- **`update_order_field`**: Cập nhật một trường
- **`update_order_fields`**: Cập nhật nhiều trường
- **`update_order_full`**: Cập nhật toàn bộ đơn hàng
- **`update_order_sequence`**: Cập nhật thứ tự drag-drop
- **`save_multiple_orders`**: Lưu nhiều đơn hàng cùng lúc
- **`get_order_status_report`**: Báo cáo trạng thái đơn hàng

### Permission Logic:
```php
// Department-based write permissions
switch ($userDept) {
    case 'PLAN': $hasWritePermission = checkPermission('planning_write'); break;
    case 'AH': $hasWritePermission = checkPermission('ah_write'); break;
    case 'SM': $hasWritePermission = checkPermission('sm_write'); break;
    case 'CMD': $hasWritePermission = checkPermission('cmd_write'); break;
    case 'SAMPLE': $hasWritePermission = checkPermission('sample_write'); break;
}

// Special permission for Sample status changes
if ($field === 'order_status' && in_array($value, ['Check', 'Complete'])) {
    $hasWritePermission = checkPermission('sample_write');
}
```

## 🎨 Frontend Architecture

### Module Structure:
- **`auth.js`**: Authentication và permission handling
- **`api.js`**: API calls và error handling  
- **`filter.js`**: Table filtering và search
- **`orders.js`**: Core order operations
- **`ui.js`**: UI management và modal handling
- **`plan.js`**: Planning matrix và timeline
- **`ah.js`**: AH department operations
- **`sm.js`**: SM department operations  
- **`cmd.js`**: CMD department operations
- **`sample.js`**: Sample department operations

### Key Features:
- **Permission-based UI**: Hide/show elements based on user permissions
- **Real-time updates**: Auto-refresh sau khi thay đổi
- **Excel Import/Export**: Hỗ trợ import/export đơn hàng
- **Drag & Drop**: Kéo thả để sắp xếp lại thứ tự
- **Context Menu**: Right-click menu với actions theo department
- **Modal System**: Popup forms cho chi tiết đơn hàng

## 📈 Reporting Features

### 1. **Order Status Report** (`order_status_report.php`)
- Timeline của từng đơn hàng
- Tracking submission, loading, completion dates
- Performance metrics theo department

### 2. **Order Timeline** (`order_timeline.php`)  
- Chi tiết timeline từng đơn hàng
- Activity logs với user information
- Change history tracking

### 3. **Order History** (`order_history.php`)
- Lịch sử thay đổi đơn hàng
- User activity tracking
- Audit trail cho compliance

## ️ Cài đặt và Setup

### 1. Yêu cầu hệ thống
- **PHP 7.4+** với PDO extension, JSON support
- **MariaDB/MySQL 5.7+** với InnoDB engine  
- **Web server** (Apache/Nginx) với mod_rewrite
- **Browser** hỗ trợ ES6+ (Chrome 60+, Firefox 55+, Safari 11+)

### 2. Setup Database
```bash
# 1. Clone source code
git clone [repository-url] webplan
cd webplan

# 2. Configure database
# Edit config/database.php với thông tin database

# 3. Run database setup
http://your-domain/webplan/docs-and-tests/setup_database.php

# 4. Verify installation
http://your-domain/webplan/login.php
```

### 3. Thông tin đăng nhập mặc định

| Username | Password | Role | Department | Chức năng |
|----------|----------|------|------------|-----------|
| **admin** | password | Admin | Planning | Toàn quyền hệ thống |
| **plan_manager** | password | Manager | Planning | Quản lý kế hoạch sản xuất |
| **ah_manager** | password | Manager | AH | Quản lý đơn hàng |
| **sm_manager** | password | Manager | SM | Quản lý quy trình may |
| **cmd_manager** | password | Manager | CMD | Quản lý hoàn thành |
| **plan_user** | password | User | Planning | Xem kế hoạch (read-only) |
| **ah_user** | password | User | AH | Xem đơn hàng (read-only) |

⚠️ **Bảo mật**: Đổi password ngay sau khi cài đặt!

## 📁 Cấu trúc thư mục (Updated)

```
WebPlan-V19/
├── 📁 admin/                   # 🔧 Admin panel và user management
│   ├── admin.php              # Admin dashboard
│   ├── user_process.php       # User CRUD operations  
│   ├── process_login.php      # Admin login processing
│   └── index.php             # Admin redirect helper
├── 📁 config/
│   └── database.php          # Database configuration
├── 📁 docs-and-tests/         # 📚 Documentation và testing
│   ├── README_USER_MANAGEMENT.md
│   ├── setup_database.php    # Database installer
│   └── test_multiple_orders.html
├── 📁 models/                 # 🗃️ Data models
│   ├── UserModel.php         # User management operations
│   ├── DepartmentModel.php   # Department operations  
│   └── OrderModel.php        # Order operations với user tracking
├── 📁 scr/                    # 📜 Frontend JavaScript modules
│   ├── auth.js               # Authentication & permissions
│   ├── api.js                # API calls & error handling
│   ├── filter.js             # Table filtering & search
│   ├── orders.js             # Core order operations
│   ├── ui.js                 # UI management & modals
│   ├── plan.js               # Planning matrix & timeline
│   ├── ah.js                 # AH department module
│   ├── sm.js                 # SM department module
│   ├── cmd.js                # CMD department module
│   └── sample.js             # Sample department module
├── 📁 sql/
│   ├── create_database.sql   # Basic schema (legacy)
│   ├── user_management_schema.sql # Full schema with users
│   └── xampp_setup.sql       # XAMPP specific setup
├── 🔐 auth.php               # Authentication functions
├── 🏠 index.php              # Main application interface
├── 🔑 login.php              # Login page & logout
├── ⚙️ process.php            # Main API backend
├── 📊 order_status_report.php # Status reporting
├── 📈 order_timeline.php     # Order timeline viewer
├── 📋 order_history.php      # Order history viewer
└── 🎨 style.css              # Application styles
```

## 🔧 Cách sử dụng

### 1. Đăng nhập và Navigation
```bash
# 1. Truy cập hệ thống
http://your-domain/webplan/login.php

# 2. Đăng nhập với username/password
# Hệ thống sẽ redirect về tab phù hợp với department

# 3. Navigation bar
[Planning] [AH] [SM] [CMD] [Sample] [Admin Panel] [Logout]
# Chỉ hiển thị tab có quyền truy cập
```

### 2. Interface theo phòng ban

#### **Planning Department**
- **Kế hoạch sản xuất**: Ma trận timeline với drag & drop
- **Submit Orders**: Thêm đơn hàng từ Submit → Loaded
- **Request Orders**: Xử lý yêu cầu mở lại từ Request → ReOpen
- **Order on Plan**: Đếm số đơn hàng cùng marker date

#### **AH Department**  
- **Order Management**: CRUD operations cho đơn hàng
- **Status Filter**: Open Orders / On Plan / Marked Orders
- **Multiple Import**: Import Excel với template download
- **Submit Workflow**: Validate required fields trước khi Submit

#### **SM Department**
- **Sewing Management**: Quản lý quy trình may
- **Status Tracking**: "Loaded" → "Sewing"

#### **CMD Department**
- **Production Completion**: "Complete" → "Marked"
- **Final Quality Control**: Kiểm tra cuối cùng

#### **Sample Department**
- **Quality Check**: "Sewing" → "Check" → "Complete"
- **Testing Workflow**: Sample development process

### 3. Quản lý User (Admin only)

#### **Admin Panel Features**:
```bash
# Truy cập Admin Panel
http://your-domain/webplan/admin/admin.php

# Functions:
- 👥 User Management: Create, Edit, Delete, Activate/Deactivate
- 📊 Department Statistics: User distribution by department  
- 📈 Activity Monitoring: User login/logout tracking
- 🔍 Audit Logs: Complete activity history
```

#### **User Management Operations**:
- **Create User**: Username, Password, Full Name, Email, Department, Role
- **Edit User**: Update profile, change department/role, reset password
- **Deactivate User**: Suspend access without deleting data
- **View Statistics**: Login frequency, last activity, department distribution

## 🔐 Security Features

### Authentication
- Password hashing với `password_hash()`
- Session-based authentication
- Automatic logout on session expire
- IP address logging

### Authorization
- Role-based permissions
- Department-based access control
- Function-level permission checks
- Frontend UI restrictions

### Logging
- User activity tracking
- Order modification history
- Login/logout events
- Admin actions monitoring

## 🎨 Frontend Enhancements

### Permission-based UI
```javascript
// Kiểm tra quyền trong JavaScript
if (hasWritePermissionForCurrentDepartment()) {
    // Cho phép chỉnh sửa
} else {
    // Chỉ xem
}
```

### User Info Bar
- Hiển thị thông tin user hiện tại
- Department và role badge
- Quick access đến Admin Panel
- Logout button

## 📊 Monitoring và Reports

### User Activity Dashboard
- Login/logout tracking
- Action history per user
- Department activity statistics
- Performance metrics

### Order Tracking
- User tạo/sửa đơn hàng
- Change history với user info
- Department workflow tracking

## 🔄 Migration từ version cũ

Hệ thống tự động migrate data từ version cũ:
1. Giữ nguyên tất cả orders hiện có
2. Thêm user tracking cho các thay đổi mới
3. Backup tự động trước khi upgrade

## 🚨 Troubleshooting

### Lỗi đăng nhập
- Kiểm tra database connection
- Verify user exists và status = 'active'
- Check session configuration

## 🔐 Security Features

### Authentication & Authorization
```php
// Password Security
- BCrypt hashing with cost factor 10
- Strong password requirements (min 8 chars, mixed case)
- Session-based authentication với timeout
- Automatic logout on inactivity (30 minutes)

// Permission System  
- Role-based access control (RBAC)
- Department-based resource isolation
- Function-level permission checks
- Frontend UI restrictions based on permissions

// Security Headers
- X-Content-Type-Options: nosniff  
- X-Frame-Options: DENY
- X-XSS-Protection: 1; mode=block
- Content-Security-Policy implementation
```

### Data Protection
```sql
-- Database Security
- Foreign key constraints untuk data integrity
- Prepared statements chống SQL injection  
- Input validation và sanitization
- Activity logging cho audit trail

-- Session Security
- Session ID regeneration sau login
- HttpOnly và Secure flags cho cookies
- IP address tracking để detect session hijacking
- Session cleanup khi logout
```

### Logging & Monitoring
```php
// Activity Tracking
- User login/logout events
- Order creation/modification history  
- Status change tracking với user_id
- Failed login attempts monitoring
- Real-time activity dashboard cho admin

// Audit Trail
- Complete change history for compliance
- User activity reports cho management
- Data retention policies
- Export logs cho external analysis
```

## 📊 Monitoring và Reports

### 1. **User Activity Dashboard**
```sql
-- Login/Logout Tracking
SELECT u.username, ual.action, ual.created_at 
FROM user_activity_logs ual
JOIN users u ON ual.user_id = u.id
WHERE ual.action IN ('login', 'logout')
ORDER BY ual.created_at DESC;

-- Department Activity Statistics  
SELECT d.department_name, COUNT(ual.id) as activity_count
FROM departments d
LEFT JOIN users u ON d.id = u.department_id  
LEFT JOIN user_activity_logs ual ON u.id = ual.user_id
GROUP BY d.id;
```

### 2. **Order Tracking Reports**
```sql
-- Order Status Timeline
SELECT o.go_no, al.action, al.old_value, al.new_value, 
       u.username, al.created_at
FROM orders o
JOIN activity_logs al ON o.id = al.order_id
LEFT JOIN users u ON al.user_id = u.id  
WHERE al.action LIKE 'update_field_order_status'
ORDER BY o.id, al.created_at;

-- Department Performance Metrics
SELECT d.department_name,
       COUNT(CASE WHEN al.action = 'update_field_order_status' 
                  AND al.new_value = 'Submit' THEN 1 END) as submitted_orders,
       COUNT(CASE WHEN al.action = 'update_field_order_status' 
                  AND al.new_value = 'Loaded' THEN 1 END) as loaded_orders
FROM departments d
LEFT JOIN users u ON d.id = u.department_id
LEFT JOIN activity_logs al ON u.id = al.user_id
GROUP BY d.id;
```

### 3. **Performance Analytics**
- **Response Time Monitoring**: API endpoint performance tracking
- **Database Query Optimization**: Slow query detection và indexing
- **User Engagement Metrics**: Daily/monthly active users
- **Feature Usage Statistics**: Most used features theo department

## 🔄 Migration và Backup

### Database Migration
```bash
# Backup trước khi migrate
mysqldump -u username -p webplan > backup_$(date +%Y%m%d).sql

# Migrate từ version cũ
php docs-and-tests/setup_database.php

# Verify migration
- Kiểm tra data integrity
- Test user permissions
- Validate workflow functionality
```

### Data Preservation
```sql
-- Preserve existing orders
- Giữ nguyên tất cả orders hiện có
- Thêm user tracking cho changes mới
- Migrate activity logs với user context
- Maintain display_order sequences

-- Backward Compatibility  
- API endpoints compatible với version cũ
- Database schema supports legacy data
- Graceful fallback cho missing user_id
```

## 🚨 Troubleshooting

### Authentication Issues
```bash
# Problem: Cannot login
Solutions:
1. Check database connection in config/database.php
2. Verify user exists và status = 'active'
3. Reset password: UPDATE users SET password_hash = '$2y$10$...' WHERE username = 'user';
4. Check session configuration in php.ini
5. Clear browser cookies/cache

# Problem: Session expires too quickly  
Solutions:
1. Increase session.gc_maxlifetime in php.ini
2. Update SESSION_TIMEOUT in auth.php
3. Check server time configuration
```

### Permission Errors
```bash
# Problem: "Unauthorized access" messages
Solutions:
1. Verify user role và department assignment
2. Check permission mapping trong UserModel.php
3. Ensure database schema updated với foreign keys
4. Test với admin account để isolate issue
5. Check browser console cho JavaScript errors

# Problem: Tabs not visible
Solutions:  
1. Verify user department permissions
2. Check JavaScript loading errors
3. Test permission functions trong auth.js
4. Validate database user-department relationship
```

### Database Issues
```bash
# Problem: Database connection failed
Solutions:
1. Check MySQL/MariaDB service status
2. Verify credentials trong config/database.php  
3. Test connection manually: mysql -u user -p database
4. Check firewall settings
5. Verify database grants: SHOW GRANTS FOR 'user'@'host';

# Problem: Tables missing or corrupted
Solutions:
1. Re-run setup_database.php
2. Check MySQL error logs: /var/log/mysql/error.log
3. Verify MySQL version compatibility (5.7+)
4. Check disk space và file permissions
5. Restore from backup if necessary
```

### Performance Issues
```bash
# Problem: Slow page loading
Solutions:
1. Check database query performance với EXPLAIN
2. Add missing indexes trên frequently queried columns
3. Optimize large datasets với pagination
4. Check server resources (CPU, RAM, disk I/O)
5. Enable query caching trong MySQL

# Problem: High memory usage
Solutions:
1. Optimize PHP memory_limit setting
2. Implement data pagination cho large result sets  
3. Add database connection pooling
4. Monitor và fix memory leaks trong JavaScript
5. Use CDN cho static assets
```

## 🔮 Tính năng sẽ phát triển

### Phase 1 - Enhanced Security (Q1 2025)
- [ ] **Two-factor authentication (2FA)** với Google Authenticator
- [ ] **Advanced password policies** với complexity requirements
- [ ] **IP whitelisting** cho admin accounts
- [ ] **Session management dashboard** với force logout capability
- [ ] **Automated security scanning** với vulnerability detection

### Phase 2 - Advanced Analytics (Q2 2025)  
- [ ] **Production efficiency dashboard** với KPI tracking
- [ ] **Predictive analytics** cho delivery time estimation
- [ ] **Department performance comparison** với benchmarking
- [ ] **Custom reporting builder** với drag-drop interface
- [ ] **Real-time notifications** cho status changes

### Phase 3 - Mobile & Integration (Q3 2025)
- [ ] **Progressive Web App (PWA)** cho mobile access
- [ ] **Barcode/QR code scanning** cho order tracking  
- [ ] **REST API documentation** với Swagger/OpenAPI
- [ ] **Webhook integration** cho external systems
- [ ] **Email notification system** cho workflow events

### Phase 4 - AI & Automation (Q4 2025)
- [ ] **Machine learning** cho production time prediction
- [ ] **Automated workflow routing** based on order characteristics
- [ ] **Smart scheduling optimization** với constraint solving
- [ ] **Anomaly detection** cho quality issues
- [ ] **Natural language processing** cho order search

### Technical Enhancements
- [ ] **Microservices architecture** migration
- [ ] **Redis caching layer** cho performance optimization  
- [ ] **Elasticsearch integration** cho advanced search
- [ ] **Docker containerization** cho deployment
- [ ] **CI/CD pipeline** với automated testing

## 📞 Support & Maintenance

### Development Team Contact
```bash
# Technical Support
Email: tech-support@sps.com
Phone: +84-xxx-xxx-xxxx
Hours: 8:00 AM - 6:00 PM (GMT+7), Monday-Friday

# Emergency Contact (Production Issues)
24/7 Hotline: +84-xxx-xxx-xxxx
Escalation: senior-dev@sps.com
```

### Maintenance Schedule
```bash
# Regular Maintenance
- Daily: Automated backup at 02:00 AM
- Weekly: Performance monitoring report
- Monthly: Security audit và dependency updates
- Quarterly: Full system health check

# Update Notifications
- Critical security patches: Immediate deployment
- Feature updates: Monthly release cycle  
- Major version upgrades: Quarterly với advance notice
```

### Documentation & Training
- **User Manual**: Complete với screenshots và workflows
- **API Documentation**: Technical reference cho developers  
- **Video Tutorials**: Step-by-step training materials
- **Best Practices Guide**: Recommended workflows cho mỗi department
- **Troubleshooting Wiki**: Community-driven problem solutions

---

🎉 **Chúc mừng!** Bạn đã có một hệ thống quản lý sản xuất hoàn chỉnh với user management chuyên nghiệp, workflow automation, và enterprise-grade security!
