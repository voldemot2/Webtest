# Admin Panel

Folder này chứa tất cả các file liên quan đến quản lý user và admin panel.

## Files trong folder:

- `admin.php` - Trang admin panel chính để quản lý users
- `user_process.php` - API endpoint xử lý các thao tác CRUD với users  
- `process_login.php` - Xử lý đăng nhập
- `index.php` - Redirect tới admin.php

## Quyền truy cập:

- Chỉ user có role 'admin' mới có thể truy cập admin panel
- Tất cả files trong folder này đều có kiểm tra quyền admin
- Cần đăng nhập mới có thể sử dụng các chức năng

## Sử dụng:

- Truy cập: `/admin/admin.php` hoặc click link "Admin Panel" từ trang chính
- Đăng nhập bằng tài khoản admin để quản lý users
- Có thể tạo, sửa, xóa users và phân quyền
