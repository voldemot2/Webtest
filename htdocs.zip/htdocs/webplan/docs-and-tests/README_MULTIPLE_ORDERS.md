# Add Multiple Orders Feature - User Guid- **Sample Type**: Sample category
- **Plan Qty**: Planned quantity (default: 1)
- **AH Date**: Account Holder date
## 📋 Overview
The **Add Multiple Orders** feature allows AH (Account Holder) users to add multiple orders at once through a convenient modal interface. This feature supports both manual data entry and Excel import functionality.

## 🚀 Getting Started

### Access the Feature
1. Navigate to the **AH** tab in the system
2. Look for the green **"📋 Add Multiple Orders"** button next to the **"➕ New Order"** button
3. Click to open the modal

## 🔧 Features

### 1. Manual Data Entry
- **Add Rows**: Click "➕ Add Row" to add new order rows
- **Remove Rows**: Use the "🗑️" button in each row to remove unwanted entries
- **Select Orders**: Use checkboxes to select which orders to save
- **Clear All**: Use "🗑️ Clear All" to remove all rows at once

### 2. Excel Import
- **Download Template**: Click "📄 Download Template" to get a sample Excel file
- **Import Data**: Use "📁 Import from Excel" to upload and populate data from Excel files
- **Supported Formats**: .xlsx, .xls, .csv

### 3. Bulk Operations
- **Select All**: Use the header checkbox to select/deselect all orders
- **Batch Save**: Save only selected orders with "💾 Save Selected Orders"

## 📊 Data Fields

### Required Fields ⚠️
- **Buyer**: Customer short name
- **GO No**: Garment Order number  
- **Style**: Style number

### Optional Fields
- **Job No**: Job number
- **Color Code**: Color specification
- **Product Type**: Product category
- **Wash Type**: Washing specification
- **Sample Type**: Sample category
- **Plan Qty**: Planned quantity (default: 0)
- **Target Output**: Target production output (default: 1, required)
- **AH Date**: Account Holder date
- **Delivery Date**: Expected delivery date

## 📁 Excel Template Structure

The Excel template includes the following columns in order:
```
| Buyer | GO No | Job No | Color Code | Style | Product Type | Wash Type | Sample Type | Plan Qty | AH Date | Delivery Date |
```

### Sample Data
```
NIKE    | GO001 | JOB001 | RED        | T-SHIRT | GARMENT     | STONE WASH | PP         | 1000     | 2024-02-01 | 2024-03-01
ADIDAS  | GO002 | JOB002 | BLUE       | SHORTS  | GARMENT     | NORMAL     | SMS        | 500      | 2024-02-05 | 2024-03-05
PUMA    | GO003 | JOB003 | BLACK      | HOODIE  | GARMENT     | ENZYME     | TOP        | 750      | 2024-02-10 | 2024-03-10
```

## 📅 Date Formats

The system accepts multiple date formats:
- **YYYY-MM-DD** (ISO format - recommended)
- **DD/MM/YYYY** (European format)
- **DD-MM-YYYY** (Alternative format)

## ⚡ Usage Tips

### 💡 Best Practices
1. **Use Templates**: Download and use the Excel template for consistent formatting
2. **Validate Data**: Check required fields before saving
3. **Batch Processing**: Select only orders you want to save to avoid duplicates
4. **Date Consistency**: Use consistent date formats throughout your Excel file

### 🔧 Keyboard Shortcuts
- **Ctrl+C / Ctrl+V**: Copy and paste data from external sources
- **Tab**: Navigate between input fields
- **Escape**: Close the modal
- **Enter**: Navigate to next row (in input fields)

## 🚨 Error Handling

### Common Errors and Solutions

| Error | Solution |
|-------|----------|
| "Missing required fields" | Ensure Buyer, GO No, and Style are filled |
| "No orders selected" | Check at least one order before saving |
| "Excel import failed" | Check file format and template structure |
| "Invalid date format" | Use YYYY-MM-DD format or DD/MM/YYYY |

### Validation Rules
- **Required Fields**: Must be filled for each selected order
- **Date Fields**: Must be valid dates or left empty
- **Numeric Fields**: Plan Qty must be a positive number or empty
- **Duplicate Check**: System may warn about potential duplicates

## 🔒 Permissions

### Required Permissions
- **ah_write**: Required to save multiple orders
- **ah_read**: Required to access the AH module

### User Roles
This feature is available to users with AH (Account Holder) permissions.

## 🧪 Testing

A test page is available at `test_multiple_orders.html` for development and testing purposes.

### Test Features
- Modal functionality
- Excel template download
- Import simulation
- Data validation
- Mock API responses

## 🔄 Integration

### Backend Integration
- **Endpoint**: `process.php?action=save_multiple_orders`
- **Method**: POST
- **Content-Type**: application/json
- **Response**: JSON with success/error status

### Database Integration
- **Table**: `orders`
- **Model**: `OrderModel::createOrder()`
- **Logging**: Activity logs are automatically created

## 📝 Changelog

### Version 1.0
- ✅ Initial release
- ✅ Modal interface
- ✅ Excel import/export
- ✅ Batch operations
- ✅ Data validation
- ✅ Error handling
- ✅ Template download

## 🤝 Support

For technical support or feature requests, please contact the development team.

### Development Files Modified
- `scr/ah.js` - Main functionality
- `style.css` - Modal styling
- `process.php` - Backend API
- `index.php` - Library inclusion

---

**Note**: This feature requires the SheetJS library (XLSX) for Excel functionality. The library is automatically loaded via CDN.
