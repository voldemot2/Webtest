<?php
require_once 'auth.php';

// Xử lý logout nếu có tham số logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Ghi log logout nếu user đang đăng nhập
    if (isset($_SESSION['user_id'])) {
        logUserActivity('logout', 'User logged out');
    }
    
    // Thực hiện logout - xóa session
    logout();
    
    // Redirect về login page với thông báo
    header('Location: login.php?message=logged_out');
    exit();
}

// Nếu user đã đăng nhập, redirect về trang chính
if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SPS Production Management</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 40px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header img {
            width: 60px;
            height: 60px;
            margin-bottom: 10px;
        }
        .login-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .form-group input {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .form-group input:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
        }
        .login-btn {
            background: #2563eb;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }
        .login-btn:hover {
            background: #1d4ed8;
        }
        .login-btn:disabled {
            background: #94a3b8;
            cursor: not-allowed;
        }
        .error-message {
            background: #fee2e2;
            color: #dc2626;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        .success-message {
            background: #dcfce7;
            color: #16a34a;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        .demo-accounts {
            margin-top: 30px;
            padding: 20px;
            background: #f8fafc;
            border-radius: 5px;
            font-size: 14px;
        }
        .demo-accounts h4 {
            margin: 0 0 10px 0;
            color: #374151;
        }
        .demo-accounts ul {
            margin: 0;
            padding-left: 20px;
        }
        .demo-accounts li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body style="background-color: #f5f5f5;">
    <div class="login-container">
        <div class="login-header">
            <img src="apple-touch-icon.png" alt="SPS Logo">
            <h2>SPS Production Management</h2>
            <p>Đăng nhập để tiếp tục</p>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <div class="error-message">
                <?php 
                    switch($_GET['error']) {
                        case 'invalid': echo 'Tên đăng nhập hoặc mật khẩu không đúng!'; break;
                        case 'inactive': echo 'Tài khoản đã bị vô hiệu hóa!'; break;
                        case 'logout': echo 'Bạn đã đăng xuất thành công!'; break;
                        default: echo 'Có lỗi xảy ra, vui lòng thử lại!';
                    }
                ?>
            </div>
        <?php elseif (isset($_GET['message'])): ?>
            <div class="success-message">
                <?php 
                    switch($_GET['message']) {
                        case 'logged_out': echo '✅ Bạn đã đăng xuất thành công!'; break;
                        default: echo $_GET['message'];
                    }
                ?>
            </div>
        <?php endif; ?>

        <form class="login-form" method="POST" action="admin/process_login.php" id="loginForm">
            <div class="form-group">
                <label for="username">Tên đăng nhập:</label>
                <input type="text" id="username" name="username" required 
                       value="<?php echo htmlspecialchars($_GET['username'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="password">Mật khẩu:</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="login-btn" id="loginBtn">
                <span id="loginText">Đăng nhập</span>
                <span id="loginSpinner" style="display: none;">Đang xử lý...</span>
            </button>
        </form>

        <div class="demo-accounts">
            <h4>🔑 Tài khoản demo:</h4>
            <ul>
                <li><strong>admin</strong> / password (Quản trị hệ thống)</li>
                <li><strong>plan_manager</strong> / password (Planning Manager)</li>
                <li><strong>ah_manager</strong> / password (AH Manager)</li>
                <li><strong>sm_manager</strong> / password (SM Manager)</li>
                <li><strong>cmd_manager</strong> / password (CMD Manager)</li>
                <li><strong>plan_user</strong> / password (Planning User)</li>
                <li><strong>ah_user</strong> / password (AH User)</li>
            </ul>
        </div>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function() {
            const btn = document.getElementById('loginBtn');
            const text = document.getElementById('loginText');
            const spinner = document.getElementById('loginSpinner');
            
            btn.disabled = true;
            text.style.display = 'none';
            spinner.style.display = 'inline';
        });

        // Auto-fill demo account
        const demoButtons = document.querySelectorAll('.demo-accounts li');
        demoButtons.forEach(li => {
            li.style.cursor = 'pointer';
            li.addEventListener('click', function() {
                const text = this.textContent;
                const username = text.split(' / ')[0].replace('admin123', '').trim();
                if (username && username !== 'Tài' && username !== '🔑') {
                    document.getElementById('username').value = username;
                    document.getElementById('password').value = 'admin123';
                }
            });
        });
    </script>
</body>
</html>
