# 📦 Hướng dẫn Chuyển đổi Website sang Offline Mode

## 🎯 Tổng quan
Website WebPlan hiện tại sử dụng 5 thư viện CDN cần kết nối internet. Hướng dẫn này sẽ giúp bạn tải về và cấu hình để website hoạt động hoàn toàn offline.

## 📋 Danh sách thư viện CDN hiện tại

### 🔧 Thư viện chính (index.php)
1. **InteractJS** - Drag & Drop functionality
   - CDN: `https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js`
   - Kích thước: ~98KB
   - Chức năng: Kéo thả các phần tử trong planning matrix

2. **SortableJS** - Sortable lists
   - CDN: `https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js`
   - Kích thước: ~44KB
   - Chức năng: Sắp xếp danh sách orders

3. **SheetJS (XLSX)** - Excel import/export
   - CDN: `https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js`
   - Kích thước: ~882KB
   - Chức năng: Import/Export Excel files

### 🎨 Thư viện UI (Admin & Reports)
4. **Font Awesome** - Icons
   - CSS: `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css`
   - Fonts: 3 file .woff2 (total ~283KB)
   - Chức năng: Icons trong UI

5. **Chart.js** - Data visualization
   - CDN: `https://cdn.jsdelivr.net/npm/chart.js`
   - Kích thước: ~208KB
   - Chức năng: Biểu đồ trong admin panel

## 📁 Cấu trúc thư mục đã tạo

```
webplan/
├── libs/                          # Thư mục chứa thư viện offline
│   ├── interact.min.js            # InteractJS library
│   ├── Sortable.min.js            # SortableJS library  
│   ├── xlsx.full.min.js           # SheetJS library
│   ├── chart.min.js               # Chart.js library
│   └── fontawesome/               # Font Awesome
│       ├── all.min.css            # CSS chính
│       └── webfonts/              # Font files
│           ├── fa-solid-900.woff2
│           ├── fa-regular-400.woff2
│           └── fa-brands-400.woff2
├── test_offline.html              # File test thư viện offline
└── ...
```

## ✅ Files đã được cập nhật

### 1. index.php (Trang chính)
**Thay đổi:**
```php
<!-- CDN cũ -->
<script src="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js" defer></script>

<!-- Offline mới -->
<script src="libs/interact.min.js" defer></script>
<script src="libs/Sortable.min.js" defer></script>
<script src="libs/xlsx.full.min.js" defer></script>
```

### 2. admin/admin.php (Trang admin)
**Thay đổi:**
```php
<!-- CDN cũ -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Offline mới -->
<link rel="stylesheet" href="../libs/fontawesome/all.min.css">
<script src="../libs/chart.min.js"></script>
```

### 3. order_history.php (Lịch sử đơn hàng)
**Thay đổi:**
```php
<!-- CDN cũ -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- Offline mới -->
<link rel="stylesheet" href="libs/fontawesome/all.min.css">
```

### 4. order_status_report.php (Báo cáo trạng thái)
**Thay đổi:**
```php
<!-- CDN cũ -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- Offline mới -->
<link rel="stylesheet" href="libs/fontawesome/all.min.css">
```

## 🧪 Cách test website offline

### 1. Test tất cả thư viện
Mở file `test_offline.html` trong browser để kiểm tra từng thư viện:
```
http://localhost/webplan/test_offline.html
```

### 2. Test website chính
1. **Ngắt kết nối internet** hoặc chặn các domain CDN
2. Mở website: `http://localhost/webplan/`
3. Kiểm tra các chức năng:
   - ✅ Icons hiển thị đúng (Font Awesome)
   - ✅ Drag & drop hoạt động (InteractJS)
   - ✅ Sorting lists hoạt động (SortableJS)
   - ✅ Export Excel hoạt động (SheetJS)
   - ✅ Charts hiển thị (Chart.js trong admin)

## 🔄 Cách rollback về CDN (nếu cần)

Nếu có vấn đề với offline libraries, bạn có thể rollback bằng cách:

1. **Sửa index.php:**
```php
<!-- Thay thế các dòng offline bằng CDN -->
<script src="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js" defer></script>
```

2. **Sửa admin/admin.php:**
```php
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
```

3. **Sửa order_history.php và order_status_report.php:**
```php
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
```

## 💾 Backup trước khi thay đổi

Nếu bạn chưa backup, tạo backup ngay:
```bash
# Backup toàn bộ project
cp -r webplan webplan_backup_$(date +%Y%m%d)

# Hoặc chỉ backup các file đã sửa
cp index.php index.php.backup
cp admin/admin.php admin/admin.php.backup  
cp order_history.php order_history.php.backup
cp order_status_report.php order_status_report.php.backup
```

## 📊 Lợi ích của Offline Mode

### ✅ Ưu điểm:
- **Tốc độ**: Không cần download từ CDN mỗi lần load
- **Ổn định**: Không phụ thuộc kết nối internet
- **Bảo mật**: Không leak thông tin ra bên ngoài
- **Kiểm soát**: Có thể tùy chỉnh thư viện theo nhu cầu

### ⚠️ Nhược điểm:
- **Cập nhật thủ công**: Cần update thư viện manually
- **Dung lượng**: Tăng kích thước project (~1.3MB)
- **Maintain**: Cần theo dõi security updates

## 🔧 Tự động hóa việc cập nhật thư viện

Tạo script PowerShell để update thư viện:
```powershell
# update_libs.ps1
$libs = @(
    @{url="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js"; path="libs/interact.min.js"},
    @{url="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"; path="libs/Sortable.min.js"},
    @{url="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"; path="libs/xlsx.full.min.js"},
    @{url="https://cdn.jsdelivr.net/npm/chart.js"; path="libs/chart.min.js"}
)

foreach ($lib in $libs) {
    Write-Host "Downloading $($lib.url)..."
    Invoke-WebRequest -Uri $lib.url -OutFile $lib.path
}
```

## 🎯 Kết luận

✅ **Website WebPlan giờ đây có thể hoạt động hoàn toàn offline!**

- Tất cả 5 thư viện CDN đã được tải về và cấu hình
- Các file đã được cập nhật để sử dụng thư viện local
- File test được tạo để kiểm tra functionality
- Hướng dẫn rollback hoàn chỉnh nếu có vấn đề

**Tổng dung lượng tiết kiệm băng thông:** ~1.3MB mỗi lần load trang đầu tiên
**Thời gian load cải thiện:** Khoảng 200-500ms tùy vào tốc độ internet

Bạn có thể an tâm triển khai website trong môi trường không có internet ổn định!
