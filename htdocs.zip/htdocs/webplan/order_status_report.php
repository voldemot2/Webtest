<?php
require_once 'auth.php';
require_once 'config/database.php';

// Kiểm tra đăng nhập
$currentUser = checkLogin();

// Chỉ cho phép manager và admin xem reports
if ($currentUser['role'] !== 'admin' && $currentUser['role'] !== 'manager') {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Status Report - SPS Planning System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="libs/fontawesome/all.min.css">
    <style>
        * {
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            line-height: 1.5;
        }
        
        .report-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
        }
        
        .page-header {
            background: white;
            padding: 16px 20px;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            margin: 0;
            color: #1f2937;
            font-size: 24px;
            font-weight: 600;
        }
        
        .header-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        .back-btn, .refresh-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 500;
            font-size: 13px;
            transition: all 0.2s;
            cursor: pointer;
            border: none;
        }
        
        .back-btn {
            background: #6366f1;
            color: white;
        }
        
        .back-btn:hover {
            background: #4f46e5;
            transform: translateY(-1px);
        }
        
        .refresh-btn {
            background: #10b981;
            color: white;
        }
        
        .refresh-btn:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .report-panel {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            overflow: hidden;
        }
        
        .report-header {
            padding: 16px 20px;
            border-bottom: 1px solid #e5e7eb;
            background: #f9fafb;
        }
        
        .report-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin: 0;
        }
        
        .report-content {
            padding: 0;
            overflow-x: auto;
            max-height: 75vh;
            overflow-y: auto;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
            table-layout: fixed;
        }
        
        .report-table th {
            background: #f8fafc;
            color: #374151;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 2;
        }
        
        .report-table td {
            padding: 12px 16px;
            border-bottom: 1px solid #f3f4f6;
            font-size: 14px;
            color: #374151;
        }
        
        .report-table tbody tr:hover {
            background: #f9fafb;
        }
        
        .date-cell {
            font-family: 'Courier New', monospace;
            font-size: 13px;
        }
        
        .date-pending {
            color: #6b7280;
            font-style: italic;
        }
        
        .date-completed {
            color: #059669;
            font-weight: 500;
        }
        
        .go-no-cell {
            font-weight: 600;
            color: #1f2937;
        }
        
        .customer-cell {
            max-width: 150px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .sample-type-cell {
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 4px;
            background: #eff6ff;
            color: #1e40af;
            text-align: center;
            white-space: nowrap;
        }
        
        .timeline-btn {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 6px 12px;
            background: #8b5cf6;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
        }
        
        .timeline-btn:hover {
            background: #7c3aed;
            transform: translateY(-1px);
        }
        
        .timeline-btn i {
            font-size: 10px;
        }
        
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            overflow: auto;
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 2% auto;
            padding: 0;
            border: none;
            border-radius: 8px;
            width: 55%;
            max-width: 1200px;
            height: 90vh;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            position: relative;
        }
        
        .modal-header {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            padding: 16px 20px;
            border-radius: 8px 8px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-title {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
        }
        
        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: all 0.2s;
        }
        
        .close-btn:hover {
            background: rgba(255,255,255,0.2);
        }
        
        .modal-body {
            height: calc(90vh - 68px);
            overflow: hidden;
        }
        
        .modal-iframe {
            width: 100%;
            height: 100%;
            border: none;
            border-radius: 0 0 8px 8px;
        }
        
        .loading {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        .loading-bar {
            width: 100%;
            max-width: 320px;
            height: 8px;
            background: #e5e7eb;
            border-radius: 4px;
            margin: 18px auto 0 auto;
            overflow: hidden;
            position: relative;
        }
        .loading-bar-progress {
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, #6366f1 0%, #8b5cf6 100%);
            border-radius: 4px;
            transition: width 0.4s cubic-bezier(.4,0,.2,1);
            position: absolute;
            left: 0;
            top: 0;
        }
        .loading i {
            font-size: 24px;
            margin-bottom: 12px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-icon {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .report-container {
                padding: 12px;
            }
            
            .page-header {
                flex-direction: column;
                gap: 12px;
                text-align: center;
            }
            
            .header-actions {
                flex-direction: column;
                width: 100%;
            }
            
            .report-table {
                font-size: 12px;
            }
            
            .report-table th,
            .report-table td {
                padding: 8px 12px;
            }
            
            .customer-cell {
                max-width: 100px;
            }
            
            /* Modal responsive */
            .modal-content {
                width: 98%;
                height: 95vh;
                margin: 1% auto;
            }
            
            .modal-body {
                height: calc(95vh - 68px);
            }
            
            .modal-title {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-chart-line"></i> Order Status Report
            </h1>
            <div class="header-actions">
                <button class="refresh-btn" onclick="loadReport()">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
                <a href="index.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Planning
                </a>
            </div>
        </div>
        
        <div class="report-panel">
            <div class="report-header">
                <h3 class="report-title">
                    <i class="fas fa-table"></i> Order Status Timeline
                </h3>
            </div>
            <div class="report-content">
                <div id="reportContainer">
                    <div class="loading">
                        <i class="fas fa-spinner fa-spin"></i>
                        <div>Loading report data...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Timeline Modal -->
    <div id="timelineModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">
                    <i class="fas fa-clock"></i> Order Timeline
                </h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <iframe id="timelineFrame" class="modal-iframe" src=""></iframe>
            </div>
        </div>
    </div>
    
    <script src="scr/api.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadReport();
        });
        
        async function loadReport() {
            try {
                const container = document.getElementById('reportContainer');
                container.innerHTML = `
                    <div class="loading">
                        <i class="fas fa-spinner fa-spin"></i>
                        <div>Loading report data...</div>
                        <div class="loading-bar"><div class="loading-bar-progress" id="loadingBarProgress"></div></div>
                    </div>`;
                // Animate loading bar
                let progress = 0;
                const loadingBar = document.getElementById('loadingBarProgress');
                const interval = setInterval(() => {
                    progress += Math.random() * 20;
                    if (progress > 90) progress = 90;
                    if (loadingBar) loadingBar.style.width = progress + '%';
                }, 400);
                const response = await fetch('process.php?action=get_order_status_report');
                const text = await response.text();
                clearInterval(interval);
                if (loadingBar) loadingBar.style.width = '100%';
                setTimeout(() => {
                    if (loadingBar) loadingBar.style.width = '0%';
                }, 600);
                try {
                    const data = JSON.parse(text);
                    if (data.success) {
                        displayReport(data.orders);
                    } else {
                        displayError(data.error || 'Failed to load report data');
                    }
                } catch (parseError) {
                    console.error('JSON parse error:', parseError);
                    console.error('Response text:', text);
                    displayError('Invalid response from server');
                }
            } catch (error) {
                console.error('Error loading report:', error);
                displayError('Error loading report data');
            }
        }
        
        function displayReport(orders) {
            const container = document.getElementById('reportContainer');
            
            if (!orders || orders.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-icon">📊</div>
                        <div><strong>No orders found</strong></div>
                        <div>There are no orders to display in the report.</div>
                    </div>`;
                return;
            }
            
            let html = `
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>GO No</th>
                            <th>Sample Type</th>
                            <th>Current Status</th>
                            <th>Create Date</th>
                            <th>Submit Date</th>
                            <th>Load Date</th>
                            <th>Maker Date</th>
                            <th>Timeline</th>
                        </tr>
                    </thead>
                    <tbody>`;
            
            orders.forEach(order => {
                html += `
                    <tr>
                        <td class="go-no-cell">${order.id || 'N/A'}</td>
                        <td class="customer-cell" title="${order.customer || 'N/A'}">${order.customer || 'N/A'}</td>
                        <td class="go-no-cell">${order.go_no || 'N/A'}</td>
                        <td><span class="sample-type-cell">${order.sample_type || 'Regular'}</span></td>
                        <td><span class="sample-type-cell">${order.current_status || 'Open'}</span></td>
                        <td class="date-cell ${order.create_date ? 'date-completed' : 'date-pending'}">
                            ${formatDate(order.create_date) || '<span class="date-pending">Pending</span>'}
                        </td>
                        <td class="date-cell ${order.submit_date ? 'date-completed' : 'date-pending'}">
                            ${formatDate(order.submit_date) || '<span class="date-pending">Pending</span>'}
                        </td>
                        <td class="date-cell ${order.load_date ? 'date-completed' : 'date-pending'}">
                            ${formatDate(order.load_date) || '<span class="date-pending">Pending</span>'}
                        </td>
                        <td class="date-cell ${order.maker_date ? 'date-completed' : 'date-pending'}">
                            ${formatDate(order.maker_date) || '<span class="date-pending">Pending</span>'}
                        </td>
                        <td>
                            <button class="timeline-btn" onclick="openTimeline(${order.id})" title="View Order Timeline">
                                <i class="fas fa-clock"></i> Timeline
                            </button>
                        </td>
                    </tr>`;
            });
            
            html += `
                    </tbody>
                </table>`;
            
            container.innerHTML = html;
        }
        
        function displayError(message) {
            const container = document.getElementById('reportContainer');
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">⚠️</div>
                    <div><strong>Error Loading Report</strong></div>
                    <div>${message}</div>
                </div>`;
        }
        
        function formatDate(dateString) {
            if (!dateString) return null;
            try {
                const date = new Date(dateString);
                if (isNaN(date.getTime())) return dateString;
                // Format MM/DD/YYYY HH:MM
                const pad = n => n.toString().padStart(2, '0');
                const MM = pad(date.getMonth() + 1);
                const DD = pad(date.getDate());
                const YYYY = date.getFullYear();
                const HH = pad(date.getHours());
                const mm = pad(date.getMinutes());
                return `${MM}/${DD}/${YYYY} ${HH}:${mm}`;
            } catch (e) {
                return dateString;
            }
        }
        
        function openTimeline(orderId) {
            if (orderId) {
                const modal = document.getElementById('timelineModal');
                const iframe = document.getElementById('timelineFrame');
                const title = document.querySelector('.modal-title');
                
                // Update modal title with order ID
                title.innerHTML = `<i class="fas fa-clock"></i> Order Timeline - Order #${orderId}`;
                
                // Set iframe source
                iframe.src = `order_timeline.php?order_id=${orderId}`;
                
                // Show modal
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden'; // Prevent background scrolling
            }
        }
        
        function closeModal() {
            const modal = document.getElementById('timelineModal');
            const iframe = document.getElementById('timelineFrame');
            
            // Hide modal
            modal.style.display = 'none';
            document.body.style.overflow = 'auto'; // Restore scrolling
            
            // Clear iframe to stop any ongoing processes
            iframe.src = '';
        }
        
        // Close modal when clicking outside of it
        window.onclick = function(event) {
            const modal = document.getElementById('timelineModal');
            if (event.target == modal) {
                closeModal();
            }
        }
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const modal = document.getElementById('timelineModal');
                if (modal.style.display === 'block') {
                    closeModal();
                }
            }
        });
    </script>
</body>
</html>
