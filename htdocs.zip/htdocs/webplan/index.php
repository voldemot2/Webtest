<?php
require_once 'auth.php';

// Kiểm tra đăng nhập
$currentUser = checkLogin();

// Xác định tab active dựa trên permissions
function getActiveTab() {
    $permissions = [
        'KEHOACH' => 'planning_read',
        'AH' => 'ah_read', 
        'SM' => 'sm_read',
        'CMD' => 'cmd_read',
        'SAMPLE' => 'sample_read'
    ];
    
    foreach ($permissions as $tab => $permission) {
        if (checkPermission($permission)) {
            return $tab;
        }
    }
    
    return 'KEHOACH'; // fallback
}

$activeTab = getActiveTab();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Production Management</title>
    <link rel="stylesheet" href="style.css">
    <!-- Offline Libraries -->
    <script src="libs/interact.min.js" defer></script>
    <script src="libs/Sortable.min.js" defer></script>
    <!-- SheetJS library for Excel import/export -->
    <script src="libs/xlsx.full.min.js" defer></script>
    <!-- Import các file JS chức năng đã tách -->
    <script src="scr/auth.js" defer></script>
    <script src="scr/api.js" defer></script>
    <script src="scr/filter.js" defer></script>
    <script src="scr/orders.js" defer></script>
    <script src="scr/plan.js" defer></script>
    <script src="scr/ah.js" defer></script>
    <script src="scr/sm.js" defer></script>
    <script src="scr/cmd.js" defer></script>
    <script src="scr/sample.js" defer></script>
    <script src="scr/ui.js" defer></script>
</head>
<body>
</div>

<div class="header-container">
    <h2><span style="display: inline-flex; align-items: center;"><img alt="SPS icon" src="apple-touch-icon.png" style="width: 40px; height: 40px; vertical-align: middle; margin-right: 8px; margin-left: 5px;"/>SPS - PRODUCTION PLANNING MANAGEMENT</span></h2>
    
    <div class="user-info-compact">
        <div class="user-info-dropdown">
            <div class="user-trigger">
                <span class="user-name">👤 <?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                <span class="dropdown-arrow">▼</span>
            </div>
            <div class="user-dropdown-content">
                <div class="user-details">
                    <div class="user-dept"><?php echo htmlspecialchars($currentUser['department_name']); ?></div>
                    <div class="user-role"><?php echo ucfirst($currentUser['role']); ?></div>
                </div>
                <div class="user-actions">
                    <?php if (isAdmin()): ?>
                        <a href="admin/admin.php" class="admin-btn">🛠️ Admin Panel</a>
                    <?php endif; ?>
                    <?php if (checkPermission('admin') || $currentUser['role'] === 'manager'): ?>
                        <a href="order_status_report.php" class="history-btn">📊 Order History</a>
                    <?php endif; ?>
                    <a href="login.php?action=logout" class="logout-btn">🚪 Logout</a>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="tab-wrapper">
        <div id="tab-bar">
            <?php if (checkPermission('planning_read')): ?>
            <button class="tab-btn <?php echo ($activeTab === 'KEHOACH') ? 'active' : ''; ?>" data-tab="KEHOACH">Planning</button>
            <?php endif; ?>
            <?php if (checkPermission('ah_read')): ?>
            <button class="tab-btn <?php echo ($activeTab === 'AH') ? 'active' : ''; ?>" data-tab="AH">AH</button>
            <?php endif; ?>
            <?php if (checkPermission('sm_read')): ?>
            <button class="tab-btn <?php echo ($activeTab === 'SM') ? 'active' : ''; ?>" data-tab="SM">SM</button>
            <?php endif; ?>
            <?php if (checkPermission('cmd_read')): ?>
            <button class="tab-btn <?php echo ($activeTab === 'CMD') ? 'active' : ''; ?>" data-tab="CMD">CMD</button>
            <?php endif; ?>
            <?php if (checkPermission('sample_read')): ?>
            <button class="tab-btn <?php echo ($activeTab === 'SAMPLE') ? 'active' : ''; ?>" data-tab="SAMPLE">Sample</button>
            <?php endif; ?>
        </div>
        <?php if (checkPermission('planning_read')): ?>
        <div id="tab-KEHOACH" class="tab-content <?php echo ($activeTab === 'KEHOACH') ? 'active' : ''; ?>">
            <div id="orders-header"></div>
            <div id="orders-list"></div>
        </div>
        <?php endif; ?>
        
        <?php if (checkPermission('ah_read')): ?>
        <div id="tab-AH" class="tab-content <?php echo ($activeTab === 'AH') ? 'active' : ''; ?>">
        <div id="ah-header"></div>
        <div id="ah-list"></div>
        </div>
        <?php endif; ?>

        <?php if (checkPermission('sm_read')): ?>
        <div id="tab-SM" class="tab-content <?php echo ($activeTab === 'SM') ? 'active' : ''; ?>">
        <div id="sm-header"></div>
        <div id="sm-list"></div>
        </div>
        <?php endif; ?>

        <?php if (checkPermission('cmd_read')): ?>
        <div id="tab-CMD" class="tab-content <?php echo ($activeTab === 'CMD') ? 'active' : ''; ?>">
          <div id="cmd-header"></div>
          <div id="cmd-list"></div>
        </div>
        <?php endif; ?>
        
        <?php if (checkPermission('sample_read')): ?>
        <div id="tab-SAMPLE" class="tab-content <?php echo ($activeTab === 'SAMPLE') ? 'active' : ''; ?>">
          <div id="sample-header"></div>
          <div id="sample-list"></div>
        </div>
        <?php endif; ?>

    </div>
    <div id="modal-bg"></div>
    <div id="modal-detail"></div>
    <div id="quick-tooltip"></div>

    <!-- <script src="script.js" defer></script> -->
    <script>
        // Thông tin user hiện tại cho JavaScript
        window.currentUser = <?php echo json_encode($currentUser ?? null); ?>;
        window.userPermissions = {
            planning_read: <?php echo (checkPermission('planning_read') ? 'true' : 'false'); ?>,
            planning_write: <?php echo (checkPermission('planning_write') ? 'true' : 'false'); ?>,
            ah_read: <?php echo (checkPermission('ah_read') ? 'true' : 'false'); ?>,
            ah_write: <?php echo (checkPermission('ah_write') ? 'true' : 'false'); ?>,
            sm_read: <?php echo (checkPermission('sm_read') ? 'true' : 'false'); ?>,
            sm_write: <?php echo (checkPermission('sm_write') ? 'true' : 'false'); ?>,
            cmd_read: <?php echo (checkPermission('cmd_read') ? 'true' : 'false'); ?>,
            cmd_write: <?php echo (checkPermission('cmd_write') ? 'true' : 'false'); ?>,
            sample_read: <?php echo (checkPermission('sample_read') ? 'true' : 'false'); ?>,
            sample_write: <?php echo (checkPermission('sample_write') ? 'true' : 'false'); ?>
        };
        
        // Tab active mặc định
        window.defaultActiveTab = '<?php echo $activeTab; ?>';
        
        // Debug info (chỉ trong development)
        if (window.location.hostname === 'localhost' || window.location.hostname.includes('192.168')) {
            console.log('🔐 Current User:', window.currentUser);
            console.log('🔑 Permissions:', window.userPermissions);
            console.log('📋 Default Active Tab:', window.defaultActiveTab);
        }
        
        // User dropdown functionality
        document.addEventListener('DOMContentLoaded', function() {
            const userDropdown = document.querySelector('.user-info-dropdown');
            const userTrigger = document.querySelector('.user-trigger');
            
            if (userTrigger && userDropdown) {
                userTrigger.addEventListener('click', function(e) {
                    e.stopPropagation();
                    userDropdown.classList.toggle('active');
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function(e) {
                    if (!userDropdown.contains(e.target)) {
                        userDropdown.classList.remove('active');
                    }
                });
                
                // Close dropdown when pressing Escape
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape') {
                        userDropdown.classList.remove('active');
                    }
                });
            }
        });
    </script>
</body>
</html>