// auth.js
// Quản lý phân quyền và kiểm tra quyền truy cập trên frontend

/**
 * Kiểm tra quyền truy cập
 * @param {string} permission - Tên quyền cần kiểm tra
 * @returns {boolean}
 */
function hasPermission(permission) {
    return window.userPermissions && window.userPermissions[permission] === true;
}

/**
 * Kiểm tra user có phải admin không
 * @returns {boolean}
 */
function isAdmin() {
    return window.currentUser && window.currentUser.role === 'admin';
}

/**
 * Kiểm tra user có phải manager không
 * @returns {boolean}
 */
function isManager() {
    return window.currentUser && ['admin', 'manager'].includes(window.currentUser.role);
}

/**
 * Lấy department của user hiện tại
 * @returns {string|null}
 */
function getUserDepartment() {
    return window.currentUser ? window.currentUser.department_code : null;
}

/**
 * Kiểm tra user thuộc department cụ thể
 * @param {string} departmentCode
 * @returns {boolean}
 */
function isUserInDepartment(departmentCode) {
    return getUserDepartment() === departmentCode;
}

/**
 * Ẩn/hiện elements dựa trên quyền
 * @param {string} selector - CSS selector
 * @param {string} permission - Tên quyền
 */
function showByPermission(selector, permission) {
    const elements = document.querySelectorAll(selector);
    const hasAccess = hasPermission(permission);
    
    elements.forEach(el => {
        el.style.display = hasAccess ? '' : 'none';
    });
}

/**
 * Disable/enable buttons dựa trên quyền
 * @param {string} selector - CSS selector
 * @param {string} permission - Tên quyền
 */
function enableByPermission(selector, permission) {
    const elements = document.querySelectorAll(selector);
    const hasAccess = hasPermission(permission);
    
    elements.forEach(el => {
        el.disabled = !hasAccess;
        if (!hasAccess) {
            el.title = 'Bạn không có quyền thực hiện thao tác này';
            el.style.opacity = '0.5';
            el.style.cursor = 'not-allowed';
        }
    });
}

/**
 * Kiểm tra quyền trước khi thực hiện action
 * @param {string} permission - Tên quyền
 * @param {Function} callback - Function thực hiện nếu có quyền
 * @param {string} message - Thông báo lỗi nếu không có quyền
 */
function checkPermissionAndExecute(permission, callback, message = 'Bạn không có quyền thực hiện thao tác này!') {
    if (hasPermission(permission)) {
        callback();
    } else {
        alert(message);
    }
}

/**
 * Lấy thông tin user hiện tại
 * @returns {object|null}
 */
function getCurrentUser() {
    return window.currentUser || null;
}

/**
 * Format tên user để hiển thị
 * @returns {string}
 */
function getUserDisplayName() {
    const user = getCurrentUser();
    return user ? `${user.full_name} (${user.department_code})` : 'Unknown User';
}

/**
 * Kiểm tra quyền ghi cho từng department
 * @returns {boolean}
 */
function hasWritePermissionForCurrentDepartment() {
    const dept = getUserDepartment();
    
    switch (dept) {
        case 'PLAN':
            return hasPermission('planning_write');
        case 'AH':
            return hasPermission('ah_write');
        case 'SM':
            return hasPermission('sm_write');
        case 'CMD':
            return hasPermission('cmd_write');
        case 'SAMPLE':
            return hasPermission('sample_write');
        default:
            return isAdmin();
    }
}

/**
 * Setup permission-based UI khi DOM ready
 */
function setupPermissionBasedUI() {
    // Ẩn/hiện các elements dựa trên quyền
    if (!hasWritePermissionForCurrentDepartment()) {
        // Disable các button edit, update, delete
        enableByPermission('.btn-edit, .btn-update, .btn-delete', 'admin');
        
        // Disable các input field
        document.querySelectorAll('input[onchange*="updateOrder"], select[onchange*="updateOrder"]').forEach(el => {
            el.disabled = true;
            el.style.backgroundColor = '#f5f5f5';
            el.title = 'Chỉ đọc - Bạn không có quyền chỉnh sửa';
        });
    }
    
    // Hiển thị thông tin user và quyền trong console (development only)
    if (window.location.hostname === 'localhost' || window.location.hostname.includes('192.168')) {
        console.log('🔐 User Info:', getCurrentUser());
        console.log('🔑 Permissions:', window.userPermissions);
    }
}

// Export các function để sử dụng
window.hasPermission = hasPermission;
window.isAdmin = isAdmin;
window.isManager = isManager;
window.getUserDepartment = getUserDepartment;
window.isUserInDepartment = isUserInDepartment;
window.showByPermission = showByPermission;
window.enableByPermission = enableByPermission;
window.checkPermissionAndExecute = checkPermissionAndExecute;
window.getCurrentUser = getCurrentUser;
window.getUserDisplayName = getUserDisplayName;
window.hasWritePermissionForCurrentDepartment = hasWritePermissionForCurrentDepartment;
window.setupPermissionBasedUI = setupPermissionBasedUI;

// Auto setup khi DOM ready
document.addEventListener('DOMContentLoaded', setupPermissionBasedUI);
