// ui.js
// Quản lý tab, modal, tooltip, tìm kiếm, khởi tạo app, các event listener chung

/**
 * Hiển thị modal với nội dung HTML
 * @param {string} contentHtml
 */
function showModal(contentHtml) {
    document.getElementById("modal-detail").innerHTML = contentHtml;
    document.getElementById("modal-bg").style.display = "block";
    document.getElementById("modal-detail").style.display = "block";
}

/**
 * Ẩn modal
 */
function hideModal() {
    document.getElementById("modal-bg").style.display = "none";
    document.getElementById("modal-detail").style.display = "none";
}

/**
 * Khởi tạo tìm kiếm cho bảng
 * @param {string} inputId
 * @param {string} tableSelector
 * @param {string} rowSelector
 */
function initSearch(inputId, tableSelector, rowSelector) {
    const searchInput = document.getElementById(inputId);
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const keyword = this.value.toLowerCase();
            const rows = document.querySelectorAll(tableSelector + ' ' + rowSelector);
            rows.forEach(row => {
                const text = row.innerText.toLowerCase();
                row.style.display = text.includes(keyword) ? '' : 'none';
            });
        });
    }
}

/**
 * Khởi tạo sự kiện tooltip cho strip-bar
 */
function initTooltipEvents() {
    document.addEventListener('mouseover', function(e) {
        const target = e.target.closest('.strip-bar');
        if (target && target.hasAttribute('data-tooltip')) {
            const tip = document.getElementById('quick-tooltip');
            tip.textContent = target.getAttribute('data-tooltip');
            tip.style.display = 'block';
            document.onmousemove = function(ev) {
                tip.style.left = (ev.clientX + 16) + 'px';
                tip.style.top = (ev.clientY + 8) + 'px';
            };
        }
    });
    document.addEventListener('mouseout', function(e) {
        const target = e.target.closest('.strip-bar');
        if (target && target.hasAttribute('data-tooltip')) {
            const tip = document.getElementById('quick-tooltip');
            tip.style.display = 'none';
            document.onmousemove = null;
        }
    });
}

/**
 * Khởi tạo sự kiện chuyển tab
 */
function initTabEvents() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));
            const tab = this.getAttribute('data-tab');
            document.getElementById('tab-' + tab).classList.add('active');
            
            // Gọi render cho từng tab tương ứng - kiểm tra element tồn tại
            if (tab === 'KEHOACH' && document.getElementById('orders-list') && typeof renderMatrix === 'function') {
                renderMatrix();
            } else if (tab === 'AH' && document.getElementById('ah-list') && typeof renderAHHeader === 'function' && typeof renderTabAH === 'function') {
                renderAHHeader();
                renderTabAH();
            } else if (tab === 'SM' && document.getElementById('sm-list') && typeof renderTabSM === 'function') {
                renderTabSM();
            } else if (tab === 'CMD' && document.getElementById('cmd-list') && typeof renderTabCMD === 'function') {
                renderTabCMD();
            } else if (tab === 'SAMPLE' && document.getElementById('sample-list') && typeof renderSampleHeader === 'function' && typeof renderTabSample === 'function') {
                renderSampleHeader();
                renderTabSample();
            }
            // Chuyển đổi giữa các tab có thể cần thiết lập lại một số thành phần giao diện
            // Ví dụ: reset form, dừng video, v.v.
            // resetInterfaceForTab(tab);
        });
    });
}

/**
 * Render lại tab hiện tại
 */
async function refreshCurrentTab() {
    const activeTab = document.querySelector('.tab-btn.active');
    if (activeTab) {
        const tabName = activeTab.dataset.tab;
        if (tabName === 'KEHOACH') {
            await renderMatrix();
        } else if (tabName === 'AH' && typeof renderTabAH === 'function') {
            await renderTabAH();
        } else if (tabName === 'SM' && typeof renderTabSM === 'function') {
            await renderTabSM();
        } else if (tabName === 'CMD' && typeof renderTabCMD === 'function') {
            await renderTabCMD();
        } else if (tabName === 'SAMPLE' && typeof renderSampleHeader === 'function' && typeof renderTabSample === 'function') {
            renderSampleHeader();
            await renderTabSample();
        }
    }
}

/**
 * Set active tab dựa trên default tab từ server
 */
function setDefaultActiveTab() {
    const defaultTab = window.defaultActiveTab || 'KEHOACH';
    const targetButton = document.querySelector(`.tab-btn[data-tab="${defaultTab}"]`);
    const targetContent = document.getElementById(`tab-${defaultTab}`);
    
    if (targetButton && targetContent) {
        // Remove active từ tất cả tab buttons và contents
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        
        // Set active cho tab mặc định
        targetButton.classList.add('active');
        targetContent.classList.add('active');
        
        // Gọi render function tương ứng - chỉ khi tab content tồn tại
        if (defaultTab === 'KEHOACH' && document.getElementById('orders-list') && typeof renderMatrix === 'function') {
            renderMatrix();
        } else if (defaultTab === 'AH' && document.getElementById('ah-list') && typeof renderAHHeader === 'function' && typeof renderTabAH === 'function') {
            renderAHHeader();
            renderTabAH();
        } else if (defaultTab === 'SM' && document.getElementById('sm-list') && typeof renderTabSM === 'function') {
            renderTabSM();
        } else if (defaultTab === 'CMD' && document.getElementById('cmd-list') && typeof renderTabCMD === 'function') {
            renderTabCMD();
        } else if (defaultTab === 'SAMPLE' && document.getElementById('sample-list') && typeof renderSampleHeader === 'function' && typeof renderTabSample === 'function') {
            renderSampleHeader();
            renderTabSample();
        }
        
        console.log(`✅ Set active tab: ${defaultTab}`);
    } else {
        console.warn(`⚠️ Could not find tab elements for: ${defaultTab}`);
    }
}

/**
 * Khởi tạo ứng dụng khi DOMContentLoaded
 */
function initApp() {
    initTabEvents();
    initTooltipEvents();
    
    // Set tab active đúng dựa trên permissions thay vì luôn render Planning
    setDefaultActiveTab();
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') hideModal();
    });
}

// Export các hàm để file khác sử dụng
window.showModal = showModal;
window.hideModal = hideModal;
window.initSearch = initSearch;
window.initTooltipEvents = initTooltipEvents;
window.initTabEvents = initTabEvents;
window.setDefaultActiveTab = setDefaultActiveTab;
window.refreshCurrentTab = refreshCurrentTab;
window.initApp = initApp;

document.addEventListener('DOMContentLoaded', initApp);