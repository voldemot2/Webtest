/**
 * Filter module cho các bảng dữ liệu
 */

/**
 * Lưu trạng thái filter cho từng bảng
 * @type {Map<string, {filterStates: {[field: string]: Set<string>}, activeFilters: Set<string>}>}
 */
const tableFilters = new Map();

/**
 * Khởi tạo filter cho một bảng
 * @param {string} tableId ID của bảng cần thêm filter
 * @param {Object} options Cấu hình filter
 * @param {Object.<string, function(any): string>} options.fieldGetters Map các hàm để lấy giá trị filter cho từng trường
 * @param {function(HTMLElement): any[]} options.getDataSource Hàm trả về mảng dữ liệu gốc để lấy giá trị unique
 */
function initTableFilter(tableId, options) {
    if (!tableFilters.has(tableId)) {
        // Khởi tạo state cho bảng mới
        const filterState = {
            filterStates: {},
            activeFilters: new Set()
        };
        
        // Khởi tạo Set cho từng trường cần filter
        Object.keys(options.fieldGetters).forEach(field => {
            filterState.filterStates[field] = new Set();
        });
        
        tableFilters.set(tableId, filterState);
    }

    const headers = document.querySelectorAll(`#${tableId} .filter-header`);
    
    // Xóa popup cũ khi click ra ngoài
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.filter-header') && !e.target.closest('.filter-popup')) {
            document.querySelectorAll('.filter-popup').forEach(popup => popup.remove());
        }
    });

    headers.forEach(header => {
        header.addEventListener('click', async function() {
            // Xóa các popup khác
            document.querySelectorAll('.filter-popup').forEach(popup => popup.remove());
            
            const field = this.dataset.field;
            if (!options.fieldGetters[field]) return;

            const data = await options.getDataSource(document.getElementById(tableId));
            if (!Array.isArray(data)) {
                console.error('Data source must return an array');
                return;
            }
            let values = [...new Set(data.map(item => options.fieldGetters[field](item)))].filter(Boolean);
            values.sort();

            const { filterStates, activeFilters } = tableFilters.get(tableId);
            createFilterPopup(this, field, values, filterStates, activeFilters, tableId);
        });
    });
}

/**
 * Tạo popup filter
 * @param {HTMLElement} header Header cell cần tạo filter
 * @param {string} field Tên trường
 * @param {string[]} values Các giá trị unique để filter
 * @param {Object.<string, Set<string>>} filterStates Trạng thái filter
 * @param {Set<string>} activeFilters Danh sách filter đang active
 * @param {string} tableId ID của bảng
 */
function createFilterPopup(header, field, values, filterStates, activeFilters, tableId) {
    const hasActiveFilter = filterStates[field].size > 0;
    
    const popup = document.createElement('div');
    popup.className = 'filter-popup';
    
    popup.innerHTML = `
        <input type="text" class="filter-search" placeholder="Search...">
        <div class="filter-options">
            <div class="filter-option">
                <input type="checkbox" id="${field}-select-all" ${!hasActiveFilter ? 'checked' : ''}>
                <label for="${field}-select-all">(Select All)</label>
            </div>
            ${values.map((value, i) => `
                <div class="filter-option">
                    <input type="checkbox" id="${field}-${i}" value="${value}" 
                        ${!hasActiveFilter || filterStates[field].has(value) ? 'checked' : ''}>
                    <label for="${field}-${i}">${value}</label>
                </div>
            `).join('')}
        </div>
        <div class="filter-actions">
            <button class="clear">Clear Filter</button>
        </div>
    `;

    // Định vị popup
    document.body.appendChild(popup);
    const headerRect = header.getBoundingClientRect();
    popup.style.top = `${headerRect.bottom + window.scrollY}px`;
    popup.style.left = `${headerRect.left + window.scrollX}px`;
    
    // Auto focus vào ô search sau khi popup hiển thị
    const searchInput = popup.querySelector('.filter-search');
    setTimeout(() => {
        popup.classList.add('show');
        searchInput?.focus();
    }, 0);

    initFilterEvents(popup, header, field, filterStates, activeFilters, tableId);
}

/**
 * Khởi tạo các sự kiện cho filter popup
 */
function initFilterEvents(popup, header, field, filterStates, activeFilters, tableId) {
    const selectAll = popup.querySelector(`#${field}-select-all`);
    const searchInput = popup.querySelector('.filter-search');
    let searchTimeout;

    // Xử lý search trong filter
    searchInput.addEventListener('input', function() {
        const searchText = this.value.toLowerCase();
        clearTimeout(searchTimeout);
        
        // Đợi user ngừng gõ 300ms rồi mới thực hiện search
        searchTimeout = setTimeout(() => {
            // Bỏ chọn tất cả trước khi search
            selectAll.checked = false;
            const checkboxes = popup.querySelectorAll('.filter-options input[type="checkbox"]:not([id="${field}-select-all"])');
            checkboxes.forEach(cb => cb.checked = false);

            // Lọc và hiển thị/ẩn các option
            let hasMatches = false;
            popup.querySelectorAll('.filter-option:not(:first-child)').forEach(option => {
                const label = option.querySelector('label').textContent.toLowerCase();
                const matches = label.includes(searchText);
                option.style.display = matches ? '' : 'none';
                
                // Tự động chọn các kết quả phù hợp
                const checkbox = option.querySelector('input[type="checkbox"]');
                if (matches && searchText) {
                    checkbox.checked = true;
                    hasMatches = true;
                }
            });

            // Nếu không có từ khóa search thì chọn lại tất cả
            if (!searchText) {
                selectAll.checked = true;
                checkboxes.forEach(cb => cb.checked = true);
            }

            // Áp dụng filter
            applyFieldFilter(field, checkboxes, header, filterStates, activeFilters, tableId);
        }, 300);
    });

    // Xử lý khi bấm Enter
    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            popup.remove();
        }
    });

    // Xử lý select all
    selectAll.addEventListener('change', function() {
        const checkboxes = popup.querySelectorAll(`.filter-options input[type="checkbox"]:not([id="${field}-select-all"])`);
        checkboxes.forEach(cb => {
            cb.checked = this.checked;
        });
        
        // Lưu trạng thái và áp dụng filter
        applyFieldFilter(field, checkboxes, header, filterStates, activeFilters, tableId);
    });

    // Xử lý thay đổi từng checkbox
    popup.querySelectorAll('.filter-options input[type="checkbox"]:not([id="${field}-select-all"])').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const checkboxes = popup.querySelectorAll('.filter-options input[type="checkbox"]:not([id="${field}-select-all"])');
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            selectAll.checked = allChecked;
            
            // Lưu trạng thái và áp dụng filter
            applyFieldFilter(field, checkboxes, header, filterStates, activeFilters, tableId);
        });
    });

    // Xử lý clear filter
    popup.querySelector('.clear').addEventListener('click', function() {
        // Xóa trạng thái filter hiện tại
        filterStates[field].clear();
        activeFilters.delete(field);
        
        // Áp dụng lại các filter còn lại
        applyAllFilters(tableId);
        
        header.classList.remove('filtered-column');
        popup.remove();
    });
}

/**
 * Lưu và áp dụng filter cho một trường
 */
function applyFieldFilter(field, checkboxes, header, filterStates, activeFilters, tableId) {
    const selectedValues = Array.from(checkboxes)
        .filter(cb => cb.checked)
        .map(cb => cb.value);

    // Lưu trạng thái filter
    filterStates[field].clear();
    if (selectedValues.length !== checkboxes.length) {
        selectedValues.forEach(value => filterStates[field].add(value));
        activeFilters.add(field);
    } else {
        activeFilters.delete(field);
    }

    // Áp dụng tất cả các filter
    applyAllFilters(tableId);

    // Thêm indicator cho cột đã filter
    header.classList.toggle('filtered-column', activeFilters.has(field));
}

/**
 * Áp dụng tất cả các filter đang active cho một bảng
 */
function applyAllFilters(tableId) {
    const table = document.getElementById(tableId);
    if (!table || !tableFilters.has(tableId)) return;

    const { filterStates, activeFilters } = tableFilters.get(tableId);
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        // Mặc định hiển thị row
        let shouldShow = true;

        // Kiểm tra từng filter đang active
        for (const field of activeFilters) {
            const cellValue = getCellValue(row, field);

            // Nếu giá trị không nằm trong filter state, ẩn row
            if (!filterStates[field].has(cellValue)) {
                shouldShow = false;
                break;
            }
        }

        row.style.display = shouldShow ? '' : 'none';
    });
}

/**
 * Lấy giá trị của cell trong row theo field
 */
function getCellValue(row, field) {
    const table = row.closest('table');
    const tableId = table?.id;
    
    // Xác định loại bảng và mapping cột
    if (tableId === 'ah-table') {
        // Bảng AH: Status, Buyer, GO no, Style, Job No, Color code, Product type, Qty, Sample Type, AH Date, Delivery Date, Remark, Action
        switch(field) {
            case 'status':
                return row.querySelector('.order-status')?.textContent?.trim() || '';
            case 'buyer':
                return row.children[1]?.textContent?.trim() || '';  // Cột 2 (index 1)
            case 'gono':
                return row.children[2]?.textContent?.trim() || '';  // Cột 3 (index 2)
            default:
                return '';
        }
    } else if (tableId === 'cmd-table') {
        // Bảng CMD: Status, Customer, GO No, Style, Job No, Color Code, Product Type, Wash Type, Sample Type, Quantity, Delivery Date, Maker date, AH Date, Remark
        switch(field) {
            case 'status':
                return row.querySelector('.order-status')?.textContent?.trim() || '';
            case 'customer':
                return row.children[1]?.textContent?.trim() || '';  // Cột 2 (index 1)
            case 'gono':
                return row.children[2]?.textContent?.trim() || '';  // Cột 3 (index 2)
            default:
                return '';
        }
    } else if (tableId === 'sample-table') {
        // Bảng Sample: Status, Customer, GO No, Style, Job No, Color Code, Product Type, Wash Type, Sample Type, Quantity, Delivery Date, Marker Date, AH Date, SM Date, Remark
        switch(field) {
            case 'status':
                return row.querySelector('.order-status')?.textContent?.trim() || '';
            case 'customer':
                return row.children[1]?.textContent?.trim() || '';  // Cột 2 (index 1)
            case 'gono':
                return row.children[2]?.textContent?.trim() || '';  // Cột 3 (index 2)
            default:
                return '';
        }
    } else {
        // Bảng Plan (default): Status, Customer, GO No, Style, Sample
        switch(field) {
            case 'status':
                return row.querySelector('.order-status')?.textContent?.trim() || '';
            case 'customer':
                return row.children[2]?.textContent?.trim() || '';
            case 'gono':
                return row.children[3]?.textContent?.trim() || '';
            case 'style':
                return row.children[4]?.textContent?.trim() || '';
            case 'sample':
                return row.children[5]?.textContent?.trim() || '';
            default:
                return '';
        }
    }
}

// Export filter module ra global
window.TableFilter = {
    init: initTableFilter,
    applyFilters: applyAllFilters,
    clearFilters: function(tableId) {
        if (tableFilters.has(tableId)) {
            const { filterStates, activeFilters } = tableFilters.get(tableId);
            activeFilters.clear();
            Object.values(filterStates).forEach(set => set.clear());
            applyAllFilters(tableId);
        }
    }
};
