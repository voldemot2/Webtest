// sample.js
// Quản lý logic và giao diện tab Sample

/**
 * Render header cho tab Sample
 */
function renderSampleHeader() {
    const headerEl = document.getElementById('sample-header');
    
    // Kiểm tra xem element có tồn tại không
    if (!headerEl) {
        console.log('⚠️ Sample header element not found');
        return;
    }
    
    headerEl.innerHTML = `
        <input type="text" id="sample-search-box" placeholder="🔍 Search orders..." class="search-input" style="margin-bottom: 12px; padding: 6px; width: 280px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc;">
        <select id="sample-status-filter" class="filter-select" style="margin-bottom: 12px; padding: 6px; width: 200px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc;">
            <option value="Check,Loaded,Marked,Sewing">All Sample Status</option>
            <option value="Check">Check</option>
            <option value="Loaded">Loaded</option>
            <option value="Marked">Marked</option>
            <option value="Sewing">Sewing</option>
        </select>
    `;
    
    // Add event listener for status filter changes
    const statusFilter = document.getElementById('sample-status-filter');
    statusFilter.value = localStorage.getItem('sample-status-filter') || 'Check,Loaded,Marked,Sewing';
    statusFilter.addEventListener('change', async (e) => {
        localStorage.setItem('sample-status-filter', e.target.value);
        await renderTabSample();
    });

    // Add event for search box
    initSearch('sample-search-box', '#sample-table', 'tbody tr');
}

/**
 * Render tab Sample - hiển thị đơn hàng có status: check, loaded, marked, sewing
 */
async function renderTabSample() {
    const headerEl = document.getElementById('sample-header');
    const listEl = document.getElementById('sample-list');
    
    // Kiểm tra xem các element có tồn tại không
    if (!headerEl || !listEl) {
        console.log('⚠️ Sample elements not found');
        return;
    }
    
    // Render header if not already rendered
    if (!headerEl.innerHTML.trim()) {
        renderSampleHeader();
    }

    let orders = await fetchData('get_orders');
    
    // Get current filter value from localStorage or default to all
    const statusFilter = document.getElementById('sample-status-filter');
    const currentFilter = statusFilter?.value || 'Check,Loaded,Marked,Sewing';
    const statusArray = currentFilter.split(',');
    
    // Filter orders by status (Check, Loaded, Marked, Sewing)
    orders = orders.filter(o => statusArray.includes(o.order_status));
    
    listEl.innerHTML = `
        <div id="sample-table-wrapper" style="height:auto; overflow:auto; position:relative;">
        <table id="sample-table" class="sticky-header-table" style="min-width:1300px;">
            <thead>
                <tr>
                    <th class="filter-header" data-field="status">Status</th>
                    <th class="filter-header" data-field="customer">Customer</th>
                    <th class="filter-header" data-field="gono">GO No</th>
                    <th>Style</th>
                    <th>Job No</th>
                    <th>Color Code</th>
                    <th>Product Type</th>
                    <th>Wash Type</th>
                    <th>Sample Type</th>
                    <th>Quantity</th>
                    <th>Delivery Date</th>
                    <th>Marker Date</th>
                    <th>AH Date</th>
                    <th>SM Date</th>
                    <th>Remark</th>
                </tr>
            </thead>
            <tbody>
                ${orders.map(o => {
                    return `
                        <tr data-id="${o.id}">
                            <td><span class="order-status status-${(o.order_status||'').toLowerCase()}">${o.order_status||''}</span></td>
                            <td>${o.customer_short_name || ''}</td>
                            <td>${o.go_no || ''}</td>
                            <td>${o.style_no || ''}</td>
                            <td>${o.jo_no || ''}</td>
                            <td>${o.color_code || ''}</td>
                            <td>${o.product_category || ''}</td>
                            <td>${o.wash_type || ''}</td>
                            <td>${o.sample_type || ''}</td>
                            <td>${o.plan_qty || ''}</td>
                            <td>${o.delivery_date ? formatDateShort(o.delivery_date) : ''}</td>
                            <td>${o.marker_date ? formatDateShort(o.marker_date) : ''}</td>
                            <td>${o.ah_date ? formatDateShort(o.ah_date) : ''}</td>
                            <td>${o.sm_date ? formatDateShort(o.sm_date) : ''}</td>
                            <td>${o.remark || ''}</td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
        </div>
    `;

    
    // Add context menu for Sample table
    addSampleContextMenu();
    
    // Khởi tạo filter cho bảng Sample (giống tab AH và CMD)
    const tableFilter = {
        fieldGetters: {
            status: order => order.order_status || '',
            customer: order => order.customer_short_name || '',
            gono: order => order.go_no || ''
        },
        getDataSource: async () => {
            try {
                // Lấy lại dữ liệu mới nhất và apply filter hiện tại
                let allOrders = await fetchData('get_orders');
                if (!Array.isArray(allOrders)) {
                    console.error('❌ fetchData did not return array:', allOrders);
                    return [];
                }
                
                const currentFilter = localStorage.getItem('sample-status-filter') || 'Check,Loaded,Marked,Sewing';
                const statusArray = currentFilter.split(',');
                const filteredOrders = allOrders.filter(o => statusArray.includes(o.order_status));
                
                return filteredOrders;
            } catch (error) {
                console.error('❌ Error in getDataSource:', error);
                return [];
            }
        }
    };
    
    // Đảm bảo DOM đã sẵn sàng trước khi khởi tạo filter
    setTimeout(() => {
        const sampleTable = document.getElementById('sample-table');
        if (sampleTable) {
            // Kiểm tra xem filter đã được khởi tạo chưa
            if (!sampleTable.hasAttribute('data-filter-initialized')) {
                if (typeof TableFilter !== 'undefined') {
                    TableFilter.init('sample-table', tableFilter);
                    sampleTable.setAttribute('data-filter-initialized', 'true');
                }
            }
        }
    }, 100);
}

/**
 * Tạo và thêm context menu cho bảng Sample
 */
function addSampleContextMenu() {
    // Tạo context menu HTML nếu chưa tồn tại
    let contextMenu = document.getElementById('sample-context-menu');
    if (!contextMenu) {
        contextMenu = document.createElement('div');
        contextMenu.id = 'sample-context-menu';
        contextMenu.className = 'context-menu';
        document.body.appendChild(contextMenu);
    }

    // Sử dụng event delegation để xử lý context menu
    const sampleTable = document.getElementById('sample-table');
    if (sampleTable) {
        // Xóa event listeners cũ nếu có
        sampleTable.removeEventListener('contextmenu', handleSampleTableContextMenu);
        
        // Thêm event listener mới với event delegation
        sampleTable.addEventListener('contextmenu', handleSampleTableContextMenu);
    }

    // Ẩn context menu khi click ra ngoài (chỉ thêm một lần)
    if (!document.body.hasAttribute('data-sample-context-listener')) {
        document.addEventListener('click', hideSampleContextMenu);
        // Thêm event listener cho phím ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                hideSampleContextMenu();
            }
        });
        document.body.setAttribute('data-sample-context-listener', 'true');
    }
}

/**
 * Xử lý sự kiện chuột phải trên bảng Sample với event delegation
 */
function handleSampleTableContextMenu(e) {
    // Tìm hàng tr gần nhất
    const row = e.target.closest('tbody tr');
    if (!row) return;
    
    e.preventDefault();
    
    const orderId = row.getAttribute('data-id');
    if (!orderId) return;
    
    // Lấy trạng thái thực tế của đơn hàng từ DOM
    const statusElement = row.querySelector('.order-status');
    const actualStatus = statusElement ? statusElement.textContent.trim() : '';
    
    // Check if user has sample_write permission
    const hasSampleWrite = window.userPermissions && window.userPermissions.sample_write;
    
    const contextMenu = document.getElementById('sample-context-menu');
    
    // Tạo nội dung menu
    let menuItems = [];
    
    // Always show Details
    menuItems.push(`
        <div class="context-menu-item" onclick="showDetail(${orderId}, []); hideSampleContextMenu();">
            <span style="color: #2563eb;">📄</span> Details
        </div>
    `);
    
    // Show action buttons based on status and permission
    if (hasSampleWrite) {
        // New status flow: Loaded => Check => Marked => Sewing => Complete
        const canCheck = actualStatus === 'Loaded';
        const canMarked = actualStatus === 'Check';
        const canSewing = actualStatus === 'Marked';
        const canComplete = actualStatus === 'Sewing';
        
        if (canCheck || canMarked || canSewing || canComplete) {
            menuItems.push('<div class="context-menu-separator"></div>');
        }
        
        if (canCheck) {
            menuItems.push(`
                <div class="context-menu-item" onclick="changeSampleStatus(${orderId}, 'Check'); hideSampleContextMenu();">
                    <span style="color: #f59e0b;">✅</span> Check
                </div>
            `);
        }
        
        if (canMarked) {
            menuItems.push(`
                <div class="context-menu-item" onclick="changeSampleStatus(${orderId}, 'Marked'); hideSampleContextMenu();">
                    <span style="color: #8b5cf6;">🔨</span> Marked
                </div>
            `);
        }
        
        if (canSewing) {
            menuItems.push(`
                <div class="context-menu-item" onclick="changeSampleStatus(${orderId}, 'Sewing'); hideSampleContextMenu();">
                    <span style="color: #06b6d4;">🪡</span> Sewing
                </div>
            `);
        }
        
        if (canComplete) {
            menuItems.push(`
                <div class="context-menu-item" onclick="changeSampleStatus(${orderId}, 'Complete'); hideSampleContextMenu();">
                    <span style="color: #10b981;">🎯</span> Complete
                </div>
            `);
        }
    }
    
    contextMenu.innerHTML = menuItems.join('');
    
    // Hiển thị menu tại vị trí chuột
    contextMenu.style.display = 'block';
    contextMenu.style.left = e.pageX + 'px';
    contextMenu.style.top = e.pageY + 'px';
    
    // Đảm bảo menu không bị cắt bởi viewport
    const rect = contextMenu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
        contextMenu.style.left = (e.pageX - rect.width) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
        contextMenu.style.top = (e.pageY - rect.height) + 'px';
    }
}

/**
 * Ẩn context menu
 */
function hideSampleContextMenu(e) {
    const contextMenu = document.getElementById('sample-context-menu');
    if (contextMenu && contextMenu.style.display === 'block') {
        // Nếu click vào context menu thì không ẩn
        if (e && contextMenu.contains(e.target)) {
            return;
        }
        contextMenu.style.display = 'none';
    }
}

/**
 * Thay đổi status của order trong tab Sample
 * @param {number} orderId - ID của order
 * @param {string} newStatus - Status mới: 'Check', 'Marked', 'Sewing', hoặc 'Complete'
 */
async function changeSampleStatus(orderId, newStatus) {
    try {
        // Validate status
        if (!['Check', 'Marked', 'Sewing', 'Complete'].includes(newStatus)) {
            alert('Invalid status! Only Check, Marked, Sewing, or Complete are allowed.');
            return;
        }
        
        // Check permission first
        const hasSampleWrite = window.userPermissions && window.userPermissions.sample_write;
        if (!hasSampleWrite) {
            showToast('You do not have permission to change sample status', 'error');
            return;
        }
        
        // Update order status
        const result = await updateOrderSingleField(orderId, 'order_status', newStatus, { noRender: true });
        
        // Check for success - now we get proper result from updateOrderSingleField
        if (result && result.success === true) {
            // Show success message
            showToast(`Order status changed to ${newStatus} successfully!`, 'success');
            
            // Re-render tab to update UI
            await renderTabSample();
        } else {
            // Show detailed error message via toast only
            const errorMsg = result?.error || result?.message || 'Unknown error occurred';
            showToast(`Failed to change status: ${errorMsg}`, 'error');
        }
        
    } catch (error) {
        showToast(`Error: ${error.message}`, 'error');
    }
}

/**
 * Show toast notification
 * @param {string} message - Message to show
 * @param {string} type - Type: 'success', 'error', 'info'
 */
function showToast(message, type = 'info') {
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div style="
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#6366f1'};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 9999;
            font-weight: 500;
            max-width: 300px;
            word-wrap: break-word;
        ">
            ${message}
        </div>
    `;
    
    // Add to body
    document.body.appendChild(toast);
    
    // Remove after 3 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 3000);
}

// Export functions to global scope
window.renderSampleHeader = renderSampleHeader;
window.renderTabSample = renderTabSample;
window.changeSampleStatus = changeSampleStatus;
window.showToast = showToast;
window.addSampleContextMenu = addSampleContextMenu;
window.handleSampleTableContextMenu = handleSampleTableContextMenu;
window.hideSampleContextMenu = hideSampleContextMenu;
