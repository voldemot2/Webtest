// cmd.js
// Quản lý logic và giao diện tab CMD
/**
 * Render tab CMD (Computer maker department)
 */
async function renderTabCMD() {
    const headerEl = document.getElementById('cmd-header');
    headerEl.innerHTML = `
        <input type="text" id="cmd-search-box" placeholder="🔍 Search orders..." class="search-input">
    `;

    let orders = await fetchData('get_orders');
    // Filter for CMD relevant statuses
    const statusArray = ['Loaded', 'Check', 'Marked'];
    orders = orders.filter(o => statusArray.includes(o.order_status));

    const listEl = document.getElementById('cmd-list');
    listEl.innerHTML = `
        <div id="cmd-table-wrapper" style="height:auto; overflow:auto; position:relative;">
        <table id="cmd-table" class="sticky-header-table" style="min-width:1200px;">
            <thead>
                <tr>
                    <th class="filter-header" data-field="status">Status</th>
                    <th class="filter-header" data-field="customer">Customer</th>
                    <th class="filter-header" data-field="gono">GO No</th>
                    <th>Style</th>
                    <th>Job No</th>
                    <th>Color Code</th>
                    <th>Product Type</th>
                    <th>Wash Type</th>
                    <th>Sample Type</th>
                    <th>Quantity</th>
                    <th>Delivery Date</th>
                    <th>Maker date</th>
                    <th>AH Date</th>
                    <th>Remark</th>
                </tr>
            </thead>
            <tbody>
                ${orders.map((o, index) => `
                    <tr data-id="${o.id}" data-order-index="${index}">
                        <td><span class="order-status status-${(o.order_status||'').toLowerCase()}">${o.order_status||''}</span></td>
                        <td>${o.customer_short_name || ''}</td>
                        <td>${o.go_no || ''}</td>
                        <td>${o.style_no || ''}</td>
                        <td>${o.jo_no || ''}</td>
                        <td>${o.color_code || ''}</td>
                        <td>${o.product_category || ''}</td>
                        <td>${o.wash_type || ''}</td>
                        <td>${o.sample_type || ''}</td>
                        <td>${o.plan_qty || ''}</td>
                        <td>${o.delivery_date ? formatDateShort(o.delivery_date) : ''}</td>
                        <td>${o.marker_date ? formatDateShort(o.marker_date) : ''}</td>
                        <td>${o.ah_date ? formatDateShort(o.ah_date) : ''}</td>
                        <td>${o.remark || ''}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
        </div>
    `;
    // Khởi tạo tìm kiếm cho bảng CMD giống tab SM
    initSearch('cmd-search-box', '#cmd-table', 'tbody tr');
    
    // Thêm context menu cho bảng
    addCMDContextMenu();
    
    // Khởi tạo filter cho bảng CMD (giống tab AH)
    const tableFilter = {
        fieldGetters: {
            status: order => order.order_status || '',
            customer: order => order.customer_short_name || '',
            gono: order => order.go_no || ''
        },
        getDataSource: async () => {
            try {
                // Lấy lại dữ liệu mới nhất và apply filter cố định
                let allOrders = await fetchData('get_orders');
                if (!Array.isArray(allOrders)) {
                    console.error('❌ fetchData did not return array:', allOrders);
                    return [];
                }
                
                // Filter for CMD relevant statuses only
                const statusArray = ['Loaded', 'Check', 'Marked'];
                const filteredOrders = allOrders.filter(o => statusArray.includes(o.order_status));
                
                return filteredOrders;
            } catch (error) {
                console.error('❌ Error in getDataSource:', error);
                return [];
            }
        }
    };
    
    // Đảm bảo DOM đã sẵn sàng trước khi khởi tạo filter
    setTimeout(() => {
        const cmdTable = document.getElementById('cmd-table');
        if (cmdTable) {
            // Kiểm tra xem filter đã được khởi tạo chưa
            if (!cmdTable.hasAttribute('data-filter-initialized')) {
                TableFilter.init('cmd-table', tableFilter);
                cmdTable.setAttribute('data-filter-initialized', 'true');
            }
        }
    }, 100);
}

/**
 * Thêm context menu cho bảng CMD
 */
function addCMDContextMenu() {
    // Tạo context menu nếu chưa tồn tại
    let contextMenu = document.getElementById('cmd-context-menu');
    if (!contextMenu) {
        contextMenu = document.createElement('div');
        contextMenu.id = 'cmd-context-menu';
        contextMenu.className = 'context-menu';
        document.body.appendChild(contextMenu);
    }

    // Sử dụng event delegation
    const cmdTable = document.getElementById('cmd-table');
    if (cmdTable) {
        cmdTable.removeEventListener('contextmenu', handleCMDTableContextMenu);
        cmdTable.addEventListener('contextmenu', handleCMDTableContextMenu);
    }

    // Ẩn context menu khi click ra ngoài
    if (!document.body.hasAttribute('data-cmd-context-listener')) {
        document.addEventListener('click', hideCMDContextMenu);
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                hideCMDContextMenu();
            }
        });
        document.body.setAttribute('data-cmd-context-listener', 'true');
    }
}

/**
 * Xử lý sự kiện chuột phải trên bảng CMD
 */
function handleCMDTableContextMenu(e) {
    const row = e.target.closest('tbody tr');
    if (!row) return;
    
    e.preventDefault();
    
    const orderId = row.getAttribute('data-id');
    if (!orderId) return;
    
    const statusElement = row.querySelector('.order-status');
    const actualStatus = statusElement ? statusElement.textContent.trim() : '';
    
    const contextMenu = document.getElementById('cmd-context-menu');
    
    let menuItems = [];
    
    // Always show Details
    menuItems.push(`
        <div class="context-menu-item" onclick="showDetail(${orderId}, ['customer_short_name','go_no','style_no','jo_no','color_code','product_category','wash_type','sample_type','plan_qty','target_output','delivery_date','marker_date','cut_start_date','sewing_start_date','ah_date','sm_date','remark','order_status']); hideCMDContextMenu();">
            <span style="color: #2563eb;">📄</span> Details
        </div>
    `);
    
    // Show Marked button if status is not Marked
    if (actualStatus !== 'Marked') {
        menuItems.push('<div class="context-menu-separator"></div>');
        menuItems.push(`
            <div class="context-menu-item" onclick="markCMDone(${orderId}); hideCMDContextMenu();">
                <span style="color: #8b5cf6;">🔨</span> Mark as Marked
            </div>
        `);
    }
    
    contextMenu.innerHTML = menuItems.join('');
    
    // Hiển thị menu tại vị trí chuột
    contextMenu.style.display = 'block';
    contextMenu.style.left = e.pageX + 'px';
    contextMenu.style.top = e.pageY + 'px';
    
    // Đảm bảo menu không bị cắt bởi viewport
    const rect = contextMenu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
        contextMenu.style.left = (e.pageX - rect.width) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
        contextMenu.style.top = (e.pageY - rect.height) + 'px';
    }
}

/**
 * Ẩn context menu của CMD
 */
function hideCMDContextMenu(e) {
    const contextMenu = document.getElementById('cmd-context-menu');
    if (contextMenu && contextMenu.style.display === 'block') {
        if (e && contextMenu.contains(e.target)) {
            return;
        }
        contextMenu.style.display = 'none';
    }
}

/**
 * Đánh dấu đơn hàng đã Marked
 */
async function markCMDone(id) {
    await updateOrderSingleField(id, 'order_status', 'Marked');
    await renderTabCMD();
}

// Export functions
window.renderTabCMD = renderTabCMD;
window.markCMDone = markCMDone;
window.addCMDContextMenu = addCMDContextMenu;
window.handleCMDTableContextMenu = handleCMDTableContextMenu;
window.hideCMDContextMenu = hideCMDContextMenu;
