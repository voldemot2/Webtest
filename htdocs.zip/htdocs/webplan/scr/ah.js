// ah.js
// Quản lý logic và giao diện tab AH

/**
 * Render tab AH (Account holder - quản lý đơn hàng)
 */

function renderAHHeader() {
    const headerEl = document.getElementById('ah-header');
    
    // Kiểm tra xem element có tồn tại không
    if (!headerEl) {
        console.log('⚠️ AH header element not found');
        return;
    }
    
    headerEl.innerHTML = `
      <button id="btn-add-ah" class="btn-add-order" style="margin-bottom: 12px; position:relative;">➕ New Order</button>
      <button id="btn-add-multiple-ah" class="btn-add-order" style="margin-bottom: 12px; margin-left: 8px; position:relative; background: #059669;">📋 Add Multiple Orders</button>
      <input type="text" id="ah-search-box" placeholder="🔍 Search orders..."
          style="margin-left: 16px; padding: 6px; width: 280px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc;">
      <select id="status-filter" style="margin-left: 16px; padding: 6px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc;">
          <option value="Open,ReOpen">Open Orders</option>
          <option value="Submit,Loaded,Request">On Plan</option>
          <option value="Marked,Sewing,Check">Marked Orders</option>
      </select>
    `;
    // Các trường readonly ở tab AH
    const readonlyFields = ["marker_date", "cut_start_date", "sewing_start_date", "order_status", "target_output"];
    headerEl.querySelector('#btn-add-ah')?.addEventListener('click', () => showDetail(0, readonlyFields));
    headerEl.querySelector('#btn-add-multiple-ah')?.addEventListener('click', () => showMultipleOrderModal());

    // Add event listener for status filter changes
    const statusFilter = document.getElementById('status-filter');
    statusFilter.value = localStorage.getItem('ah-status-filter') || 'Open';
    statusFilter.addEventListener('change', async (e) => {
        localStorage.setItem('ah-status-filter', e.target.value);
        await renderTabAH();
    });

    // Add event for search box
    initSearch('ah-search-box', '#ah-table', 'tbody tr');
}

async function renderTabAH() {
    let orders = await fetchData('get_orders');
    // Get current filter value from localStorage or default to 'Open'
    const currentFilter = localStorage.getItem('ah-status-filter') || 'Open';
    const statusArray = currentFilter.split(',');
    orders = orders.filter(o => statusArray.includes(o.order_status));

    const listEl = document.getElementById('ah-list');
    
    // Kiểm tra xem element có tồn tại không
    if (!listEl) {
        console.log('⚠️ AH list element not found');
        return;
    }
    
    const isMarked = currentFilter === 'Marked,Sewing,Check';
    const isOnPlan = currentFilter === 'Submit,Loaded,Request';
    const isOpen = currentFilter === 'Open,ReOpen';
    const isReadonly = isMarked || isOnPlan;
    listEl.innerHTML = `
        <div id="ah-table-wrapper" style="height: auto; overflow: auto; position:relative;">
            <table id="ah-table" class="sticky-header-table" style="min-width:1100px;">
                <thead>
                  <tr>
                    <th class="filter-header" data-field="status">Status</th>
                    <th class="filter-header" data-field="buyer">Buyer</th>
                    <th class="filter-header" data-field="gono">GO no</th>
                    <th>Style</th>
                    <th>Job No</th>
                    <th>Color code</th>
                    <th>Product type</th>
                    <th>Qty</th>
                    <th>Sample Type</th>
                    <th>AH Date</th>
                    <th>Delivery Date</th>
                    <th>Remark</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  ${orders.map(o => `
                    <tr data-id="${o.id}">
                        <td><span class="order-status status-${(o.order_status||'').toLowerCase()}">${o.order_status||''}</span></td>
                        <td>${o.customer_short_name || ''}</td>
                        <td>${o.go_no || ''}</td>
                        <td>${o.style_no || ''}</td>
                        <td>${o.jo_no || ''}</td>
                        <td>${o.color_code || ''}</td>
                        <td>${o.product_category || ''}</td>
                        <td><input type="number" name="plan_qty" value="${o.plan_qty || ''}" onchange="updateOrderSingleField(${o.id}, 'plan_qty', this.value, {noRender:true})" style="width:50px" ${isReadonly ? 'readonly' : ''}></td>
                        <td><input type="text" name="sample_type" value="${o.sample_type || ''}" onchange="updateOrderSingleField(${o.id}, 'sample_type', this.value, {noRender:true})" style="width:100px" ${isReadonly ? 'readonly' : ''}></td>
                        <td><input type="date" name="ah_date" value="${o.ah_date ? new Date(o.ah_date).toISOString().split('T')[0] : ''}" onchange="updateOrderSingleField(${o.id}, 'ah_date', this.value, {noRender:true})" style="width:120px" ${isReadonly ? 'readonly' : ''}></td>
                        <td><input type="date" name="delivery_date" value="${o.delivery_date ? new Date(o.delivery_date).toISOString().split('T')[0] : ''}" onchange="updateOrderSingleField(${o.id}, 'delivery_date', this.value, {noRender:true})" style="width:120px" ${isReadonly ? 'readonly' : ''}></td>
                        <td><input type="text" value="${o.remark || ''}" onchange="updateOrderSingleField(${o.id}, 'remark', this.value, {noRender:true})" style="width:120px" ${isReadonly ? 'readonly' : ''}></td>
                        <td>
                            <div style="display:flex; flex-direction:column; gap:4px;">
                                ${isMarked
                                    ? `<span style='font-weight:bold; color: #059669;'>${o.order_status}</span>`
                                    : isOnPlan
                                        ? `<button type="button" onclick="changeOrderStatus(${o.id}, 'Request')" style="background: #f59e0b; padding:4px 8px; font-size:12px; color: white;">Request Open</button>`
                                        : `<button type="button" onclick="changeOrderStatus(${o.id}, 'Submit')" style="background: #2563eb; padding:4px 8px; font-size:12px;">Submit</button>`
                                }
                            </div>
                        </td>
                    </tr>
                  `).join('')}
                </tbody>
            </table>
        </div>
    `;
    
    // Thêm context menu cho AH table
    addAHContextMenu();
    
    // Khởi tạo filter cho bảng AH
    const tableFilter = {
        fieldGetters: {
            status: order => order.order_status || '',
            buyer: order => order.customer_short_name || '',
            gono: order => order.go_no || ''
        },
        getDataSource: async () => {
            try {
                // Lấy lại dữ liệu mới nhất và apply filter hiện tại
                let allOrders = await fetchData('get_orders');
                if (!Array.isArray(allOrders)) {
                    console.error('❌ fetchData did not return array:', allOrders);
                    return [];
                }
                
                const currentFilter = localStorage.getItem('ah-status-filter') || 'Open,ReOpen';
                const statusArray = currentFilter.split(',');
                const filteredOrders = allOrders.filter(o => statusArray.includes(o.order_status));
                
                return filteredOrders;
            } catch (error) {
                console.error('❌ Error in getDataSource:', error);
                return [];
            }
        }
    };
    
    // Đảm bảo DOM đã sẵn sàng trước khi khởi tạo filter
    setTimeout(() => {
        const ahTable = document.getElementById('ah-table');
        if (ahTable) {
            // Kiểm tra xem filter đã được khởi tạo chưa
            if (!ahTable.hasAttribute('data-filter-initialized')) {
                TableFilter.init('ah-table', tableFilter);
                ahTable.setAttribute('data-filter-initialized', 'true');
            }
        }
    }, 100);
}

/**
 * Tạo và thêm context menu cho bảng AH
 */
function addAHContextMenu() {
    // Tạo context menu HTML nếu chưa tồn tại
    let contextMenu = document.getElementById('ah-context-menu');
    if (!contextMenu) {
        contextMenu = document.createElement('div');
        contextMenu.id = 'ah-context-menu';
        contextMenu.className = 'context-menu';
        document.body.appendChild(contextMenu);
    }

    // Sử dụng event delegation để xử lý context menu
    const ahTable = document.getElementById('ah-table');
    if (ahTable) {
        // Xóa event listeners cũ nếu có
        ahTable.removeEventListener('contextmenu', handleAHTableContextMenu);
        
        // Thêm event listener mới với event delegation
        ahTable.addEventListener('contextmenu', handleAHTableContextMenu);
    }

    // Ẩn context menu khi click ra ngoài (chỉ thêm một lần)
    if (!document.body.hasAttribute('data-ah-context-listener')) {
        document.addEventListener('click', hideAHContextMenu);
        // Thêm event listener cho phím ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                hideAHContextMenu();
            }
        });
        document.body.setAttribute('data-ah-context-listener', 'true');
    }
}

/**
 * Xử lý sự kiện chuột phải trên bảng AH với event delegation
 */
function handleAHTableContextMenu(e) {
    // Tìm hàng tr gần nhất
    const row = e.target.closest('tbody tr');
    if (!row) return;
    
    e.preventDefault();
    
    const orderId = row.getAttribute('data-id');
    const currentFilter = localStorage.getItem('ah-status-filter') || 'Open,ReOpen';
    const isMarked = currentFilter === 'Marked,Sewing,Check';
    const isOnPlan = currentFilter === 'Submit,Loaded,Request';
    const isOpen = currentFilter === 'Open,ReOpen';
    
    // Lấy trạng thái thực tế của đơn hàng từ DOM
    const statusElement = row.querySelector('.order-status');
    const actualStatus = statusElement ? statusElement.textContent.trim() : '';
    
    if (!orderId) return;
    
    const contextMenu = document.getElementById('ah-context-menu');
    
    // Tạo nội dung menu
    let menuItems = [];
    
    if (isMarked) {
        // Menu cho đơn hàng Marked - chỉ có Chi tiết
        menuItems.push(`
            <div class="context-menu-item" onclick="showDetail(${orderId}, [
            'marker_date',
            'cut_start_date',
            'sewing_start_date',
            'order_status',
            'target_output',
            'customer_short_name',
            'go_no',
            'style_no',
            'jo_no',
            'color_code',
            'product_category',
            'plan_qty',
            'sample_type',
            'wash_type',
            'ah_date',
            'sm_date',
            'delivery_date'
            ]); hideAHContextMenu();">
            <span style="color: #2563eb;">📄</span> Chi tiết
            </div>
        `);
    } else if (isOnPlan) {
        // Menu cho đơn hàng On Plan - chỉ có Copy order và Request Open
        menuItems.push(`
            <div class="context-menu-item" onclick="showDetail(${orderId}, [
            'marker_date',
            'cut_start_date',
            'sewing_start_date',
            'order_status',
            'target_output',
            'customer_short_name',
            'go_no',
            'style_no',
            'jo_no',
            'color_code',
            'product_category',
            'plan_qty',
            'sample_type',
            'wash_type',
            'ah_date',
            'sm_date',
            'delivery_date'
            ]); hideAHContextMenu();">
            <span style="color: #2563eb;">📄</span> Chi tiết
            </div>
        `);
        menuItems.push(`
            <div class="context-menu-item" onclick="duplicateAHRow(${orderId}); hideAHContextMenu();">
                <span style="color: #1dd76e;">📋</span> Copy order
            </div>
        `);
        
        menuItems.push('<div class="context-menu-separator"></div>');
        
        menuItems.push(`
            <div class="context-menu-item" onclick="changeOrderStatus(${orderId}, 'Request'); hideAHContextMenu();">
                <span style="color: #f59e0b;">🔄</span> Request Open
            </div>
        `);
    } else {
        // Menu cho đơn hàng Open và ReOpen - đầy đủ chức năng
        menuItems.push(`
            <div class="context-menu-item" onclick="showDetail(${orderId}, ['marker_date','cut_start_date','sewing_start_date','order_status','target_output']); hideAHContextMenu();">
                <span style="color: #2563eb;">📄</span> Chi tiết
            </div>
        `);
        
        menuItems.push(`
            <div class="context-menu-item" onclick="duplicateAHRow(${orderId}); hideAHContextMenu();">
                <span style="color: #1dd76e;">📋</span> Copy order
            </div>
        `);
        
        menuItems.push('<div class="context-menu-separator"></div>');
        
        menuItems.push(`
            <div class="context-menu-item" onclick="changeOrderStatus(${orderId}, 'Submit'); hideAHContextMenu();">
                <span style="color: #2563eb;">✅</span> Submit
            </div>
        `);
        
        menuItems.push(`
            <div class="context-menu-item" onclick="changeOrderStatus(${orderId}, 'Cancel'); hideAHContextMenu();">
                <span style="color: #f87171;">❌</span> Cancel
            </div>
        `);
    }    contextMenu.innerHTML = menuItems.join('');
    
    // Hiển thị menu tại vị trí chuột
    contextMenu.style.display = 'block';
    contextMenu.style.left = e.pageX + 'px';
    contextMenu.style.top = e.pageY + 'px';
    
    // Đảm bảo menu không bị cắt bởi viewport
    const rect = contextMenu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
        contextMenu.style.left = (e.pageX - rect.width) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
        contextMenu.style.top = (e.pageY - rect.height) + 'px';
    }
}

/**
 * Ẩn context menu
 */
function hideAHContextMenu(e) {
    const contextMenu = document.getElementById('ah-context-menu');
    if (contextMenu && contextMenu.style.display === 'block') {
        // Nếu click vào context menu thì không ẩn
        if (e && contextMenu.contains(e.target)) {
            return;
        }
        contextMenu.style.display = 'none';
    }
}

/**
 * Hiển thị modal thêm đơn hàng hàng loạt
 */
function showMultipleOrderModal() {
    // Tạo modal HTML
    const modalHTML = `
        <div id="multiple-order-modal" class="modal" style="display: flex; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); align-items: center; justify-content: center;">
            <div class="modal-content" style="background-color: white; padding: 20px; border-radius: 8px; width: 95%; max-width: 1400px; max-height: 90%; overflow-y: auto; position: relative;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #e5e7eb; padding-bottom: 15px;">
                    <h2 style="margin: 0; color: #1f2937; font-size: 24px;">📋 Add Multiple Orders</h2>
                    <button onclick="closeMultipleOrderModal()" style="background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 16px;">✕ Close</button>
                </div>
                
                <div style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                    <input type="file" id="excel-file-input" accept=".xlsx,.xls,.csv" style="display: none;">
                    <button onclick="triggerFileImport()" style="background: #10b981; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">📁 Import from Excel</button>
                    <button onclick="downloadExcelTemplate()" style="background: #8b5cf6; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">📄 Download Template</button>
                    <button onclick="addNewRowToMultipleOrders()" style="background: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">➕ Add Row</button>
                    <button onclick="clearAllMultipleOrders()" style="background: #f59e0b; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">🗑️ Clear All</button>
                    <span style="margin-left: auto; font-weight: bold; color: #059669;">Selected: <span id="selected-count">0</span> orders</span>
                </div>
                
                <div id="multiple-orders-table-wrapper" style="border: 1px solid #e5e7eb; border-radius: 4px; overflow: auto; max-height: 400px;">
                    <table id="multiple-orders-table" style="width: 100%; border-collapse: collapse; min-width: 1200px;">
                        <thead style="background-color: #f8fafc; position: sticky; top: 0; z-index: 10;">
                            <tr>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; text-align: center; width: 50px;">
                                    <input type="checkbox" id="select-all-orders" onchange="toggleAllOrderSelection()" style="transform: scale(1.2);">
                                </th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 70px;">Buyer</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 80px;">GO No</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 100px;">Job No</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 100px;">Color Code</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 100px;">Style</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 70px;">Product Type</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 70px;">Wash Type</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 70px;">Sample Type</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 70px;">Plan Qty</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 100px;">AH Date</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; min-width: 100px;">Delivery Date</th>
                                <th style="border: 1px solid #e5e7eb; padding: 10px; width: 60px;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="multiple-orders-tbody">
                            <!-- Rows will be added here -->
                        </tbody>
                    </table>
                </div>
                
                <div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center; border-top: 2px solid #e5e7eb; padding-top: 15px;">
                    <div style="display: flex; gap: 10px;">
                        <button onclick="closeMultipleOrderModal()" style="background: #6b7280; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer;">Cancel</button>
                        <button onclick="saveMultipleOrders()" style="background: #059669; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold;">💾 Save Selected Orders</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Thêm modal vào body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Thêm event listener cho file input để tự động import khi chọn file
    const fileInput = document.getElementById('excel-file-input');
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                importFromExcel();
            }
        });
    }
    
    // Thêm 3 rows mặc định
    for (let i = 0; i < 3; i++) {
        addNewRowToMultipleOrders();
    }
    
    updateSelectedCount();
}

/**
 * Trigger file import dialog
 */
function triggerFileImport() {
    const fileInput = document.getElementById('excel-file-input');
    if (fileInput) {
        fileInput.click();
    }
}

/**
 * Đóng modal thêm đơn hàng hàng loạt
 */
function closeMultipleOrderModal() {
    const modal = document.getElementById('multiple-order-modal');
    if (modal) {
        modal.remove();
    }
}

/**
 * Thêm row mới vào bảng multiple orders
 */
function addNewRowToMultipleOrders() {
    const tbody = document.getElementById('multiple-orders-tbody');
    if (!tbody) return;
    
    const rowIndex = tbody.children.length;
    const today = new Date().toISOString().split('T')[0];
    
    const rowHTML = `
        <tr data-row-index="${rowIndex}">
            <td style="border: 1px solid #e5e7eb; padding: 8px; text-align: center;">
                <input type="checkbox" class="order-row-checkbox" onchange="updateSelectedCount()" style="transform: scale(1.2);">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="customer_short_name" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Enter buyer...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="go_no" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="GO number...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="jo_no" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Job number...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="color_code" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Color code...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="style_no" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Style number...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="product_category" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Product type...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="wash_type" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Wash type...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="text" name="sample_type" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Sample type...">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="number" name="plan_qty" style="width: 100%; border: none; padding: 4px; background: transparent;" placeholder="Qty..." min="1" value="1">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="date" name="ah_date" style="width: 100%; border: none; padding: 4px; background: transparent;" value="${today}">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px;">
                <input type="date" name="delivery_date" style="width: 100%; border: none; padding: 4px; background: transparent;">
            </td>
            <td style="border: 1px solid #e5e7eb; padding: 4px; text-align: center;">
                <button onclick="removeOrderRow(${rowIndex})" style="background: #ef4444; color: white; border: none; padding: 4px 8px; border-radius: 3px; cursor: pointer; font-size: 12px;">🗑️</button>
            </td>
        </tr>
    `;
    
    tbody.insertAdjacentHTML('beforeend', rowHTML);
}

/**
 * Xóa row khỏi bảng multiple orders
 */
function removeOrderRow(rowIndex) {
    const row = document.querySelector(`tr[data-row-index="${rowIndex}"]`);
    if (row) {
        row.remove();
        updateSelectedCount();
    }
}

/**
 * Toggle chọn tất cả orders
 */
function toggleAllOrderSelection() {
    const selectAllCheckbox = document.getElementById('select-all-orders');
    const orderCheckboxes = document.querySelectorAll('.order-row-checkbox');
    
    orderCheckboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });
    
    updateSelectedCount();
}

/**
 * Cập nhật số lượng orders được chọn
 */
function updateSelectedCount() {
    const selectedCheckboxes = document.querySelectorAll('.order-row-checkbox:checked');
    const countElement = document.getElementById('selected-count');
    if (countElement) {
        countElement.textContent = selectedCheckboxes.length;
    }
}

/**
 * Xóa tất cả orders trong bảng
 */
function clearAllMultipleOrders() {
    if (confirm('Are you sure you want to clear all orders?')) {
        clearMultipleOrdersTable();
    }
}

/**
 * Xóa tất cả orders trong bảng (không hỏi confirm)
 */
function clearMultipleOrdersTable() {
    const tbody = document.getElementById('multiple-orders-tbody');
    if (tbody) {
        tbody.innerHTML = '';
        
        // Reset checkbox "select all"
        const selectAllCheckbox = document.getElementById('select-all-orders');
        if (selectAllCheckbox) {
            selectAllCheckbox.checked = false;
        }
        
        updateSelectedCount();
    }
}

/**
 * Import orders từ Excel
 */
function importFromExcel() {
    const fileInput = document.getElementById('excel-file-input');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Please select an Excel file first!');
        return;
    }
    
    // Kiểm tra định dạng file
    const validExtensions = ['.xlsx', '.xls', '.csv'];
    const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
    
    if (!validExtensions.includes(fileExtension)) {
        alert('Please select a valid Excel file (.xlsx, .xls, or .csv)');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            // Sử dụng thư viện SheetJS để đọc Excel (cần import thư viện này)
            if (typeof XLSX === 'undefined') {
                // Fallback: đọc CSV đơn giản
                if (fileExtension === '.csv') {
                    parseCSVData(e.target.result);
                } else {
                    alert('Excel import requires XLSX library. Please use CSV format or add XLSX library to your project.');
                }
                return;
            }
            
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, {type: 'array'});
            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
            const jsonData = XLSX.utils.sheet_to_json(firstSheet, {header: 1});
            
            parseExcelData(jsonData);
            
        } catch (error) {
            console.error('Error reading Excel file:', error);
            alert('Error reading Excel file. Please check the file format.');
        } finally {
            // Reset file input để có thể import lại cùng file
            fileInput.value = '';
        }
    };
    
    if (fileExtension === '.csv') {
        reader.readAsText(file);
    } else {
        reader.readAsArrayBuffer(file);
    }
}

/**
 * Parse CSV data
 */
function parseCSVData(csvData) {
    const lines = csvData.split('\n');
    const data = lines.map(line => line.split(',').map(cell => cell.trim()));
    parseExcelData(data);
}

/**
 * Parse Excel/CSV data và populate vào bảng
 */
function parseExcelData(data) {
    if (!data || data.length < 2) {
        alert('No data found in the file or invalid format');
        return;
    }
    
    // Xóa dữ liệu hiện tại
    clearMultipleOrdersTable();
    
    // Bỏ qua header row (row đầu tiên)
    const dataRows = data.slice(1);
    
    dataRows.forEach((row, index) => {
        if (row.length > 0 && row.some(cell => cell && cell.toString().trim() !== '')) {
            addNewRowToMultipleOrders();
            
            // Lấy row vừa được tạo (row cuối cùng trong tbody)
            const tbody = document.getElementById('multiple-orders-tbody');
            const currentRow = tbody ? tbody.lastElementChild : null;
            
            if (currentRow) {
                // Map dữ liệu theo thứ tự columns: Buyer, GO, Job No, Color Code, Style, Product Type, Wash Type, Sample Type, Plan Qty, AH Date, Delivery Date
                const inputs = currentRow.querySelectorAll('input[type="text"], input[type="number"], input[type="date"]');
                
                const fieldMapping = [
                    'customer_short_name', 'go_no', 'jo_no', 'color_code', 'style_no', 
                    'product_category', 'wash_type', 'sample_type', 'plan_qty', 'ah_date', 'delivery_date'
                ];
                
                fieldMapping.forEach((fieldName, fieldIndex) => {
                    if (row[fieldIndex] && row[fieldIndex].toString().trim() !== '') {
                        const input = currentRow.querySelector(`input[name="${fieldName}"]`);
                        if (input) {
                            let value = row[fieldIndex].toString().trim();
                            
                            // Xử lý định dạng date
                            if (fieldName === 'ah_date' || fieldName === 'delivery_date') {
                                value = formatDateForInput(value);
                            }
                            
                            input.value = value;
                        }
                    }
                });
                
                // Tự động check checkbox cho row có dữ liệu
                const checkbox = currentRow.querySelector('.order-row-checkbox');
                if (checkbox) {
                    checkbox.checked = true;
                }
            }
        }
    });
    
    updateSelectedCount();
    
    // Hiển thị thông báo không thành công
    const importedRowsCount = dataRows.filter(row => 
        row.length > 0 && row.some(cell => cell && cell.toString().trim() !== '')
    ).length;

    if (importedRowsCount === 0) {

        alert('⚠️ No valid data rows found in the Excel file.');
    }
}

/**
 * Format date cho input date - hỗ trợ nhiều định dạng
 */
function formatDateForInput(dateStr) {
    if (!dateStr) return '';
    
    // Convert to string and trim whitespace
    const cleanDateStr = dateStr.toString().trim();
    
    try {
        // Thử parse nhiều định dạng date khác nhau
        let date;
        
        // Kiểm tra nếu là Excel serial date (số thuần túy)
        if (!isNaN(cleanDateStr) && !cleanDateStr.includes('/') && !cleanDateStr.includes('-')) {
            const serialNumber = parseFloat(cleanDateStr);
            
            // Excel serial dates thường từ 1 (1900-01-01) đến khoảng 50000+ (tương ứng với năm 2030+)
            if (serialNumber > 0 && serialNumber < 100000) {
                // Excel epoch: January 1, 1900 (nhưng Excel tính sai leap year 1900)
                // JavaScript epoch: January 1, 1970
                // Excel serial date 1 = January 1, 1900
                // Nhưng Excel có bug: nó nghĩ 1900 là leap year
                
                const excelEpoch = new Date(1899, 11, 30); // December 30, 1899
                date = new Date(excelEpoch.getTime() + (serialNumber * 24 * 60 * 60 * 1000));
            }
        }
        // Định dạng MM/DD/YYYY hoặc DD/MM/YYYY hoặc M/D/YYYY hoặc D/M/YYYY (với hoặc không có số 0 đứng trước)
        // Hoặc MM-DD-YYYY hoặc DD-MM-YYYY hoặc M-D-YYYY hoặc D-M-YYYY
        else if (cleanDateStr.includes('/') || cleanDateStr.includes('-')) {
            const separator = cleanDateStr.includes('/') ? '/' : '-';
            const parts = cleanDateStr.split(separator);
            
            if (parts.length === 3) {
                // Parse và làm sạch các phần
                const part1 = parseInt(parts[0].trim());
                const part2 = parseInt(parts[1].trim());
                const year = parseInt(parts[2].trim());
                
                // Validate year first (hỗ trợ cả 2 và 4 chữ số)
                let fullYear = year;
                if (year >= 0 && year <= 99) {
                    // Convert 2-digit year to 4-digit
                    fullYear = year >= 50 ? 1900 + year : 2000 + year;
                }
                
                if (fullYear < 1900 || fullYear > 2100) {
                    return '';
                }
                
                // Smart detection of MM/DD/YYYY vs DD/MM/YYYY
                let month, day;
                
                // If first part > 12, it must be DD/MM/YYYY
                if (part1 > 12) {
                    day = part1;
                    month = part2;
                } 
                // If second part > 12, it must be MM/DD/YYYY
                else if (part2 > 12) {
                    month = part1;
                    day = part2;
                }
                // If both <= 12, assume MM/DD/YYYY (Excel default)
                else {
                    month = part1;
                    day = part2;
                }
                
                // Validate month and day ranges
                if (month < 1 || month > 12 || day < 1 || day > 31) {
                    return '';
                }
                
                date = new Date(fullYear, month - 1, day);
                
                // Double check the date is valid (handles invalid dates like 2/30/2024)
                if (date.getFullYear() === fullYear && 
                    date.getMonth() === month - 1 && 
                    date.getDate() === day) {
                    // Valid date
                } else {
                    date = null;
                }
            } else {
                // Invalid date format
            }
        } else {
            // Thử parse trực tiếp (cho các format khác như ISO: YYYY-MM-DD)
            date = new Date(cleanDateStr);
        }
        
        if (date && !isNaN(date.getTime())) {
            return date.toISOString().split('T')[0];
        }
    } catch (error) {
        // Error parsing date
    }
    
    return '';
}

/**
 * Lưu các orders được chọn
 */
async function saveMultipleOrders() {
    const selectedRows = document.querySelectorAll('.order-row-checkbox:checked');
    
    if (selectedRows.length === 0) {
        alert('Please select at least one order to save!');
        return;
    }
    
    const ordersToSave = [];
    let hasErrors = false;
    const errors = [];
    
    selectedRows.forEach((checkbox, index) => {
        const row = checkbox.closest('tr');
        const inputs = row.querySelectorAll('input[type="text"], input[type="number"], input[type="date"]');
        
        const orderData = {};
        inputs.forEach(input => {
            if (input.name) {
                orderData[input.name] = input.value.trim();
            }
        });
        
        // Validation cơ bản
        const requiredFields = ['customer_short_name', 'go_no', 'style_no'];
        const missingFields = requiredFields.filter(field => !orderData[field]);
        
        if (missingFields.length > 0) {
            hasErrors = true;
            errors.push(`Row ${index + 1}: Missing required fields: ${missingFields.join(', ')}`);
        } else {
            // Thêm các trường mặc định
            orderData.order_status = 'Open';
            orderData.created_by = 'AH'; // Hoặc lấy từ session user
            orderData.display_order = 0; // Default display order
            
            // Đảm bảo các trường số hợp lệ với giá trị mặc định
            if (!orderData.plan_qty || orderData.plan_qty === '') {
                orderData.plan_qty = 1; // Mặc định là 1
            } else {
                orderData.plan_qty = parseInt(orderData.plan_qty) || 1;
            }
            
            // target_output luôn mặc định là 1 (người dùng không được nhập)
            orderData.target_output = 1;
            
            // Đảm bảo các trường không required có giá trị mặc định
            const optionalFields = ['jo_no', 'color_code', 'product_category', 'wash_type', 'sample_type', 'remark'];
            optionalFields.forEach(field => {
                if (!orderData[field]) {
                    orderData[field] = null;
                }
            });
            
            // Đảm bảo date fields được xử lý đúng
            ['ah_date', 'delivery_date', 'marker_date', 'cut_start_date', 'sewing_start_date', 'sm_date'].forEach(field => {
                if (!orderData[field]) {
                    orderData[field] = null;
                }
            });
            
            ordersToSave.push(orderData);
        }
    });
    
    if (hasErrors) {
        alert('Please fix the following errors:\n\n' + errors.join('\n'));
        return;
    }
    
    // Hiển thị loading
    const saveButton = event.target;
    const originalText = saveButton.textContent;
    saveButton.textContent = '💾 Saving...';
    saveButton.disabled = true;
    
    try {
        // Gọi API để lưu orders
        const requestBody = {
            action: 'save_multiple_orders',
            orders: ordersToSave
        };
        
        const response = await fetch('process.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(`Successfully saved ${result.created_count || ordersToSave.length} orders!`);
            closeMultipleOrderModal();
            // Refresh lại tab AH
            await renderTabAH();
        } else {
            alert('Error saving orders: ' + (result.error || result.message || 'Unknown error'));
        }
        
    } catch (error) {
        alert('Error saving orders. Please try again.');
    } finally {
        saveButton.textContent = originalText;
        saveButton.disabled = false;
    }
}

/**
 * Download Excel template file
 */
function downloadExcelTemplate() {
    // Tạo workbook mới
    const wb = XLSX.utils.book_new();
    
    // Tạo header data
    const headers = [
        'Buyer', 'GO No', 'Job No', 'Color Code', 'Style', 
        'Product Type', 'Wash Type', 'Sample Type', 'Plan Qty', 
        'AH Date', 'Delivery Date'
    ];
    
    // Tạo sample data với nhiều định dạng ngày tháng
    const sampleData = [
        headers,
        ['NIKE', 'GO001', 'JOB001', 'RED', 'T-SHIRT', 'GARMENT', 'STONE WASH', 'PP', '1000', '02/01/2024', '03/01/2024'],
        ['ADIDAS', 'GO002', 'JOB002', 'BLUE', 'SHORTS', 'GARMENT', 'NORMAL', 'SMS', '500', '2/5/2024', '3/5/2024'],
        ['PUMA', 'GO003', 'JOB003', 'BLACK', 'HOODIE', 'GARMENT', 'ENZYME', 'TOP', '750', '3/25/2025', '4/25/2025']
    ];
    
    // Tạo worksheet
    const ws = XLSX.utils.aoa_to_sheet(sampleData);
    
    // Thiết lập độ rộng cột
    ws['!cols'] = [
        { width: 15 }, // Buyer
        { width: 12 }, // GO No
        { width: 12 }, // Job No
        { width: 12 }, // Color Code
        { width: 15 }, // Style
        { width: 15 }, // Product Type
        { width: 12 }, // Wash Type
        { width: 12 }, // Sample Type
        { width: 10 }, // Plan Qty
        { width: 12 }, // AH Date
        { width: 12 }  // Delivery Date
    ];
    
    // Thiết lập style cho header
    const headerRange = XLSX.utils.decode_range(ws['!ref']);
    for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
        const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
        if (!ws[cellAddress]) continue;
        
        ws[cellAddress].s = {
            font: { bold: true },
            fill: { fgColor: { rgb: "E3F2FD" } },
            alignment: { horizontal: "center" }
        };
    }
    
    // Thêm worksheet vào workbook
    XLSX.utils.book_append_sheet(wb, ws, "Orders Template");
    
    // Tạo file và download
    const fileName = `Orders_Template_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    // Hiển thị thông báo hướng dẫn
    setTimeout(() => {
        alert('📄 Excel template downloaded successfully!\n\n' +
              '📋 Instructions:\n' +
              '1. Fill in your order data in the template\n' +
              '2. Keep the header row intact\n' +
              '3. Date formats supported:\n' +
              '   • MM/DD/YYYY (02/01/2024)\n' +
              '   • M/D/YYYY (3/25/2025)\n' +
              '   • DD/MM/YYYY (25/03/2025)\n' +
              '   • YYYY-MM-DD (2024-02-01)\n' +
              '   • Excel serial dates (auto-detected)\n' +
              '4. Required fields: Buyer, GO No, Style\n' +
              '5. Import the file back using "Import from Excel" button');
    }, 500);
}