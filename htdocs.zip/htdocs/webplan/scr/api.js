// api.js
// Chứa các hàm gọi API backend và các hàm tiện ích chung

/**
 * Gọi API tới process.php với action và method tương ứng
 * @param {string} action - Tên action backend
 * @param {string} method - Phương thức HTTP (GET/POST)
 * @param {object|string|FormData|null} body - Dữ liệu gửi đi
 * @returns {Promise<any>} - Kết quả trả về dạng JSON
 */
async function fetchData(action, method = 'GET', body = null) {
    try {
        const options = { method };
        if (body) {
            if (method === 'POST' && body instanceof FormData) {
                options.body = body;
            } else if (method === 'POST' && typeof body === 'object') {
                options.headers = { 'Content-Type': 'application/json' };
                options.body = JSON.stringify(body);
            } else if (method === 'POST' && typeof body === 'string') {
                options.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
                options.body = body;
            }
        }
        
        const res = await fetch(`process.php?action=${action}`, options);
        const text = await res.text();
        
        // Debug log để kiểm tra response
        if (window.location.hostname === 'localhost' || window.location.hostname.includes('192.168')) {
            console.log(`API ${action}:`, text.substring(0, 200));
        }
        
        // Kiểm tra nếu response không phải JSON
        if (!text.trim().startsWith('{') && !text.trim().startsWith('[')) {
            throw new Error(`Invalid JSON response: ${text.substring(0, 100)}...`);
        }
        
        return JSON.parse(text);
        
    } catch (error) {
        console.error(`API Error for ${action}:`, error);
        
        // Trả về error object thay vì throw
        return {
            error: true,
            message: error.message,
            action: action
        };
    }
}

/**
 * Lấy activity logs với filter parameters
 * @param {object} filters - Object chứa các filter: page, limit, order_id, user_id, action, date_from, date_to
 * @returns {Promise<object>} - Kết quả chứa logs, total, page info
 */
async function fetchActivityLogs(filters = {}) {
    const params = new URLSearchParams();
    
    // Default values
    params.append('page', filters.page || 1);
    params.append('limit', filters.limit || 50);
    
    // Optional filters
    if (filters.order_id) params.append('order_id', filters.order_id);
    if (filters.user_id) params.append('user_id', filters.user_id);
    if (filters.action) params.append('action_filter', filters.action); // Đổi thành action_filter
    if (filters.date_from) params.append('date_from', filters.date_from);
    if (filters.date_to) params.append('date_to', filters.date_to);
    
    try {
        const response = await fetch(`process.php?action=get_activity_logs&${params.toString()}`);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Failed to fetch activity logs');
        }
        
        return data;
    } catch (error) {
        console.error('Error fetching activity logs:', error);
        return {
            error: true,
            message: error.message,
            logs: [],
            total: 0
        };
    }
}

/**
 * Định dạng ngày theo MM/DD/YY
 * @param {string} dateStr
 * @returns {string}
 */
function formatDateMDY(dateStr) {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    if (isNaN(d)) return dateStr;
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const yy = String(d.getFullYear()).slice(-2);
    return `${mm}/${dd}/${yy}`;
}

/**
 * Tính toán các ngày sản xuất cho một đơn hàng
 * @param {object} order
 * @returns {Array<{date: string, qty: number}>}
 */
function getOrderPlanDays(order) {
    const res = [];
    let planQty = Number(order.plan_qty);
    const target = Number(order.target_output);
    const start = new Date(order.sewing_start_date);
    let remain = planQty;
    const cur = new Date(start);

    if (isNaN(start.getTime())) {
        return res;
    }

    while (remain > 0) {
        if (cur.getDay() !== 0) {
            const dateStr = cur.toISOString().slice(0, 10);
            const qty = Math.min(target, remain);
            res.push({ date: dateStr, qty });
            remain -= qty;
        }
        cur.setDate(cur.getDate() + 1);
    }
    return res;
}

/**
 * Tính ngày kết thúc may của đơn hàng
 * @param {object} order
 * @returns {string}
 */
function calcEndSew(order) {
    const days = getOrderPlanDays(order);
    return days.length ? formatDateShort(days[days.length - 1].date) : '';
}

/**
 * Lấy dải ngày chung cho tất cả đơn hàng
 * @param {Array<object>} orders
 * @returns {Array<string>}
 */
function getDateRange(orders) {
    let minDate = null, maxDate = null;
    for (const o of orders) {
        const days = getOrderPlanDays(o);
        if (days.length > 0) {
            const start = new Date(days[0].date);
            const end = new Date(days[days.length - 1].date);
            if (!minDate || start < minDate) minDate = start;
            if (!maxDate || end > maxDate) maxDate = end;
        }
    }

    const dates = [];
    if (!minDate || !maxDate) return dates;

    // Mở rộng thêm 7 ngày trước và sau
    minDate.setDate(minDate.getDate() - 3);
    maxDate.setDate(maxDate.getDate() + 7);

    const d = new Date(minDate);
    while (d <= maxDate) {
        dates.push(d.toISOString().slice(0, 10));
        d.setDate(d.getDate() + 1);
    }
    return dates;
}

// Export các hàm để file khác sử dụng
window.fetchData = fetchData;
window.formatDateMDY = formatDateMDY;
window.getOrderPlanDays = getOrderPlanDays;
window.calcEndSew = calcEndSew;
window.getDateRange = getDateRange;