// sm.js
// Quản lý logic và giao diện tab SM

/**
 * Render tab SM (Sub material Phụ Liệu)
 */
async function renderTabSM() {
    const headerEl = document.getElementById('sm-header');
    const listEl = document.getElementById('sm-list');
    
    // Kiểm tra xem các element có tồn tại không
    if (!headerEl || !listEl) {
        console.log('⚠️ SM elements not found');
        return;
    }
    
    headerEl.innerHTML = `
        <input type="text" id="sm-search-box" placeholder="🔍 Search orders..."
            style="margin-bottom: 12px; padding: 6px; width: 280px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc;">
    `;

    let orders = await fetchData('get_orders');
    orders = orders.filter(o => o.order_status === "Submit");

    listEl.innerHTML = `
        <div id="sm-table-wrapper" style="height:auto; overflow:auto; position:relative;">
            <table id="sm-table" class="sticky-header-table" style="min-width:1100px;">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>GO No</th>
                        <th>Style</th>
                        <th>Job No</th>
                        <th>Color Code</th>
                        <th>Product Type</th>
                        <th>Wash Type</th>
                        <th>Quantity</th>
                        <th>Sample Type</th>
                        <th>AH Date</th>
                        <th>SM Date</th>
                        <th>Delivery Date</th>
                        <th>Remark</th>
                    </tr>
                </thead>
                <tbody>
                    ${orders.map(o => `
                        <tr data-id="${o.id}">
                            <td>${o.customer_short_name || ''}</td>
                            <td>${o.go_no || ''}</td>
                            <td>${o.style_no || ''}</td>
                            <td>${o.jo_no || ''}</td>
                            <td>${o.color_code || ''}</td>
                            <td>${o.product_category || ''}</td>
                            <td>${o.wash_type || ''}</td>
                            <td>${o.plan_qty || ''}</td>
                            <td>${o.sample_type || ''}</td>
                            <td>${o.ah_date ? formatDateShort(o.ah_date) : ''}</td>
                            <td><input type="date" value="${o.sm_date || ''}" onchange="updateOrderSingleField(${o.id}, 'sm_date', this.value, {noRender:true})" style="width:130px"></td>
                            <td>${o.delivery_date ? formatDateShort(o.delivery_date) : ''}</td>
                            <td><input type="text" value="${o.remark || ''}" onchange="updateOrderSingleField(${o.id}, 'remark', this.value, {noRender:true})" style="width:220px"></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;

    initSearch('sm-search-box', '#sm-table', 'tbody tr');
}

// Export các hàm để file khác sử dụng
window.renderTabSM = renderTabSM; 