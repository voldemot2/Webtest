// plan.js
// Quản lý logic và giao diện kế hoạch sản xuất (tab Kế hoạch)

/**
 * So sánh ngày ở định dạng YYYY-MM-DD hoặc MM/DD/YY
 * @param {string} date1
 * @param {string} date2
 * @returns {number} -1 if date1 < date2, 0 if equal, 1 if date1 > date2
 */
function compareDates(date1, date2) {
    // Ensure we have valid dates
    if (!date1 || !date2) return 0;
    
    // Convert MM/DD/YY to YYYY-MM-DD for comparison
    const parseDate = (str) => {
        const match = str.match(/^(\d{2})\/(\d{2})\/(\d{2})$/);
        if (match) {
            // If MM/DD/YY format
            return `20${match[3]}-${match[1]}-${match[2]}`;
        }
        // If already YYYY-MM-DD format
        return str;
    };
    
    const d1 = parseDate(date1);
    const d2 = parseDate(date2);
    
    // Compare as strings in YYYY-MM-DD format
    if (d1 < d2) return -1;
    if (d1 > d2) return 1;
    return 0;
}

/**
 * Kiểm tra xem một ngày có phải là ngày hiện tại không (chỉ so sánh ngày tháng)
 * @param {string} dateStr - Ngày ở định dạng YYYY-MM-DD
 * @returns {boolean}
 */
function isToday(dateStr) {
    const today = new Date();
    const date = new Date(dateStr);
    return date.getDate() === today.getDate() && 
           date.getMonth() === today.getMonth() && 
           date.getFullYear() === today.getFullYear();
}

let globalDateArr = [];

// Filter module sẽ được load từ index.php

/**
 * Render bảng kế hoạch sản xuất (ma trận)
 */
async function renderMatrix() {
    const container = document.getElementById('orders-list');
    
    // Kiểm tra xem element có tồn tại không (user có thể không có permission planning)
    if (!container) {
        console.log('⚠️ Planning tab not available for current user');
        return;
    }
    
    const prevScrollWrapper = container.querySelector('#plan-table-wrapper');
    const prevScrollLeft = prevScrollWrapper?.scrollLeft || 0;
    const prevScrollTop = prevScrollWrapper?.scrollTop || 0;

    let orders = await fetchData('get_orders');
    const submitCount = orders.filter(o => o.order_status === "Submit").length;
    const requestCount = orders.filter(o => o.order_status === "Request").length;
    orders = orders.filter(o => o.order_status === "Loaded" || o.order_status === "Marked" || o.order_status === "Check" || o.order_status === "Sewing");

    globalDateArr = getDateRange(orders);

    // Header
    const headerEl = document.getElementById('orders-header');
    headerEl.innerHTML = `
        <button id="btn-add-order" class="btn-add-order" style="margin-bottom: 12px; position:relative;">
            ➕ New Order
            <span id="badge-submit" class="badge-submit"${submitCount > 0 ? '' : ' style="display:none"'}>${submitCount}</span>
        </button>
        <button id="btn-request-open" class="btn-request-open" style="margin-bottom: 12px; margin-left: 8px; position:relative;">
            🔄 Request Open
            <span id="badge-request" class="badge-request"${requestCount > 0 ? '' : ' style="display:none"'}>${requestCount}</span>
        </button>
        <input type="text" id="search-box" placeholder="🔍 Search orders..." style="margin-left: 16px; padding: 6px; width: 280px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc;">
    `;
    headerEl.querySelector('#btn-add-order')?.addEventListener('click', showSubmittedOrdersPopup);
    headerEl.querySelector('#btn-request-open')?.addEventListener('click', showRequestOrdersPopup);

    // Table HTML
    let html = `
    <div id="plan-table-wrapper" style="max-height:75vh;overflow:auto;position:relative;">
        <table id="orders-table">
            <thead>
                <tr>
                    <th style="width: 30px;">⋮⋮</th>
                    <th class="filter-header" data-field="status">Status</th>
                    <th class="filter-header" data-field="customer">Customer</th>
                    <th class="filter-header" data-field="gono">GO No</th>
                    <th class="filter-header" data-field="style">Style</th>
                    <th class="filter-header" data-field="sample">Sample</th>
                    <th>Plan Qty</th>
                    <th>Daily Qty</th>
                    <th>Marker Date</th>
                    <th>Sewing Start</th>
                    
                    <th>Sewing End</th>
                    <th>Delivery Date</th>
                    ${globalDateArr.map(date => {
                        const d = new Date(date);
                        const isSunday = d.getDay() === 0;
                        const isCurrentDay = isToday(date);
                        const className = ["col-date"]
                            .concat(isSunday ? ["sunday"] : [])
                            .concat(isCurrentDay ? ["today"] : [])
                            .join(" ");
                        // Hiển thị MM/DD cho các cột kế hoạch hàng ngày
                        const [yyyy, mm, dd] = date.split('-');
                        return `<th class="${className}">${mm}/${dd}</th>`;
                    }).join('')}
                </tr>
            </thead>
            <tbody>`;

    for (const o of orders) {
        const endSew = calcEndSew(o);
        const delivery = o.delivery_date || '';
        const warning = (endSew && delivery && compareDates(endSew, delivery) > 0) ? 'danger' : '';
        const planDays = getOrderPlanDays(o);
        const firstPlanDay = planDays[0]?.date;
        const lastPlanDay = planDays[planDays.length - 1]?.date;

        html += `<tr class="order-row" data-id="${o.id}">
            <td class="drag-handle" style="text-align: center; cursor: grab; user-select: none; font-size: 16px " title="Drag to reorder" onmousedown="this.style.cursor='grabbing'" onmouseup="this.style.cursor='grab'">⋮⋮</td>
            <td><span class="order-status status-${(o.order_status||'').toLowerCase()}">${o.order_status||''}</span></td>
            <td>${o.customer_short_name}</td>
            <td>${o.go_no}</td>
            <td>${o.style_no}</td>
            <td>${o.sample_type || ''}</td>
            <td><input type="number" value="${o.plan_qty}" min="1" onchange="updateOrderSingleField(${o.id},'plan_qty',this.value)" style="width:70px"></td>
            <td><input type="number" value="${o.target_output}" min="1" onchange="updateOrderSingleField(${o.id},'target_output',this.value)" style="width:70px"></td>
            <td><input type="date" value="${o.marker_date || ''}" onchange="updateOrderSingleField(${o.id},'marker_date',this.value)" style="width:130px"></td>
            <td><input type="date" value="${o.sewing_start_date}" onchange="handleSewingStartDateChange(${o.id}, this.value)" style="width:130px"></td>
            <td class="${warning}">${endSew}</td>
            <td>${delivery ? formatDateShort(delivery) : ''}</td>`;

        for (const date of globalDateArr) {
            const isCurrentDay = isToday(date);
            if (!firstPlanDay || !lastPlanDay) {
                html += `<td class="${isCurrentDay ? 'today' : ''}"></td>`;
                continue;
            }
            if (date === firstPlanDay) {
                const span = (new Date(lastPlanDay) - new Date(firstPlanDay)) / (1000 * 60 * 60 * 24) + 1;
                const isLate = endSew && delivery && compareDates(endSew, delivery) > 0;
                const stripClass = `strip-bar${isLate ? " late" : ""}`;
                // Chuyển ngày từ MM/DD/YY về YYYY-MM-DD để tính toán
                const convertToDate = (str) => {
                    const match = str.match(/^(\d{2})\/(\d{2})\/(\d{2})$/);
                    if (match) {
                        return new Date(`20${match[3]}-${match[1]}-${match[2]}`);
                    }
                    return new Date(str);
                };
                const lateDays = isLate ? Math.ceil((convertToDate(endSew) - convertToDate(delivery)) / (1000 * 60 * 60 * 24)) : 0;
                let tooltip = `${o.customer_short_name} | ${o.go_no} | ${o.sample_type || ''} | ${o.plan_qty} pcs`;
                if (isLate) {
                    tooltip += ` | Delay ${lateDays} Day${lateDays > 1 ? 's' : ''}`;
                }
                html += `<td colspan="${span}" class="date-cell">
                    <div class="${stripClass}" data-id="${o.id}" data-start="${firstPlanDay}" data-tooltip="${tooltip}">
                        ${o.go_no }
                    </div>
                </td>`;
            } else if (date > firstPlanDay && date <= lastPlanDay) {
                // skip
            } else {
                html += `<td class="${isToday(date) ? 'today' : ''} col-date"></td>`;
            }
        }
        html += `</tr>`;
    }
    html += `</tbody></table></div>`;
    container.innerHTML = html;

    // Restore scroll position
    const newScroll = container.querySelector('#plan-table-wrapper');
    if (newScroll) {
        newScroll.scrollLeft = prevScrollLeft;
        newScroll.scrollTop = prevScrollTop;
    }

    // Khởi tạo search và các tính năng khác
    initSearch('search-box', '#orders-table', '.order-row');
    initDraggable();
    initRowSortable();
    addPlanContextMenu();
    
    // Khởi tạo filter cho bảng orders
    const tableFilter = {
        fieldGetters: {
            status: order => order.order_status || '',
            customer: order => order.customer_short_name || '',
            gono: order => order.go_no || '',
            style: order => order.style_no || '',
            sample: order => order.sample_type || ''
        },
        getDataSource: async () => {
            // Trả về đúng danh sách orders đã lọc, đang hiển thị trên bảng
            return orders || [];
        }
    };
    TableFilter.init('orders-table', tableFilter);
}

/**
 * Xử lý khi thay đổi ngày bắt đầu may
 * @param {number|string} orderId
 * @param {string} value
 */
async function handleSewingStartDateChange(orderId, value) {
    if (!value) {
        await updateOrderSingleField(orderId, 'sewing_start_date', value);
        return;
    }
    const sewDate = new Date(value);
    const markerDate = new Date(sewDate);
    const cutDate = new Date(sewDate);
    markerDate.setDate(sewDate.getDate() - 6);
    cutDate.setDate(sewDate.getDate() - 3);

    await updateOrderMultipleFields(orderId, {
        sewing_start_date: value,
        marker_date: markerDate.toISOString().slice(0, 10),
        cut_start_date: cutDate.toISOString().slice(0, 10)
    });
}

/**
 * Khởi tạo kéo thả strip-bar trên bảng kế hoạch
 */
function initDraggable() {
    document.querySelectorAll('.strip-bar').forEach(div => {
        div.style.transform = '';
        div.setAttribute('data-x', 0);
    });

    interact('.strip-bar').draggable({
        listeners: {
            move(event) {
                const x = (parseFloat(event.target.getAttribute('data-x')) || 0) + event.dx;
                event.target.style.transform = `translate(${x}px, 0px)`;
                event.target.setAttribute('data-x', x);
            },
            async end(event) {
                const orderId = event.target.getAttribute('data-id');
                const startDate = event.target.getAttribute('data-start');
                const x = parseFloat(event.target.getAttribute('data-x')) || 0;
                // Lấy chiều rộng thực tế của cột ngày
                const col = document.querySelector('.col-date');
                const colWidth = col ? col.offsetWidth : 70;
                const daysMoved = Math.round(x / colWidth); // tự động theo chiều rộng cột

                const newDate = new Date(startDate);
                newDate.setDate(newDate.getDate() + daysMoved);
                const newStr = newDate.toISOString().slice(0, 10);

                // Nếu không thay đổi ngày, reset transform về 0
                if (newStr === startDate) {
                    event.target.style.transform = '';
                    event.target.setAttribute('data-x', 0);
                } else {
                    // Nếu có thay đổi ngày, chỉ render lại dòng, không reset transform (DOM sẽ tự cập nhật strip đúng vị trí)
                    const sewDate = new Date(newStr);
                    const markerDate = new Date(sewDate);
                    const cutDate = new Date(sewDate);
                    markerDate.setDate(sewDate.getDate() - 6);
                    cutDate.setDate(sewDate.getDate() - 3);
                    await updateOrderMultipleFields(orderId, {
                        sewing_start_date: newStr,
                        marker_date: markerDate.toISOString().slice(0, 10),
                        cut_start_date: cutDate.toISOString().slice(0, 10)
                    }, { noRender: true });
                    await renderOrderRow(orderId);
                }
            }
        }
    });
}

/**
 * Khởi tạo sortable cho các dòng đơn hàng trong bảng kế hoạch
 */
function initRowSortable() {
    const tableBody = document.querySelector("#orders-table tbody");
    if (!tableBody) return;

    Sortable.create(tableBody, {
        handle: ".drag-handle",        // Chỉ cho phép kéo qua handle (nút 3 gạch)
        animation: 150,
        ghostClass: "sortable-ghost",
        filter: ".strip-bar",
        preventOnFilter: false,
        onEnd: async function () {
            const rows = Array.from(document.querySelectorAll(".order-row"));
            const newOrderIds = rows.map(r => r.dataset.id);
            await fetchData('update_order_sequence', 'POST', newOrderIds);
            renderMatrix();
        }
    });
}

/**
 * Hiển thị popup chọn đơn hàng đã Submit để thêm vào kế hoạch
 */
async function showSubmittedOrdersPopup() {
    let orders = await fetchData('get_orders');
    const submitted = orders.filter(o => o.order_status === 'Submit');
    const loadedOrders = orders.filter(o => o.order_status === 'Loaded' || o.order_status === 'Check' || o.order_status === 'Submit');
    
    if (submitted.length === 0) {
        alert('No orders in Submit status!');
        return;
    }

    // Hàm tính số đơn hàng có cùng marker date
    const getOrdersOnPlan = (markerDate) => {
        if (!markerDate) return 0;
        return loadedOrders.filter(order => order.marker_date === markerDate).length;
    };

    let html = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin: 0;">Submitted Orders</h3>
        <button type="button" onclick="hideModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666; padding: 4px; border-radius: 4px;" onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='none'">&times;</button>
    </div>
    <div style="min-height:450px;overflow:auto;">
    <table class="sticky-header-table" id="table-select-submit" style="min-width:1050px;">
        <thead>
            <tr>
                <th><input type="checkbox" id="select-all-submit"></th>
                <th>Customer</th>
                <th>GO No</th>
                <th>Style</th>
                <th>Sample</th>
                <th>Qty</th>
                <th>Daily Output</th>
                <th>AH Date</th>
                <th>SM Date</th>
                <th>Marker Date</th>
                <th>Order on Plan</th>
                <th>Delivery</th>
            </tr>
        </thead>
        <tbody>`;
    for (const o of submitted) {
        const ordersOnPlan = getOrdersOnPlan(o.marker_date);
        html += `<tr data-id="${o.id}">
            <td><input type="checkbox" class="chk-submit-order" value="${o.id}"></td>
            <td>${o.customer_short_name || ''}</td>
            <td>${o.go_no || ''}</td>
            <td>${o.style_no || ''}</td>
            <td>${o.sample_type || ''}</td>
            <td>${o.plan_qty || ''}</td>
            <td>
                <input type="number" class="input-target-output" data-id="${o.id}" value="${o.target_output || 1}" min="1" style="width: 70px">
            </td>
            <td>${o.ah_date ? formatDateShort(o.ah_date) : ''}</td>
            <td>${o.sm_date ? formatDateShort(o.sm_date) : ''}</td>
            <td>
                <input type="date" class="input-marker-date" data-id="${o.id}" value="${o.marker_date || ''}">
            </td>
            <td class="order-on-plan-count" data-id="${o.id}" style="text-align: center; font-weight: bold; ${ordersOnPlan > 0 ? 'color: orange;' : 'color: green;'}">${ordersOnPlan}</td>
            <td>${o.delivery_date ? formatDateShort(o.delivery_date) : ''}</td>
        </tr>`;
    }
    html += `</tbody></table></div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px">
            <button type="button" onclick="hideModal()">Close</button>
            <button type="button" id="btn-add-to-kehoach">Add to Plan</button>
        </div>
    `;
    showModal(html);

    document.getElementById('select-all-submit')?.addEventListener('change', function () {
        document.querySelectorAll('.chk-submit-order').forEach(c => c.checked = this.checked);
    });

    // Hàm cập nhật số lượng Order on Plan
    const updateOrderOnPlanCount = (orderId, newMarkerDate) => {
        const countCell = document.querySelector(`.order-on-plan-count[data-id="${orderId}"]`);
        if (countCell) {
            const count = getOrdersOnPlan(newMarkerDate);
            countCell.textContent = count;
            countCell.style.color = count > 0 ? 'orange' : 'green';
        }
    };

    // Tạo custom date picker với hiển thị Order on Plan
    document.querySelectorAll('.input-marker-date').forEach(input => {
        createCustomCalendar(input, {
            getOrderCount: getOrdersOnPlan,
            onChange: (selectedDate) => {
                // Cập nhật số lượng Order on Plan ngay lập tức
                const orderId = input.dataset.id;
                updateOrderOnPlanCount(orderId, selectedDate);
            },
            calendarClass: 'custom-calendar'
        });
        
        input.addEventListener('change', async function () {
            const orderId = this.dataset.id;
            const value = this.value;
            
            // Cập nhật số lượng Order on Plan ngay lập tức
            updateOrderOnPlanCount(orderId, value);
            
            if (!value) return;

            const markerDate = new Date(value);
            const cutDate = new Date(markerDate);
            const sewDate = new Date(markerDate);
            cutDate.setDate(markerDate.getDate() + 3);
            sewDate.setDate(markerDate.getDate() + 6);

            await updateOrderMultipleFields(orderId, {
                marker_date: value,
                cut_start_date: cutDate.toISOString().slice(0, 10),
                sewing_start_date: sewDate.toISOString().slice(0, 10)
            }, { noRender: true });
        });
    });

    document.getElementById('btn-add-to-kehoach')?.addEventListener('click', async function () {
        const checkedRows = Array.from(document.querySelectorAll('.chk-submit-order:checked')).map(c => c.closest('tr[data-id]'));
        if (checkedRows.length === 0) {
            alert('Please select at least one order!');
            return;
        }

        let hasError = false;
        for (const row of checkedRows) {
            const inputDate = row.querySelector('.input-marker-date');
            const inputTarget = row.querySelector('.input-target-output');

            inputDate.classList.remove('input-error');
            inputTarget.classList.remove('input-error');

            if (!inputDate.value) {
                inputDate.classList.add('input-error');
                hasError = true;
            }
            if (!inputTarget.value || Number(inputTarget.value) <= 0) {
                inputTarget.classList.add('input-error');
                hasError = true;
            }
        }
        if (hasError) return;

        for (const row of checkedRows) {
            const orderId = row.dataset.id;
            const inputTarget = row.querySelector('.input-target-output');
            if (inputTarget && inputTarget.value) {
                await updateOrderSingleField(orderId, 'target_output', inputTarget.value, { noRender: true });
            }
            await updateOrderSingleField(orderId, 'order_status', 'Loaded', { noRender: true });
        }
        hideModal();
        renderMatrix();
    });
}

/**
 * Hiển thị popup chọn đơn hàng Request để reopen
 */
async function showRequestOrdersPopup() {
    let orders = await fetchData('get_orders');
    const requestOrders = orders.filter(o => o.order_status === 'Request');
    const loadedOrders = orders.filter(o => o.order_status === 'Loaded' || o.order_status === 'Check' || o.order_status === 'Request');
    if (requestOrders.length === 0) {
        alert('No orders in Request status!');
        return;
    }

    let html = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin: 0;">Request Orders</h3>
        <button type="button" onclick="hideModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666; padding: 4px; border-radius: 4px;" onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='none'">&times;</button>
    </div>
    <div style="min-height:450px;overflow:auto;">
    <table class="sticky-header-table" id="table-select-request" style="min-width:950px;">
        <thead>
            <tr>
                <th><input type="checkbox" id="select-all-request"></th>
                <th>Customer</th>
                <th>GO No</th>
                <th>Style</th>
                <th>Sample</th>
                <th>Qty</th>
                <th>Daily Output</th>
                <th>AH Date</th>
                <th>SM Date</th>
                <th>Marker Date</th>
                <th>Delivery</th>
            </tr>
        </thead>
        <tbody>`;
    for (const o of requestOrders) {
        html += `<tr data-id="${o.id}">
            <td><input type="checkbox" class="chk-request-order" value="${o.id}"></td>
            <td>${o.customer_short_name || ''}</td>
            <td>${o.go_no || ''}</td>
            <td>${o.style_no || ''}</td>
            <td>${o.sample_type || ''}</td>
            <td>${o.plan_qty || ''}</td>
            <td>
                <input type="number" class="input-request-target-output" data-id="${o.id}" value="${o.target_output || 1}" min="1" style="width: 70px">
            </td>
            <td>${o.ah_date ? formatDateShort(o.ah_date) : ''}</td>
            <td>${o.sm_date ? formatDateShort(o.sm_date) : ''}</td>
            <td>
                <input type="date" class="input-request-marker-date" data-id="${o.id}" value="${o.marker_date || ''}">
            </td>
            <td>${o.delivery_date ? formatDateShort(o.delivery_date) : ''}</td>
        </tr>`;
    }
    html += `</tbody></table></div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px">
            <button type="button" onclick="hideModal()">Close</button>
            <div style="display:flex;gap:8px;">
                <button type="button" id="btn-add-request-to-plan">Add to Plan</button>
                <button type="button" id="btn-reopen-order">Reopen Order</button>
            </div>
        </div>
    `;
    showModal(html);

    document.getElementById('select-all-request')?.addEventListener('change', function () {
        document.querySelectorAll('.chk-request-order').forEach(c => c.checked = this.checked);
    });

    // Tạo custom date picker với hiển thị Order on Plan cho Request Orders
    document.querySelectorAll('.input-request-marker-date').forEach(input => {
        createCustomCalendar(input, {
            getOrderCount: (dateStr) => loadedOrders.filter(order => order.marker_date === dateStr).length,
            onChange: () => {},
            calendarClass: 'custom-calendar-request'
        });
        
        input.addEventListener('change', async function () {
            const orderId = this.dataset.id;
            const value = this.value;
            
            if (!value) return;

            const markerDate = new Date(value);
            const cutDate = new Date(markerDate);
            const sewDate = new Date(markerDate);
            cutDate.setDate(markerDate.getDate() + 3);
            sewDate.setDate(markerDate.getDate() + 6);

            await updateOrderMultipleFields(orderId, {
                marker_date: value,
                cut_start_date: cutDate.toISOString().slice(0, 10),
                sewing_start_date: sewDate.toISOString().slice(0, 10)
            }, { noRender: true });
        });
    });

    document.getElementById('btn-reopen-order')?.addEventListener('click', async function () {
        const checkedRows = Array.from(document.querySelectorAll('.chk-request-order:checked')).map(c => c.closest('tr[data-id]'));
        if (checkedRows.length === 0) {
            alert('Please select at least one order!');
            return;
        }

        for (const row of checkedRows) {
            const orderId = row.dataset.id;
            const inputTarget = row.querySelector('.input-request-target-output');
            if (inputTarget && inputTarget.value) {
                await updateOrderSingleField(orderId, 'target_output', inputTarget.value, { noRender: true });
            }
            await updateOrderSingleField(orderId, 'order_status', 'ReOpen', { noRender: true });
        }
        hideModal();
        renderMatrix();
    });

    document.getElementById('btn-add-request-to-plan')?.addEventListener('click', async function () {
        const checkedRows = Array.from(document.querySelectorAll('.chk-request-order:checked')).map(c => c.closest('tr[data-id]'));
        if (checkedRows.length === 0) {
            alert('Please select at least one order!');
            return;
        }

        let hasError = false;
        for (const row of checkedRows) {
            const inputDate = row.querySelector('.input-request-marker-date');
            const inputTarget = row.querySelector('.input-request-target-output');

            inputDate.classList.remove('input-error');
            inputTarget.classList.remove('input-error');

            if (!inputDate.value) {
                inputDate.classList.add('input-error');
                hasError = true;
            }
            if (!inputTarget.value || Number(inputTarget.value) <= 0) {
                inputTarget.classList.add('input-error');
                hasError = true;
            }
        }
        if (hasError) return;

        for (const row of checkedRows) {
            const orderId = row.dataset.id;
            const inputTarget = row.querySelector('.input-request-target-output');
            if (inputTarget && inputTarget.value) {
                await updateOrderSingleField(orderId, 'target_output', inputTarget.value, { noRender: true });
            }
            await updateOrderSingleField(orderId, 'order_status', 'Loaded', { noRender: true });
        }
        hideModal();
        renderMatrix();
    });
}

/**
 * Hàm render lại 1 dòng đơn hàng theo id
 */
async function renderOrderRow(orderId) {
    // Lấy lại order vừa cập nhật
    const orders = await fetchData('get_orders');
    const o = orders.find(x => x.id == orderId);
    if (!o) return;
    const endSew = calcEndSew(o);
    const delivery = o.delivery_date || '';
    const warning = (endSew && delivery && compareDates(endSew, delivery) > 0) ? 'danger' : '';
    const planDays = getOrderPlanDays(o);
    const firstPlanDay = planDays[0]?.date;
    const lastPlanDay = planDays[planDays.length - 1]?.date;
    let html = `<tr class="order-row" data-id="${o.id}">
        <td class="drag-handle" style="text-align: center; cursor: grab; user-select: none; font-size: 16px; color: #666; padding: 8px; border-right: 1px solid #ddd;" title="Drag to reorder" onmousedown="this.style.cursor='grabbing'" onmouseup="this.style.cursor='grab'">⋮⋮</td>
        <td><span class="order-status status-${(o.order_status||'').toLowerCase()}">${o.order_status||''}</span></td>
        <td>${o.customer_short_name}</td>
        <td>${o.go_no}</td>
        <td>${o.style_no}</td>
        <td>${o.sample_type || ''}</td>
        <td><input type="number" value="${o.plan_qty}" min="1" onchange="updateOrderSingleField(${o.id},'plan_qty',this.value)" style="width:70px"></td>
        <td><input type="number" value="${o.target_output}" min="1" onchange="updateOrderSingleField(${o.id},'target_output',this.value)" style="width:70px"></td>
        <td><input type="date" value="${o.sewing_start_date}" onchange="handleSewingStartDateChange(${o.id}, this.value)" style="width:130px"></td>
        <td><input type="date" value="${o.marker_date || ''}" onchange="updateOrderSingleField(${o.id},'marker_date',this.value)" style="width:130px"></td>
        <td class="${warning}">${endSew}</td>
        <td>${delivery ? formatDateShort(delivery) : ''}</td>`;
    for (const date of globalDateArr) {
        if (!firstPlanDay || !lastPlanDay) {
            html += `<td class="${isToday(date) ? 'today' : ''}"></td>`;
            continue;
        }
        if (date === firstPlanDay) {
            const span = (new Date(lastPlanDay) - new Date(firstPlanDay)) / (1000 * 60 * 60 * 24) + 1;
            const isLate = endSew && delivery && new Date(endSew) > new Date(delivery);
            const stripClass = `strip-bar${isLate ? " late" : ""}`;
            const lateDays = isLate ? Math.ceil((new Date(endSew) - new Date(delivery)) / (1000 * 60 * 60 * 24)) : 0;
            let tooltip = `${o.customer_short_name} | ${o.go_no} | ${o.sample_type || ''} | ${o.plan_qty} pcs`;
            if (isLate) {
                tooltip += ` | Delay ${lateDays} Day${lateDays > 1 ? 's' : ''}`;
            }
            html += `<td colspan="${span}" class="date-cell">
                <div class="${stripClass}" data-id="${o.id}" data-start="${firstPlanDay}" data-tooltip="${tooltip}">
                    ${o.go_no}
                </div>
            </td>`;
        } else if (date > firstPlanDay && date <= lastPlanDay) {
            // skip
        } else {
            html += `<td class="${isToday(date) ? 'today' : ''}"></td>`;
        }
    }
    html += `</tr>`;
    // Thay thế dòng trong DOM
    const row = document.querySelector(`tr.order-row[data-id="${o.id}"]`);
    if (row) {
        const temp = document.createElement('tbody');
        temp.innerHTML = html;
        row.replaceWith(temp.firstElementChild);
    }
    // Re-init draggable cho strip-bar mới
    initDraggable();
}

/**
 * Thêm context menu cho bảng Plan
 */
function addPlanContextMenu() {
    // Tạo context menu nếu chưa tồn tại
    let contextMenu = document.getElementById('plan-context-menu');
    if (!contextMenu) {
        contextMenu = document.createElement('div');
        contextMenu.id = 'plan-context-menu';
        contextMenu.className = 'context-menu';
        document.body.appendChild(contextMenu);
    }

    // Sử dụng event delegation
    const planTable = document.getElementById('orders-table');
    if (planTable) {
        planTable.removeEventListener('contextmenu', handlePlanTableContextMenu);
        planTable.addEventListener('contextmenu', handlePlanTableContextMenu);
    }

    // Ẩn context menu khi click ra ngoài
    if (!document.body.hasAttribute('data-plan-context-listener')) {
        document.addEventListener('click', hidePlanContextMenu);
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                hidePlanContextMenu();
            }
        });
        document.body.setAttribute('data-plan-context-listener', 'true');
    }
}

/**
 * Xử lý sự kiện chuột phải trên bảng Plan
 */
function handlePlanTableContextMenu(e) {
    const row = e.target.closest('tbody tr.order-row');
    if (!row) return;
    
    e.preventDefault();
    
    const orderId = row.getAttribute('data-id');
    if (!orderId) return;
    
    const contextMenu = document.getElementById('plan-context-menu');
    
    let menuItems = [];
    
    // Always show Details
    menuItems.push(`
        <div class="context-menu-item" onclick="showDetail(${orderId}, ['customer_short_name','order_status']); hidePlanContextMenu();">
            <span style="color: #2563eb;">📄</span> Details
        </div>
    `);
    
    // Add Timeline menu
    menuItems.push('<div class="context-menu-separator"></div>');
    menuItems.push(`
        <div class="context-menu-item" onclick="openTimeline(${orderId}); hidePlanContextMenu();">
            <span style="color: #16a34a;">🕐</span> Timeline
        </div>
    `);
    
    contextMenu.innerHTML = menuItems.join('');
    
    // Hiển thị menu tại vị trí chuột
    contextMenu.style.display = 'block';
    contextMenu.style.left = e.pageX + 'px';
    contextMenu.style.top = e.pageY + 'px';
    
    // Đảm bảo menu không bị cắt bởi viewport
    const rect = contextMenu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
        contextMenu.style.left = (e.pageX - rect.width) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
        contextMenu.style.top = (e.pageY - rect.height) + 'px';
    }
}

/**
 * Ẩn context menu của Plan
 */
function hidePlanContextMenu(e) {
    const contextMenu = document.getElementById('plan-context-menu');
    if (contextMenu && contextMenu.style.display === 'block') {
        if (e && contextMenu.contains(e.target)) {
            return;
        }
        contextMenu.style.display = 'none';
    }
}

/**
 * Mở Timeline cho đơn hàng
 */
function openTimeline(orderId) {
    if (orderId) {
        // Tạo modal nếu chưa tồn tại với style giống order_status_report
        let modal = document.getElementById('plan-timeline-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'plan-timeline-modal';
            modal.className = 'modal';
            modal.style.cssText = `
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
                overflow: auto;
            `;
            modal.innerHTML = `
                <div class="modal-content" style="
                    background-color: #fefefe;
                    margin: 2% auto;
                    padding: 0;
                    border: none;
                    border-radius: 8px;
                    width: 55%;
                    max-width: 1200px;
                    height: 90vh;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                    position: relative;
                ">
                    <div class="modal-header" style="
                        background: linear-gradient(135deg, #6366f1, #8b5cf6);
                        color: white;
                        padding: 16px 20px;
                        border-radius: 8px 8px 0 0;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    ">
                        <h3 class="modal-title" style="
                            margin: 0;
                            font-size: 18px;
                            font-weight: 600;
                        ">
                            <i class="fas fa-clock"></i> Order Timeline
                        </h3>
                        <button class="close-btn" onclick="closePlanTimelineModal()" style="
                            background: none;
                            border: none;
                            color: white;
                            font-size: 24px;
                            cursor: pointer;
                            padding: 0;
                            width: 30px;
                            height: 30px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            border-radius: 4px;
                            transition: all 0.2s;
                        " onmouseover="this.style.background='rgba(255,255,255,0.2)'" onmouseout="this.style.background='none'">&times;</button>
                    </div>
                    <div class="modal-body" style="
                        height: calc(90vh - 68px);
                        overflow: hidden;
                    ">
                        <iframe id="plan-timeline-frame" class="modal-iframe" src="" style="
                            width: 100%;
                            height: 100%;
                            border: none;
                            border-radius: 0 0 8px 8px;
                        "></iframe>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            // Add click event to close modal when clicking outside
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closePlanTimelineModal();
                }
            });
        }
        
        const iframe = document.getElementById('plan-timeline-frame');
        const title = modal.querySelector('.modal-title');
        
        // Update modal title with order ID
        title.innerHTML = `<i class="fas fa-clock"></i> Order Timeline - Order #${orderId}`;
        
        // Set iframe source
        iframe.src = `order_timeline.php?order_id=${orderId}`;
        
        // Show modal
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
    }
}

/**
 * Đóng Timeline modal
 */
function closePlanTimelineModal() {
    const modal = document.getElementById('plan-timeline-modal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto'; // Restore scrolling
        
        // Clear iframe source
        const iframe = document.getElementById('plan-timeline-frame');
        if (iframe) {
            iframe.src = '';
        }
    }
}

// Export các hàm để file khác sử dụng
window.renderMatrix = renderMatrix;
window.handleSewingStartDateChange = handleSewingStartDateChange;
window.initDraggable = initDraggable;
window.initRowSortable = initRowSortable;
window.showSubmittedOrdersPopup = showSubmittedOrdersPopup;
window.showRequestOrdersPopup = showRequestOrdersPopup;
window.addPlanContextMenu = addPlanContextMenu;
window.handlePlanTableContextMenu = handlePlanTableContextMenu;
window.hidePlanContextMenu = hidePlanContextMenu;
window.openTimeline = openTimeline;
window.closePlanTimelineModal = closePlanTimelineModal;
