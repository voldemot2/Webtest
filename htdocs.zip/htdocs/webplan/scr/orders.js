// orders.js
// Quản lý logic đơn hàng: thêm, sửa, cập nhật, nhân bản, form chi tiết, validate

/**
 * Tạo style compact cho custom calendar
 */
function getCompactCalendarStyle() {
    return {
        container: `
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1001;
            display: none;
            padding: 8px;
            min-width: 260px;
        `,
        header: `
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 8px; 
            background: #f8f9fa; 
            padding: 6px; 
            border-radius: 4px;
        `,
        navButton: `
            background: #007cba; 
            border: none; 
            font-size: 14px; 
            cursor: pointer; 
            padding: 4px 8px; 
            border-radius: 3px; 
            color: white; 
            font-weight: bold; 
            min-width: 30px; 
            transition: all 0.2s;
        `,
        monthTitle: `
            font-weight: bold; 
            font-size: 14px; 
            color: #333;
        `,
        gridContainer: `
            display: grid; 
            grid-template-columns: repeat(7, 1fr); 
            gap: 1px; 
            text-align: center;
        `,
        dayHeader: `
            font-weight: bold; 
            padding: 2px; 
            font-size: 11px;
        `,
        dayCell: `
            padding: 6px 3px;
            cursor: pointer;
            border-radius: 3px;
            position: relative;
            font-size: 11px;
            min-height: 26px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        `
    };
}

/**
 * Format ngày để hiển thị dễ đọc
 * @param {string} dateStr - Ngày ở định dạng YYYY-MM-DD
 * @returns {string}
 */
function formatDateDisplay(dateStr) {
    console.log('🔄 formatDateDisplay called with:', dateStr);
    if (!dateStr) {
        console.log('❌ No dateStr provided, returning Select Date');
        return 'Select Date';
    }
    const date = new Date(dateStr);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const result = `${month}/${day}/${date.getFullYear()}`;
    console.log('✅ formatDateDisplay result:', result);
    return result;
}

/**
 * Tạo custom calendar picker cho input date
 * @param {HTMLInputElement} input - Input element để gắn calendar
 * @param {Object} options - Tùy chọn calendar
 * @param {Function} options.getOrderCount - Hàm trả về số đơn hàng cho ngày cụ thể
 * @param {Function} options.onChange - Callback khi chọn ngày
 * @param {string} options.calendarClass - CSS class cho calendar container
 */
function createCustomCalendar(input, options = {}) {
    const {
        getOrderCount = () => 0,
        onChange = () => {},
        calendarClass = 'custom-calendar'
    } = options;

    // Ẩn input date gốc và tạo custom picker
    input.style.display = 'none';
    
    // Tạo wrapper container cho custom picker
    const wrapper = document.createElement('div');
    wrapper.style.position = 'relative';
    wrapper.style.display = 'inline-block';
    
    // Thay thế input bằng wrapper
    input.parentNode.insertBefore(wrapper, input);
    wrapper.appendChild(input);
    
    // Tạo button hiển thị ngày đã chọn
    const dateButton = document.createElement('button');
    dateButton.type = 'button';
    dateButton.textContent = formatDateDisplay(input.value);
    dateButton.style.cssText = `
        padding: 6px 12px;
        border: 1px solid #ccc;
        background: white;
        cursor: pointer;
        border-radius: 4px;
        font-size: 14px;
        min-width: 120px;
        color: black;
    `;
    wrapper.appendChild(dateButton);
    
    // Tạo custom calendar
    const calendar = document.createElement('div');
    calendar.className = calendarClass;
    const compactStyle = getCompactCalendarStyle();
    calendar.style.cssText = compactStyle.container;
    wrapper.appendChild(calendar);
    
    // Hàm tạo calendar cho tháng hiện tại
    const renderCalendar = (year, month) => {
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startDayOfWeek = firstDay.getDay();
        
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                           'July', 'August', 'September', 'October', 'November', 'December'];
        
        let html = `
            <div style="${compactStyle.header}">
                <button type="button" class="prev-month" style="${compactStyle.navButton}" onmouseover="this.style.background='#005a8b'" onmouseout="this.style.background='#007cba'">&lt;</button>
                <span style="${compactStyle.monthTitle}">${monthNames[month]} ${year}</span>
                <button type="button" class="next-month" style="${compactStyle.navButton}" onmouseover="this.style.background='#005a8b'" onmouseout="this.style.background='#007cba'">&gt;</button>
            </div>
            <div style="${compactStyle.gridContainer}">
                <div style="${compactStyle.dayHeader}">Su</div>
                <div style="${compactStyle.dayHeader}">Mo</div>
                <div style="${compactStyle.dayHeader}">Tu</div>
                <div style="${compactStyle.dayHeader}">We</div>
                <div style="${compactStyle.dayHeader}">Th</div>
                <div style="${compactStyle.dayHeader}">Fr</div>
                <div style="${compactStyle.dayHeader}">Sa</div>`;
        
        // Empty cells for days before first day of month
        for (let i = 0; i < startDayOfWeek; i++) {
            html += `<div></div>`;
        }
        
        // Days of the month
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const orderCount = getOrderCount(dateStr);
            const isSelected = input.value === dateStr;
            const isToday = new Date().toDateString() === new Date(dateStr).toDateString();
            
            let dayStyle = compactStyle.dayCell;
            
            if (isSelected) {
                dayStyle += 'background: #007cba; color: white;';
            } else if (isToday) {
                dayStyle += 'background: #e3f2fd; border: 1px solid #2196f3;';
            } else {
                dayStyle += 'background: #f9f9f9; border: 1px solid transparent;';
            }
            
            html += `
                <div class="calendar-day" data-date="${dateStr}" style="${dayStyle}" onmouseover="if(!this.classList.contains('selected')) this.style.background='#e1f5fe'" onmouseout="if(!this.classList.contains('selected')) this.style.background='${isToday ? '#e3f2fd' : '#f9f9f9'}'">
                    <span style="font-weight: bold;">${day}</span>
                    ${orderCount > 0 ? `<span style="font-size: 10px; color: ${isSelected ? 'white' : '#ff9800'}; font-weight: bold;">${orderCount}</span>` : ''}
                </div>`;
        }
        
        html += `</div>`;
        calendar.innerHTML = html;
        
        // Event listeners cho navigation
        calendar.querySelector('.prev-month').addEventListener('click', (e) => {
            e.stopPropagation();
            const newMonth = month === 0 ? 11 : month - 1;
            const newYear = month === 0 ? year - 1 : year;
            renderCalendar(newYear, newMonth);
        });
        
        calendar.querySelector('.next-month').addEventListener('click', (e) => {
            e.stopPropagation();
            const newMonth = month === 11 ? 0 : month + 1;
            const newYear = month === 11 ? year + 1 : year;
            renderCalendar(newYear, newMonth);
        });
        
        // Event listeners cho chọn ngày
        calendar.querySelectorAll('.calendar-day').forEach(dayEl => {
            dayEl.addEventListener('click', () => {
                const selectedDate = dayEl.dataset.date;
                console.log('📅 Calendar day clicked:', selectedDate);
                
                input.value = selectedDate;
                console.log('✅ Input value set to:', input.value);
                
                dateButton.textContent = formatDateDisplay(selectedDate);
                console.log('✅ DateButton text set to:', dateButton.textContent);
                
                calendar.style.display = 'none';
                
                // Trigger change event
                const changeEvent = new Event('change', { bubbles: true });
                input.dispatchEvent(changeEvent);
                
                // Call custom onChange callback
                onChange(selectedDate);
                console.log('✅ Change event dispatched and callback called');
            });
        });
    };
    
    // Hiển thị calendar khi click button
    dateButton.addEventListener('click', (e) => {
        e.stopPropagation();
        
        // Ẩn tất cả calendar khác
        document.querySelectorAll(`.${calendarClass}`).forEach(cal => {
            if (cal !== calendar) cal.style.display = 'none';
        });
        
        if (calendar.style.display === 'none') {
            const currentDate = input.value ? new Date(input.value) : new Date();
            renderCalendar(currentDate.getFullYear(), currentDate.getMonth());
            calendar.style.display = 'block';
        } else {
            calendar.style.display = 'none';
        }
    });
    
    // Ẩn calendar khi click ngoài
    const hideCalendar = (e) => {
        if (!wrapper.contains(e.target)) {
            calendar.style.display = 'none';
        }
    };
    
    document.addEventListener('click', hideCalendar);
    
    // Return cleanup function
    return {
        destroy: () => {
            document.removeEventListener('click', hideCalendar);
            wrapper.parentNode.replaceChild(input, wrapper);
            input.style.display = '';
        },
        updateButton: (newValue) => {
            dateButton.textContent = formatDateDisplay(newValue);
        }
    };
}

function formatDateShort(dateStr) {
    if (!dateStr || dateStr === 'null') return '';
    // Convert YYYY-MM-DD to MM/DD/YY
    const match = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (match) {
        return `${match[2]}/${match[3]}/${match[1].slice(2)}`;
    }
    return dateStr;
}

// --- HÀM CẬP NHẬT ĐƠN HÀNG ---
async function updateOrderSingleField(order_id, field, value, options = {}) {
    // Kiểm tra quyền ghi
    if (!hasWritePermissionForCurrentDepartment()) {
        alert('Bạn không có quyền chỉnh sửa đơn hàng!');
        return { success: false, error: 'No write permission' };
    }
    
    const params = new URLSearchParams({ order_id, field, value });
    const result = await fetchData('update_order_field', 'POST', params.toString());
    
    if (!options.noRender) {
        refreshCurrentTab();
    } else if (typeof options.onDone === 'function') {
        options.onDone();
    }
    
    return result;
}

async function updateOrderMultipleFields(order_id, fields, options = {}) {
    // Kiểm tra quyền ghi
    if (!hasWritePermissionForCurrentDepartment()) {
        alert('Bạn không có quyền chỉnh sửa đơn hàng!');
        return { success: false, error: 'No write permission' };
    }
    
    const result = await fetchData('update_order_fields', 'POST', { order_id, fields });
    
    if (!options.noRender) {
        refreshCurrentTab();
    } else if (typeof options.onDone === 'function') {
        options.onDone();
    }
    
    return result;
}

// --- HÀM CHI TIẾT, FORM, LƯU ĐƠN HÀNG ---
async function showDetail(id, readonlyFields = []) {
    if (id === 0) {
        // Mở form thêm mới đơn hàng
        const today = new Date().toISOString().slice(0, 10);
        openForm({
            id: 0, go_no: "", style_no: "", customer_short_name: "",
            plan_qty: 1, target_output: 1,
            sewing_start_date: today, delivery_date: today,
            marker_date: today, cut_start_date: today,
            jo_no: "", color_code: "", product_category: "", wash_type: "",
            order_status: "Open"
        }, readonlyFields);
        return;
    }
    const orders = await fetchData('get_orders');
    const o = orders.find(x => x.id == id);        if (!o) return alert('Order not found!');
    openForm(o, readonlyFields);
}

function addNewOrder() {
    // Kiểm tra quyền thêm mới
    if (!hasWritePermissionForCurrentDepartment()) {
        alert('Bạn không có quyền thêm đơn hàng mới!');
        return;
    }
    
    const today = new Date().toISOString().slice(0, 10);
    openForm({
        id: 0, go_no: "", style_no: "", customer_short_name: "",
        plan_qty: 100, target_output: 50,
        sewing_start_date: today, delivery_date: today,
        marker_date: today, cut_start_date: today,
        jo_no: "", color_code: "", product_category: "", wash_type: "",
        order_status: "Open"
    });
}

function openForm(o, readonlyFields = []) {
    function inputStyle(readonly) {
        return readonly ? '' : 'background:#fffbe6;';
    }
    function isReadonly(field) {
        return readonlyFields.includes(field);
    }
    let html = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin: 0;">${o.id === 0 ? 'Add New' : 'Order Details'}</h3>
        <button type="button" onclick="hideModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666; padding: 4px; border-radius: 4px;" onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='none'">&times;</button>
    </div>
    <form id="frm-detail">
      <input type="hidden" name="id" value="${o.id}">
      <div class="form-grid">
        <div>
          <label>Customer:<input name="customer_short_name" value="${o.customer_short_name || ''}" required style="${inputStyle(isReadonly('customer_short_name'))}" ${isReadonly('customer_short_name') ? 'readonly' : ''}></label>
          <label>GO No:<input name="go_no" value="${o.go_no || ''}" required style="${inputStyle(isReadonly('go_no'))}" ${isReadonly('go_no') ? 'readonly' : ''}></label>
          <label>Job No:<input name="jo_no" value="${o.jo_no || ''}" style="${inputStyle(isReadonly('jo_no'))}" ${isReadonly('jo_no') ? 'readonly' : ''}></label>
          <label>Color Code:<input name="color_code" value="${o.color_code || ''}" style="${inputStyle(isReadonly('color_code'))}" ${isReadonly('color_code') ? 'readonly' : ''}></label>
          <label>Style:<input name="style_no" value="${o.style_no || ''}" required style="${inputStyle(isReadonly('style_no'))}" ${isReadonly('style_no') ? 'readonly' : ''}></label>
          <label>Product Type:<input name="product_category" value="${o.product_category || ''}" style="${inputStyle(isReadonly('product_category'))}" ${isReadonly('product_category') ? 'readonly' : ''}></label>
          <label>Wash Type:<input name="wash_type" value="${o.wash_type || ''}" style="${inputStyle(isReadonly('wash_type'))}" ${isReadonly('wash_type') ? 'readonly' : ''}></label>
          <label>Sample Type:<input name="sample_type" value="${o.sample_type || ''}" style="${inputStyle(isReadonly('sample_type'))}" ${isReadonly('sample_type') ? 'readonly' : ''}></label>
          <label>Order Status:<input name="order_status" value="${o.order_status || 'Open'}" style="${inputStyle(isReadonly('order_status'))}" ${isReadonly('order_status') ? 'readonly' : ''}></label>
        </div>
        <div>
          <label>Plan Qty:<input type="number" name="plan_qty" value="${o.plan_qty || ''}" required style="${inputStyle(isReadonly('plan_qty'))}" ${isReadonly('plan_qty') ? 'readonly' : ''}></label>
          <label>Daily Output:<input type="number" name="target_output" value="${o.target_output || ''}" required style="${inputStyle(isReadonly('target_output'))}" ${isReadonly('target_output') ? 'readonly' : ''}></label>
          <label>AH Date:<input type="date" name="ah_date" value="${o.ah_date || ''}" style="${inputStyle(isReadonly('ah_date'))}" ${isReadonly('ah_date') ? 'readonly' : ''}></label>
          <label>SM Date:<input type="date" name="sm_date" value="${o.sm_date || ''}" style="${inputStyle(isReadonly('sm_date'))}" ${isReadonly('sm_date') ? 'readonly' : ''}></label>
          <label>Delivery Date:<input type="date" name="delivery_date" value="${o.delivery_date || ''}" required style="${inputStyle(isReadonly('delivery_date'))}" ${isReadonly('delivery_date') ? 'readonly' : ''}></label>
          <label>Marker Date:<input type="date" name="marker_date" value="${o.marker_date || ''}" style="${inputStyle(isReadonly('marker_date'))}" ${isReadonly('marker_date') ? 'readonly' : ''}></label>
          <label>Cut Start Date:<input type="date" name="cut_start_date" value="${o.cut_start_date || ''}" style="${inputStyle(isReadonly('cut_start_date'))}" ${isReadonly('cut_start_date') ? 'readonly' : ''}></label>
          <label>Sewing Start:<input type="date" name="sewing_start_date" value="${o.sewing_start_date || ''}" style="${inputStyle(isReadonly('sewing_start_date'))}" ${isReadonly('sewing_start_date') ? 'readonly' : ''}></label>
          <label>Remark:<input name="remark" value="${o.remark || ''}" style="${inputStyle(isReadonly('remark'))}" ${isReadonly('remark') ? 'readonly' : ''}></label>
        </div>
      </div>
      <div class="btns">
        <button type="button" onclick="hideModal()">Cancel</button>
        <button type="button" onclick="saveDetail()">Save</button>
      </div>
    </form>`;
    showModal(html);
}

async function saveDetail() {
    const frm = document.getElementById('frm-detail');
    const data = new FormData(frm);
    const sewDateStr = data.get("sewing_start_date");
    // Cho phép bỏ trống marker_date, cut_start_date, sewing_start_date, sm_date
    if (sewDateStr) {
        const sewDate = new Date(sewDateStr);
        const markerDate = new Date(sewDate);
        const cutDate = new Date(sewDate);
        markerDate.setDate(sewDate.getDate() - 6);
        cutDate.setDate(sewDate.getDate() - 3);
        data.set("marker_date", markerDate.toISOString().slice(0, 10));
        data.set("cut_start_date", cutDate.toISOString().slice(0, 10));
    } else {
        data.set("marker_date", "null");
        data.set("cut_start_date", "null");
        data.set("sewing_start_date", "null");
    }
    // Các trường ngày khác nếu rỗng thì set "null" (chuỗi) để backend nhận biết và chuyển thành NULL)
    ["sm_date", "ah_date", "delivery_date"].forEach(field => {
        if (!data.get(field)) data.set(field, "null");
    });
    try {
        const json = await fetchData('update_order_full', 'POST', data);
        if (json.success) {
            hideModal();
            refreshCurrentTab();
        } else {
            alert('Save failed!');
        }
    } catch (err) {
        alert('Connection error or invalid data!');
        console.error(err);
    }
}

async function duplicateAHRow(orderId) {
    const orders = await fetchData('get_orders');
    const order = orders.find(x => x.id == orderId);
    if (!order) {
        alert("Order not found for duplication!");
        return;
    }
    const dateFields = [
        'ah_date', 'sm_date', 'marker_date', 'cut_start_date', 'sewing_start_date', 'delivery_date'
    ];
    // Tạo bản sao, các trường ngày luôn set 'null' (chuỗi)
    const newOrder = { ...order, id: 0, plan_qty: order.plan_qty || 1, target_output: order.target_output || 1, sample_type: "", remark: "", order_status: "Open" };
    dateFields.forEach(field => {
        newOrder[field] = "null";
    });
    const formData = new FormData();
    for (const key in newOrder) {
        formData.append(key, newOrder[key]);
    }
    const json = await fetchData('update_order_full', 'POST', formData);
    if (json.success) {
        renderTabAH();
    } else {
        alert("Failed to add new row!\n" + (json.error || JSON.stringify(json)));
        console.error('duplicateAHRow error:', json);
    }
}

async function changeOrderStatus(orderId, status) {
    const fieldsToCheck = ['plan_qty', 'sample_type', 'ah_date', 'delivery_date'];
    let isValid = true;
    if (status === "Submit") {
        if (orderId === 0) {
            // Kiểm tra trên form modal khi thêm mới
            const frm = document.getElementById('frm-detail');
            if (frm) {
                for (const name of fieldsToCheck) {
                    const input = frm.querySelector(`[name="${name}"]`);
                    if (!input || !input.value.trim()) {
                        if (input) input.classList.add('input-error');
                        isValid = false;
                    } else {
                        input.classList.remove('input-error');
                    }
                }
                if (!isValid) {
                    setTimeout(() => {
                        for (const name of fieldsToCheck) {
                            const input = frm.querySelector(`[name="${name}"]`);
                            if (input) input.classList.remove('input-error');
                        }
                    }, 2000);
                    return;
                }
            } else {
                // Không tìm thấy form, không cho submit
                return;
            }
        } else {
            // Kiểm tra trên bảng khi sửa dòng cũ
            const row = document.querySelector(`#ah-table tr[data-id="${orderId}"]`);
            if (row) {
                let updateFields = {};
                for (const name of fieldsToCheck) {
                    const input = row.querySelector(`[name="${name}"]`);
                    if (!input || !input.value.trim()) {
                        if (input) input.classList.add('input-error');
                        isValid = false;
                    } else {
                        input.classList.remove('input-error');
                        updateFields[name] = input.value;
                    }
                }
                if (!isValid) {
                    setTimeout(() => {
                        for (const name of fieldsToCheck) {
                            const input = row.querySelector(`[name="${name}"]`);
                            if (input) input.classList.remove('input-error');
                        }
                    }, 2000);
                    return;
                }
                // Nếu hợp lệ, cập nhật các trường bắt buộc trước khi đổi trạng thái
                if (Object.keys(updateFields).length > 0) {
                    await updateOrderMultipleFields(orderId, updateFields, {noRender:true});
                }
            } else {
                // Không tìm thấy dòng, không cho submit
                return;
            }
        }
    }
    await updateOrderSingleField(orderId, 'order_status', status);
    renderTabAH();
}

// Export các hàm để file khác sử dụng
window.getCompactCalendarStyle = getCompactCalendarStyle;
window.formatDateDisplay = formatDateDisplay;
window.createCustomCalendar = createCustomCalendar;
window.updateOrderSingleField = updateOrderSingleField;
window.updateOrderMultipleFields = updateOrderMultipleFields;
window.showDetail = showDetail;
window.addNewOrder = addNewOrder;
window.openForm = openForm;
window.saveDetail = saveDetail;
window.duplicateAHRow = duplicateAHRow;
window.changeOrderStatus = changeOrderStatus;