<?php
require_once 'auth.php';

// Kiểm tra đăng nhập
$currentUser = checkLogin();

// Chỉ cho phép manager và admin xem logs
if ($currentUser['role'] !== 'admin' && $currentUser['role'] !== 'manager') {
    header('Location: index.php');
    exit();
}

// Get order ID from URL parameter
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Timeline - SPS Planning System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Reset và override các style có thể conflict */
        * {
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            line-height: 1.5;
        }
        
        .timeline-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
        }
        
        .page-header {
            background: white;
            padding: 12px 16px;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            margin: 0;
            color: #1f2937;
            font-size: 22px;
            font-weight: 600;
        }
        
        .header-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        .back-btn, .history-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 500;
            font-size: 13px;
            transition: all 0.2s;
        }
        
        .back-btn {
            background: #6366f1;
            color: white;
        }
        
        .back-btn:hover {
            background: #4f46e5;
            transform: translateY(-1px);
        }
        
        .history-btn {
            background: #10b981;
            color: white;
        }
        
        .history-btn:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .order-info-panel {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            margin-bottom: 16px;
            overflow: hidden;
            display: none;
        }
        
        .order-info-header {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            padding: 16px 20px;
        }
        
        .order-title {
            font-size: 20px;
            font-weight: 600;
            margin: 0 0 6px 0;
        }
        
        .order-subtitle {
            font-size: 14px;
            opacity: 0.9;
            margin: 0;
        }
        
        .timeline-panel {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            overflow: hidden;
            display: none;
            max-height: 600px;
            display: flex;
            flex-direction: column;
        }
        
        .timeline-header {
            padding: 16px 20px;
            border-bottom: 1px solid #e5e7eb;
            background: #f9fafb;
            flex-shrink: 0;
        }
        
        .timeline-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin: 0;
        }
        
        .timeline-content {
            padding: 20px;
            min-height: 400px;
            flex: 1;
            overflow-y: auto;
            max-height: 500px;
        }
        
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e5e7eb;
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 32px;
            background: #f9fafb;
            border-radius: 8px;
            padding: 16px;
            border-left: 4px solid #6366f1;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -21px;
            top: 20px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #6366f1;
            border: 2px solid white;
            box-shadow: 0 0 0 2px #6366f1;
        }
        
        .timeline-item.create::before {
            background: #10b981;
            box-shadow: 0 0 0 2px #10b981;
        }
        
        .timeline-item.update::before {
            background: #f59e0b;
            box-shadow: 0 0 0 2px #f59e0b;
        }
        
        .timeline-item.delete::before {
            background: #ef4444;
            box-shadow: 0 0 0 2px #ef4444;
        }
        
        .timeline-header-info {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .timeline-action {
            font-size: 16px;
            font-weight: 600;
            color: #1f2937;
            margin: 0;
        }
        
        .timeline-time {
            font-size: 12px;
            color: #6b7280;
            font-weight: 500;
        }
        
        .timeline-user {
            font-size: 14px;
            color: #4b5563;
            margin-bottom: 8px;
        }
        
        .timeline-changes {
            margin-top: 12px;
        }
        
        .change-item {
            background: white;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 8px;
            border: 1px solid #e5e7eb;
        }
        
        .change-field {
            font-weight: 500;
            color: #374151;
            margin-bottom: 8px;
        }
        
        .change-values {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        
        .change-single {
            display: block;
        }
        
        .change-old, .change-new {
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 13px;
            font-family: 'Courier New', monospace;
            position: relative;
        }
        
        .change-old {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        
        .change-new {
            background: #f0fdf4;
            color: #059669;
            border: 1px solid #bbf7d0;
        }
        
        .change-label {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 4px;
            opacity: 0.7;
        }
        
        .change-comparison {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 8px;
            padding: 8px 12px;
            background: #f8fafc;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
        }
        
        .comparison-arrow {
            color: #6b7280;
            font-weight: bold;
            font-size: 16px;
        }
        
        .comparison-value {
            flex: 1;
            padding: 6px 10px;
            border-radius: 4px;
            font-size: 13px;
            font-family: 'Courier New', monospace;
        }
        
        .comparison-old {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        
        .comparison-new {
            background: #f0fdf4;
            color: #059669;
            border: 1px solid #bbf7d0;
        }
        
        .comparison-equal {
            background: #f1f5f9;
            color: #475569;
            border: 1px solid #cbd5e1;
            text-align: center;
            font-style: italic;
        }
        
        .change-diff {
            margin-top: 8px;
            padding: 8px 12px;
            background: #fefce8;
            border: 1px solid #fde047;
            border-radius: 6px;
            font-size: 12px;
        }
        
        .diff-added {
            color: #15803d;
            background: #dcfce7;
            padding: 2px 4px;
            border-radius: 3px;
            font-weight: 500;
        }
        
        .diff-removed {
            color: #dc2626;
            background: #fef2f2;
            padding: 2px 4px;
            border-radius: 3px;
            font-weight: 500;
        }
        
        .change-summary {
            margin-top: 8px;
            padding: 6px 10px;
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 4px;
            font-size: 12px;
            color: #1e40af;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-icon {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .loading {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .loading i {
            font-size: 24px;
            margin-bottom: 12px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .timeline-container {
                padding: 12px;
            }
            
            .page-header {
                flex-direction: column;
                gap: 12px;
                text-align: center;
            }
            
            .header-actions {
                flex-direction: column;
                width: 100%;
            }
            
            .change-values {
                grid-template-columns: 1fr;
            }
            
            .change-comparison {
                flex-direction: column;
                gap: 8px;
            }
            
            .comparison-arrow {
                transform: rotate(90deg);
                align-self: center;
            }
            
            .timeline {
                padding-left: 20px;
            }
            
            .timeline-item::before {
                left: -16px;
            }
            
            .timeline-content {
                max-height: 400px;
            }
        }
        
        /* Override any conflicting styles from main stylesheet */
        .timeline-container * {
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <div class="timeline-container">
        
        <div class="order-info-panel" id="orderInfoPanel">
            <div class="order-info-header" id="orderInfoHeader">
                <div style="display: flex; align-items: baseline; gap: 16px; flex-wrap: wrap;">
                    <h2 class="order-title" id="orderTitle" style="margin: 0;">Loading...</h2>
                    <span class="order-subtitle" id="orderSubtitle" style="margin: 0; font-size: 15px; opacity: 0.8;">Order Information</span>
                </div>
            </div>
        </div>
        
        <div class="timeline-panel" id="timelinePanel">
            <div class="timeline-header">
                <h3 class="timeline-title">
                    <i class="fas fa-history"></i> Change Timeline
                </h3>
            </div>
            <div class="timeline-content">
                <div id="timelineContainer">
                    <div class="loading">
                        <i class="fas fa-spinner fa-spin"></i>
                        <div>Loading timeline...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="scr/api.js"></script>
    <script>
        let currentOrderId = <?php echo $order_id; ?>;
        
        document.addEventListener('DOMContentLoaded', function() {
            // Load initial order if ID provided
            if (currentOrderId > 0) {
                loadOrderTimeline(currentOrderId);
            }
        });
        
        async function loadOrderTimeline(orderId) {
            try {
                // Show panels
                const orderPanel = document.getElementById('orderInfoPanel');
                const timelinePanel = document.getElementById('timelinePanel');
                
                orderPanel.style.display = 'block';
                timelinePanel.style.display = 'flex'; // Changed from 'block' to 'flex'
                
                // Load order info and timeline in parallel
                const [orderInfo, timelineData] = await Promise.all([
                    fetchOrderInfo(orderId),
                    fetchOrderTimeline(orderId)
                ]);
                
                if (orderInfo.success) {
                    console.log('Order info loaded successfully:', orderInfo);
                    displayOrderInfo(orderInfo.order);
                } else {
                    console.log('Order info error:', orderInfo);
                    displayOrderError(orderInfo.error || 'Order not found');
                }
                
                if (timelineData.success) {
                    displayTimeline(timelineData.logs);
                } else {
                    displayTimelineError('No timeline data found');
                }
                
            } catch (error) {
                console.error('Error loading order timeline:', error);
                displayOrderError('Error loading order data');
                displayTimelineError('Error loading timeline data');
            }
        }
        
        async function fetchOrderInfo(orderId) {
            try {
                const response = await fetch(`process.php?action=get_order_info&order_id=${orderId}`);
                const text = await response.text();
                console.log('Order info response:', text); // Debug log
                
                try {
                    return JSON.parse(text);
                } catch (parseError) {
                    console.error('JSON parse error for order info:', parseError);
                    console.error('Response text:', text);
                    return { success: false, error: 'Invalid JSON response' };
                }
            } catch (error) {
                console.error('Error fetching order info:', error);
                return { success: false, error: error.message };
            }
        }
        
        async function fetchOrderTimeline(orderId) {
            try {
                const response = await fetch(`process.php?action=get_activity_logs&order_id=${orderId}&limit=100`);
                const text = await response.text();
                return JSON.parse(text);
            } catch (error) {
                console.error('Error fetching timeline:', error);
                return { success: false, error: error.message };
            }
        }
        
        function displayOrderInfo(order) {
            // Handle cases where order data might be incomplete
            const goNo = order.go_no || `Order #${order.id}`;
            const customer = order.customer_short_name || 'Unknown Customer';
            const sampleType = order.sample_type || 'Regular Order';
            
            document.getElementById('orderTitle').textContent = goNo;
            document.getElementById('orderSubtitle').textContent = `${customer} • ${sampleType}`;
        }
        
        function displayOrderError(message) {
            document.getElementById('orderTitle').textContent = 'Order Not Found';
            document.getElementById('orderSubtitle').textContent = message;
        }
        
        function displayTimeline(logs) {
            const container = document.getElementById('timelineContainer');
            
            if (!logs || logs.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-icon">📋</div>
                        <div><strong>No timeline data found</strong></div>
                        <div>This order has no recorded changes.</div>
                    </div>`;
                return;
            }
            
            // Sort logs by date (newest first)
            logs.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            
            let html = '<div class="timeline">';
            
            logs.forEach(log => {
                const date = new Date(log.created_at);
                // MM/DD/YYYY HH:MM
                const pad = n => n.toString().padStart(2, '0');
                const MM = pad(date.getMonth() + 1);
                const DD = pad(date.getDate());
                const YYYY = date.getFullYear();
                const HH = pad(date.getHours());
                const mm = pad(date.getMinutes());
                const timeStr = `${MM}/${DD}/${YYYY} ${HH}:${mm}`;
                
                const actionClass = log.action.includes('create') ? 'create' : 
                                  log.action.includes('delete') ? 'delete' : 'update';
                
                const actionText = getActionText(log.action);
                const userInfo = log.full_name || log.username || 'System';
                const userRole = log.role ? ` (${log.role})` : '';
                
                html += `
                    <div class="timeline-item ${actionClass}">
                        <div class="timeline-header-info">
                            <h4 class="timeline-action">${actionText}</h4>
                            <span class="timeline-time">${timeStr}</span>
                        </div>
                        <div class="timeline-user">
                            <i class="fas fa-user"></i> ${userInfo}${userRole}
                        </div>`;
                
                // Add changes if available
                if (log.old_value && log.new_value) {
                    const fieldName = getFieldName(log.action);
                    const oldVal = formatValue(log.old_value);
                    const newVal = formatValue(log.new_value);
                    
                    // Show comparison for non-status updates, simple old/new for status updates
                    if (actionText === 'Update Field Order Status') {
                        html += `
                            <div class="timeline-changes">
                                <div class="change-item">
                                    <div class="change-field">${fieldName}</div>
                                    <div class="change-values">
                                        <div>
                                            <div class="change-label">Old Value</div>
                                            <div class="change-old">${oldVal}</div>
                                        </div>
                                        <div>
                                            <div class="change-label">New Value</div>
                                            <div class="change-new">${newVal}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                    } else {
                        const comparison = compareValues(log.old_value, log.new_value, fieldName);
                        html += `
                            <div class="timeline-changes">
                                <div class="change-item">
                                    <div class="change-field">${fieldName}</div>
                                    ${comparison}
                                </div>
                            </div>`;
                    }
                } else if (log.new_value) {
                    html += `
                        <div class="timeline-changes">
                            <div class="change-item">
                                <div class="change-field">Value</div>
                                <div class="change-single">
                                    <div class="change-label">New Value</div>
                                    <div class="change-new">${formatValue(log.new_value)}</div>
                                </div>
                            </div>
                        </div>`;
                }
                
                html += `</div>`;
            });
            
            html += '</div>';
            container.innerHTML = html;
        }
        
        function displayTimelineError(message) {
            document.getElementById('timelineContainer').innerHTML = 
                `<div class="empty-state">
                    <div class="empty-icon">⚠️</div>
                    <div><strong>${message}</strong></div>
                    <div>Unable to load timeline data.</div>
                </div>`;
        }
        
        function getActionText(action) {
            const actionMap = {
                'create': 'Order Created',
                'update_field': 'Field Updated',
                'update_field_order_status': 'Update Field Order Status',
                'update_order_sequence': 'Order Sequence Changed',
                'delete': 'Order Deleted'
            };
            
            return actionMap[action] || action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        }
        
        function getFieldName(action) {
            if (action.includes('cut_start_date')) return 'Cut Start Date';
            if (action.includes('ship_date')) return 'Ship Date';
            if (action.includes('customer')) return 'Customer';
            if (action.includes('go_no')) return 'GO Number';
            if (action.includes('sequence')) return 'Order Sequence';
            if (action.includes('order_status')) return 'Order Status';
            return 'Field';
        }
        
        function formatDate(dateString) {
            if (!dateString) return null;
            
            try {
                const date = new Date(dateString);
                if (isNaN(date.getTime())) return dateString; // Return original if invalid date
                
                return date.toLocaleDateString('vi-VN', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric'
                });
            } catch (e) {
                return dateString;
            }
        }
        
        function compareValues(oldValue, newValue, fieldName) {
            const oldVal = formatValue(oldValue);
            const newVal = formatValue(newValue);
            
            // Check if values are the same
            if (oldVal === newVal) {
                return `
                    <div class="comparison-equal">No change detected</div>
                `;
            }
            
            // Generate comparison view
            let comparisonHtml = `
                <div class="change-comparison">
                    <div class="comparison-value comparison-old">${oldVal}</div>
                    <div class="comparison-arrow">→</div>
                    <div class="comparison-value comparison-new">${newVal}</div>
                </div>
            `;
            
            // Add change summary for specific field types
            const summary = getChangeSummary(oldValue, newValue, fieldName);
            if (summary) {
                comparisonHtml += `<div class="change-summary">${summary}</div>`;
            }
            
            // Add detailed comparison for text values (skip for numeric values)
            if (typeof oldValue === 'string' && typeof newValue === 'string' && 
                oldValue.length > 0 && newValue.length > 0 && 
                !isDateString(oldValue) && !isDateString(newValue) &&
                isNaN(oldValue) && isNaN(newValue)) {
                
                const diff = getTextDifference(oldValue, newValue);
                if (diff) {
                    comparisonHtml += `<div class="change-diff">${diff}</div>`;
                }
            }
            
            return comparisonHtml;
        }
        
        function getChangeSummary(oldValue, newValue, fieldName) {
            // Date comparisons
            if (isDateString(oldValue) && isDateString(newValue)) {
                const oldDate = new Date(oldValue);
                const newDate = new Date(newValue);
                const diffDays = Math.ceil((newDate - oldDate) / (1000 * 60 * 60 * 24));
                
                if (diffDays > 0) {
                    return `📅 Moved ${diffDays} day(s) later`;
                } else if (diffDays < 0) {
                    return `📅 Moved ${Math.abs(diffDays)} day(s) earlier`;
                }
            }
            
            // Numeric comparisons
            if (!isNaN(oldValue) && !isNaN(newValue)) {
                const oldNum = parseFloat(oldValue);
                const newNum = parseFloat(newValue);
                const diff = newNum - oldNum;
                
                if (diff > 0) {
                    return `📈 Increased by ${diff}`;
                } else if (diff < 0) {
                    return `📉 Decreased by ${Math.abs(diff)}`;
                }
            }
            
            // Text length comparison
            if (typeof oldValue === 'string' && typeof newValue === 'string') {
                const oldLen = oldValue.length;
                const newLen = newValue.length;
                
                if (newLen > oldLen) {
                    return `📝 Text expanded by ${newLen - oldLen} characters`;
                } else if (newLen < oldLen) {
                    return `📝 Text shortened by ${oldLen - newLen} characters`;
                }
            }
            
            return null;
        }
        
        function getTextDifference(oldText, newText) {
            // Simple word-based diff for short texts
            if (oldText.length > 100 || newText.length > 100) {
                return null; // Skip diff for long texts
            }
            
            const oldWords = oldText.split(/\s+/);
            const newWords = newText.split(/\s+/);
            
            // Find added and removed words
            const removed = oldWords.filter(word => !newWords.includes(word));
            const added = newWords.filter(word => !oldWords.includes(word));
            
            let diffHtml = '';
            
            if (removed.length > 0) {
                diffHtml += `<span class="diff-removed">- ${removed.join(', ')}</span> `;
            }
            
            if (added.length > 0) {
                diffHtml += `<span class="diff-added">+ ${added.join(', ')}</span>`;
            }
            
            return diffHtml || null;
        }
        
        function isDateString(value) {
            if (typeof value !== 'string') return false;
            return value.match(/^\d{4}-\d{2}-\d{2}/) !== null;
        }
        
        function formatValue(value) {
            if (!value) return 'N/A';
            
            // Try to parse JSON
            try {
                if (value.startsWith('{') || value.startsWith('[')) {
                    const parsed = JSON.parse(value);
                    return JSON.stringify(parsed, null, 2);
                }
            } catch (e) {
                // Not JSON, return as is
            }
            
            // Format dates
            if (value.match(/^\d{4}-\d{2}-\d{2}/)) {
                try {
                    const date = new Date(value);
                    return date.toLocaleDateString('vi-VN');
                } catch (e) {
                    return value;
                }
            }
            
            return value;
        }
    </script>
</body>
</html>
