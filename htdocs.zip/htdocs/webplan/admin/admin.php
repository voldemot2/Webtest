<?php
require_once '../auth.php';
require_once '../models/UserModel.php';
require_once '../models/DepartmentModel.php';
require_once '../models/OrderModel.php';

// Kiểm tra quyền admin
if (!isAdmin()) {
    header('Location: ../index.php');
    exit();
}

$userModel = new UserModel();
$departmentModel = new DepartmentModel();
$orderModel = new OrderModel();

$users = $userModel->getAllUsers();
$departments = $departmentModel->getAllDepartments();
$departmentStats = $departmentModel->getDepartmentStats();

// Get orders for order management
$orders = $orderModel->getAllOrders();
$orderStats = [
    'total' => count($orders),
    'open' => count(array_filter($orders, fn($o) => $o['order_status'] === 'Open')),
    'submit' => count(array_filter($orders, fn($o) => $o['order_status'] === 'Submit')),
    'marked' => count(array_filter($orders, fn($o) => $o['order_status'] === 'Marked'))
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - SPS Production Management</title>
    <link rel="stylesheet" href="../style.css">
    <!-- Font Awesome for icons - Offline -->
    <link rel="stylesheet" href="../libs/fontawesome/all.min.css">
    <!-- Admin Panel Styles -->
    <link rel="stylesheet" href="admin.css">
    <!-- Chart.js for data visualization - Offline -->
    <script src="../libs/chart.min.js"></script>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar" id="sidebar">
            <div class="admin-header" style="margin-bottom: 12px; padding: 8px 12px; flex-shrink: 0;">
                <h1 style="font-size: 16px; margin: 0 0 2px 0;"><i class="fas fa-tools"></i> Admin Panel</h1>
                <p style="font-size: 10px; margin: 0; color: #64748b;">SPS Production Management</p>
            </div>
            
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link active" onclick="showSection('dashboard')">
                            <i class="fas fa-chart-pie"></i>
                            Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="showSection('users')">
                            <i class="fas fa-users"></i>
                            User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="showSection('departments')">
                            <i class="fas fa-building"></i>
                            Departments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="showSection('orders')">
                            <i class="fas fa-shopping-cart"></i>
                            Order Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="showSection('order-history')">
                            <i class="fas fa-history"></i>
                            Order History
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="showSection('analytics')">
                            <i class="fas fa-chart-bar"></i>
                            Analytics
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <a href="../index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to System
                </a>
                <a href="../login.php?action=logout" class="btn btn-warning">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Dashboard Section -->
            <div class="content-section active" id="section-dashboard">
                <div class="content-card">
                    <h2 class="page-title"><i class="fas fa-chart-pie"></i> System Dashboard</h2>
                    
                    <div class="stats-grid">
                        <div class="stat-card">
                            <h3><?php echo count($users); ?></h3>
                            <p><i class="fas fa-users"></i> Total Users</p>
                        </div>
                        <div class="stat-card success">
                            <h3><?php echo count(array_filter($users, fn($u) => $u['status'] === 'active')); ?></h3>
                            <p><i class="fas fa-user-check"></i> Active Users</p>
                        </div>
                        <div class="stat-card warning">
                            <h3><?php echo $orderStats['total']; ?></h3>
                            <p><i class="fas fa-shopping-cart"></i> Total Orders</p>
                        </div>
                        <div class="stat-card danger">
                            <h3><?php echo count($departments); ?></h3>
                            <p><i class="fas fa-building"></i> Departments</p>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                        <div>
                            <h3>Order Status Distribution</h3>
                            <div class="chart-container">
                                <canvas id="orderStatusChart"></canvas>
                            </div>
                        </div>
                        <div>
                            <h3>User Role Distribution</h3>
                            <div class="chart-container">
                                <canvas id="userRoleChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="content-card">
                    <h3><i class="fas fa-building"></i> Department Statistics</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Department</th>
                                <th>Code</th>
                                <th>User Count</th>
                                <th>Description</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($departmentStats as $dept): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($dept['department_name']); ?></strong></td>
                                <td><span class="badge badge-info"><?php echo htmlspecialchars($dept['department_code']); ?></span></td>
                                <td><span class="badge badge-success"><?php echo $dept['user_count']; ?></span></td>
                                <td><?php echo htmlspecialchars($dept['description'] ?? 'No description'); ?></td>
                                <td><span class="badge badge-success">Active</span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- User Management Section -->
            <div class="content-section" id="section-users">
                <div class="content-card">
                    <div class="actions-bar">
                        <h2 class="page-title"><i class="fas fa-users"></i> User Management</h2>
                        <div style="display: flex; gap: 12px;">
                            <button class="btn btn-info" onclick="exportUsers()">
                                <i class="fas fa-download"></i> Export Users
                            </button>
                            <button class="btn btn-success" onclick="showAddUserModal()">
                                <i class="fas fa-plus"></i> Add New User
                            </button>
                        </div>
                    </div>
                    
                    <div class="search-container">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" class="search-input" placeholder="Search users by name, username, email..." id="userSearch">
                        <div class="search-filters" style="display: flex; gap: 12px; margin-top: 12px; flex-wrap: wrap;">
                            <select id="roleFilter" class="form-input" style="width: auto;">
                                <option value="">All Roles</option>
                                <option value="admin">Admin</option>
                                <option value="manager">Manager</option>
                                <option value="user">User</option>
                            </select>
                            <select id="statusFilter" class="form-input" style="width: auto;">
                                <option value="">All Status</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                            <select id="departmentFilter" class="form-input" style="width: auto;">
                                <option value="">All Departments</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?php echo htmlspecialchars($dept['department_code']); ?>">
                                        <?php echo htmlspecialchars($dept['department_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-secondary" onclick="clearFilters()" style="margin-left: auto;">
                                <i class="fas fa-times"></i> Clear Filters
                            </button>
                        </div>
                        <div id="bulk-actions" style="display: none; margin-top: 12px; padding: 12px; background: #f8fafc; border-radius: 8px;">
                            <span id="selected-count">0 users selected</span>
                            <div style="margin-top: 8px;">
                                <button class="btn btn-warning" onclick="bulkActivate()">
                                    <i class="fas fa-check"></i> Activate Selected
                                </button>
                                <button class="btn btn-secondary" onclick="bulkDeactivate()">
                                    <i class="fas fa-ban"></i> Deactivate Selected
                                </button>
                                <button class="btn btn-danger" onclick="bulkDelete()">
                                    <i class="fas fa-trash"></i> Delete Selected
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-wrapper">
                        <table class="data-table" id="usersTable">
                            <thead>
                                <tr>
                                    <th>
                                        <input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)">
                                    </th>
                                    <th>ID</th>
                                    <th>Avatar</th>
                                    <th>User Info</th>
                                    <th>Department</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Last Login</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" class="user-checkbox" value="<?php echo $user['id']; ?>" onchange="updateBulkActions()">
                                    </td>
                                    <td><strong>#<?php echo $user['id']; ?></strong></td>
                                    <td>
                                        <div style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                            <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                                            <small style="color: #64748b;">@<?php echo htmlspecialchars($user['username']); ?></small><br>
                                            <small style="color: #64748b;"><?php echo htmlspecialchars($user['email'] ?? 'No email'); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge badge-info">
                                            <?php echo htmlspecialchars($user['department_code'] ?? 'N/A'); ?>
                                        </span>
                                        <br><small><?php echo htmlspecialchars($user['department_name'] ?? 'No Department'); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $user['role'] === 'admin' ? 'warning' : ($user['role'] === 'manager' ? 'info' : 'secondary'); ?>">
                                            <i class="fas fa-<?php echo $user['role'] === 'admin' ? 'crown' : ($user['role'] === 'manager' ? 'user-tie' : 'user'); ?>"></i>
                                            <?php echo ucfirst($user['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?>">
                                            <i class="fas fa-<?php echo $user['status'] === 'active' ? 'check-circle' : 'times-circle'; ?>"></i>
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user['last_login']): ?>
                                            <div>
                                                <strong><?php echo date('d/m/Y', strtotime($user['last_login'])); ?></strong><br>
                                                <small><?php echo date('H:i', strtotime($user['last_login'])); ?></small>
                                            </div>
                                        <?php else: ?>
                                            <span class="badge badge-secondary"><i class="fas fa-question"></i> Never</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-primary" onclick="editUser(<?php echo $user['id']; ?>)" style="margin-bottom: 4px;">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                            <button class="btn btn-danger" onclick="deleteUser(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Departments Section -->
            <div class="content-section" id="section-departments">
                <div class="content-card">
                    <div class="actions-bar">
                        <h2 class="page-title"><i class="fas fa-building"></i> Department Management</h2>
                        <button class="btn btn-success" onclick="showAddDepartmentModal()">
                            <i class="fas fa-plus"></i> Add New Department
                        </button>
                    </div>
                    <p style="color: #64748b; margin-bottom: 24px;">Manage system departments and their permissions</p>
                    
                    <div class="stats-grid" style="margin-bottom: 24px;">
                        <div class="stat-card">
                            <h3><?php echo count($departments); ?></h3>
                            <p><i class="fas fa-building"></i> Total Departments</p>
                        </div>
                        <div class="stat-card success">
                            <h3><?php echo array_sum(array_column($departmentStats, 'user_count')); ?></h3>
                            <p><i class="fas fa-users"></i> Total Users</p>
                        </div>
                        <div class="stat-card warning">
                            <h3><?php echo count(array_filter($departmentStats, fn($d) => $d['user_count'] > 5)); ?></h3>
                            <p><i class="fas fa-chart-line"></i> Large Departments</p>
                        </div>
                        <div class="stat-card info">
                            <h3><?php echo count(array_filter($departmentStats, fn($d) => $d['user_count'] == 0)); ?></h3>
                            <p><i class="fas fa-exclamation-triangle"></i> Empty Departments</p>
                        </div>
                    </div>
                    
                    <div class="search-container">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" class="search-input" placeholder="Search departments by name or code..." id="departmentSearch">
                    </div>
                    
                    <div class="table-wrapper">
                        <table class="data-table" id="departmentsTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Code</th>
                                    <th>Department Name</th>
                                    <th>Description</th>
                                    <th>User Count</th>
                                    <th>Permissions</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($departmentStats as $dept): ?>
                                <tr>
                                    <td><strong>#<?php echo $dept['id']; ?></strong></td>
                                    <td><span class="badge badge-info"><?php echo htmlspecialchars($dept['department_code']); ?></span></td>
                                    <td><strong><?php echo htmlspecialchars($dept['department_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($dept['description'] ?? 'No description'); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $dept['user_count'] > 0 ? 'success' : 'secondary'; ?>">
                                            <i class="fas fa-users"></i> <?php echo $dept['user_count']; ?> users
                                        </span>
                                    </td>
                                    <td>
                                        <small style="color: #64748b;">
                                            <?php 
                                            $code = strtolower($dept['department_code']);
                                            echo "• {$code}_read<br>• {$code}_write (Manager+)";
                                            ?>
                                        </small>
                                    </td>
                                    <td><span class="badge badge-success"><i class="fas fa-check-circle"></i> Active</span></td>
                                    <td>
                                        <button class="btn btn-primary" onclick="editDepartment(<?php echo $dept['id']; ?>)" style="margin-bottom: 4px;">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button class="btn btn-info" onclick="viewDepartmentUsers(<?php echo $dept['id']; ?>)">
                                            <i class="fas fa-users"></i> Users
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Order Management Section -->
            <div class="content-section" id="section-orders">
                <div class="content-card">
                    <div class="actions-bar">
                        <h2 class="page-title"><i class="fas fa-shopping-cart"></i> Order Management</h2>
                        <div style="display: flex; gap: 12px;">
                            <select id="orderStatusFilter" class="form-input" style="width: auto;">
                                <option value="">All Status</option>
                                <option value="Open">Open</option>
                                <option value="Submit">Submit</option>
                                <option value="Loaded">Loaded</option>
                                <option value="Request">Request</option>
                                <option value="Marked">Marked</option>
                                <option value="Cancel">Cancel</option>
                            </select>
                            <button class="btn btn-info" onclick="exportOrders()">
                                <i class="fas fa-download"></i> Export
                            </button>
                            <button class="btn btn-success" onclick="showAddOrderModal()">
                                <i class="fas fa-plus"></i> Add Order
                            </button>
                        </div>
                    </div>
                    
                    <div class="stats-grid" style="margin-bottom: 24px;">
                        <div class="stat-card">
                            <h3><?php echo $orderStats['total']; ?></h3>
                            <p><i class="fas fa-shopping-cart"></i> Total Orders</p>
                        </div>
                        <div class="stat-card success">
                            <h3><?php echo $orderStats['open']; ?></h3>
                            <p><i class="fas fa-folder-open"></i> Open Orders</p>
                        </div>
                        <div class="stat-card warning">
                            <h3><?php echo $orderStats['submit']; ?></h3>
                            <p><i class="fas fa-paper-plane"></i> Submitted</p>
                        </div>
                        <div class="stat-card danger">
                            <h3><?php echo $orderStats['marked']; ?></h3>
                            <p><i class="fas fa-check-circle"></i> Completed</p>
                        </div>
                    </div>
                    
                    <div class="search-container">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" class="search-input" placeholder="Search orders by GO No, Buyer, Category..." id="orderSearch">
                        <div class="search-filters" style="display: flex; gap: 12px; margin-top: 12px; flex-wrap: wrap;">
                            <select id="customerFilter" class="form-input" style="width: auto;">
                                <option value="">All Customers</option>
                                <?php 
                                $customers = array_unique(array_column($orders, 'customer_short_name'));
                                foreach ($customers as $customer): 
                                    if ($customer):
                                ?>
                                    <option value="<?php echo htmlspecialchars($customer); ?>">
                                        <?php echo htmlspecialchars($customer); ?>
                                    </option>
                                <?php 
                                    endif;
                                endforeach; 
                                ?>
                            </select>
                            <select id="productCategoryFilter" class="form-input" style="width: auto;">
                                <option value="">All Categories</option>
                                <?php 
                                $categories = array_unique(array_filter(array_column($orders, 'product_category')));
                                foreach ($categories as $category): 
                                ?>
                                    <option value="<?php echo htmlspecialchars($category); ?>">
                                        <?php echo htmlspecialchars($category); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-secondary" onclick="clearOrderFilters()" style="margin-left: auto;">
                                <i class="fas fa-times"></i> Clear Filters
                            </button>
                        </div>
                        <div id="order-bulk-actions" style="display: none; margin-top: 12px; padding: 12px; background: #f8fafc; border-radius: 8px;">
                            <span id="order-selected-count">0 orders selected</span>
                            <div style="margin-top: 8px;">
                                <button class="btn btn-warning" onclick="bulkUpdateOrderStatus('Submit')">
                                    <i class="fas fa-paper-plane"></i> Mark as Submit
                                </button>
                                <button class="btn btn-success" onclick="bulkUpdateOrderStatus('Marked')">
                                    <i class="fas fa-check"></i> Mark as Completed
                                </button>
                                <button class="btn btn-danger" onclick="bulkUpdateOrderStatus('Cancel')">
                                    <i class="fas fa-ban"></i> Cancel Selected
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-wrapper">
                        <table class="data-table" id="ordersTable">
                            <thead>
                                <tr>
                                    <th>
                                        <input type="checkbox" id="selectAllOrders" onchange="toggleSelectAllOrders(this)">
                                    </th>
                                    <th>ID</th>
                                    <th>GO No</th>
                                    <th>Buyer</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Status</th>
                                    <th>AH Date</th>
                                    <th>Delivery Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($orders, 0, 100) as $order): ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" class="order-checkbox" value="<?php echo $order['id']; ?>" onchange="updateOrderBulkActions()">
                                    </td>
                                    <td><strong>#<?php echo $order['id']; ?></strong></td>
                                    <td><strong><?php echo htmlspecialchars($order['go_no'] ?? ''); ?></strong></td>
                                    <td><?php echo htmlspecialchars($order['customer_short_name'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($order['product_category'] ?? ''); ?></td>
                                    <td><span class="badge badge-info"><?php echo number_format($order['plan_qty'] ?? 0); ?></span></td>
                                    <td>
                                        <?php
                                        $status = $order['order_status'] ?? 'Open';
                                        $badgeClass = match($status) {
                                            'Open' => 'badge-info',
                                            'Submit' => 'badge-warning',
                                            'Loaded' => 'badge-warning',
                                            'Request' => 'badge-warning',
                                            'Marked' => 'badge-success',
                                            'Cancel' => 'badge-danger',
                                            default => 'badge-secondary'
                                        };
                                        ?>
                                        <span class="badge <?php echo $badgeClass; ?>">
                                            <?php echo $status; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($order['ah_date']): ?>
                                            <?php echo date('d/m/Y', strtotime($order['ah_date'])); ?>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Not set</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($order['delivery_date']): ?>
                                            <?php echo date('d/m/Y', strtotime($order['delivery_date'])); ?>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Not set</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-primary" onclick="viewOrder(<?php echo $order['id']; ?>)" style="margin-bottom: 4px;">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <button class="btn btn-warning" onclick="editOrder(<?php echo $order['id']; ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Order History Section -->
            <div class="content-section" id="section-order-history">
                <div class="content-card">
                    <h2 class="page-title"><i class="fas fa-history"></i> Order History & Analytics</h2>
                    
                    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 24px;">
                        <div>
                            <h3>Order Timeline</h3>
                            <div class="chart-container">
                                <canvas id="orderTimelineChart"></canvas>
                            </div>
                        </div>
                        <div>
                            <h3>Recent Activities</h3>
                            <div style="max-height: 300px; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 8px; padding: 16px;">
                                <?php 
                                $recentOrders = array_slice($orders, 0, 10);
                                foreach ($recentOrders as $order): 
                                ?>
                                <div style="padding: 8px 0; border-bottom: 1px solid #f1f5f9;">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <strong><?php echo htmlspecialchars($order['go_no'] ?? ''); ?></strong>
                                            <br><small style="color: #64748b;"><?php echo htmlspecialchars($order['customer_short_name'] ?? ''); ?></small>
                                        </div>
                                        <span class="badge badge-info"><?php echo $order['order_status'] ?? 'Open'; ?></span>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-grid" style="margin-bottom: 24px;">
                        <div>
                            <label class="form-label">Date From:</label>
                            <input type="date" class="form-input" id="dateFrom">
                        </div>
                        <div>
                            <label class="form-label">Date To:</label>
                            <input type="date" class="form-input" id="dateTo">
                        </div>
                        <div>
                            <label class="form-label">Status:</label>
                            <select class="form-input" id="historyStatusFilter">
                                <option value="">All Status</option>
                                <option value="Open">Open</option>
                                <option value="Submit">Submit</option>
                                <option value="Loaded">Loaded</option>
                                <option value="Marked">Marked</option>
                            </select>
                        </div>
                        <div style="display: flex; align-items: end;">
                            <button class="btn btn-primary" onclick="filterOrderHistory()">
                                <i class="fas fa-filter"></i> Filter
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Analytics Section -->
            <div class="content-section" id="section-analytics">
                <div class="content-card">
                    <h2 class="page-title"><i class="fas fa-chart-bar"></i> System Analytics</h2>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                        <div>
                            <h3>Department Performance</h3>
                            <div class="chart-container">
                                <canvas id="departmentPerformanceChart"></canvas>
                            </div>
                        </div>
                        <div>
                            <h3>Monthly Order Trends</h3>
                            <div class="chart-container">
                                <canvas id="monthlyTrendsChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add User Modal -->
    <div class="modal" id="addUserModal">
        <div class="modal-content">
            <h2 style="margin-bottom: 24px;"><i class="fas fa-user-plus"></i> Add New User</h2>
            <form id="addUserForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Username:</label>
                        <input type="text" name="username" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Full Name:</label>
                        <input type="text" name="full_name" class="form-input" required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Email:</label>
                        <input type="email" name="email" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Password:</label>
                        <input type="password" name="password" class="form-input" required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Department:</label>
                        <select name="department_id" class="form-input" required>
                            <option value="">Select Department</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo $dept['id']; ?>">
                                    <?php echo htmlspecialchars($dept['department_name']); ?> (<?php echo $dept['department_code']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Role:</label>
                        <select name="role" class="form-input" required>
                            <option value="user">User</option>
                            <option value="manager">Manager</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                    <button type="button" class="btn btn-secondary" onclick="closeAddUserModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-plus"></i> Create User
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit User Modal -->
    <div class="modal" id="editUserModal">
        <div class="modal-content">
            <h2 style="margin-bottom: 24px;"><i class="fas fa-user-edit"></i> Edit User</h2>
            <form id="editUserForm">
                <input type="hidden" name="id" id="edit-user-id">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Username:</label>
                        <input type="text" name="username" id="edit-username" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Full Name:</label>
                        <input type="text" name="full_name" id="edit-full-name" class="form-input" required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Email:</label>
                        <input type="email" name="email" id="edit-email" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Department:</label>
                        <select name="department_id" id="edit-department" class="form-input" required>
                            <option value="">Select Department</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo $dept['id']; ?>">
                                    <?php echo htmlspecialchars($dept['department_name']); ?> (<?php echo $dept['department_code']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Role:</label>
                        <select name="role" id="edit-role" class="form-input" required>
                            <option value="user">User</option>
                            <option value="manager">Manager</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status:</label>
                        <select name="status" id="edit-status" class="form-input" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditUserModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-warning" onclick="showChangePasswordModal()">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update User
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div class="modal" id="changePasswordModal">
        <div class="modal-content">
            <h2 style="margin-bottom: 24px;"><i class="fas fa-key"></i> Change Password</h2>
            <form id="changePasswordForm">
                <input type="hidden" name="id" id="password-user-id">
                <div class="form-group">
                    <label class="form-label">New Password:</label>
                    <input type="password" name="new_password" id="new-password" class="form-input" required>
                    <small style="color: #64748b;">Password should be at least 6 characters long</small>
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm Password:</label>
                    <input type="password" name="confirm_password" id="confirm-password" class="form-input" required>
                </div>
                
                <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                    <button type="button" class="btn btn-secondary" onclick="closeChangePasswordModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-key"></i> Update Password
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Department Modal -->
    <div class="modal" id="addDepartmentModal">
        <div class="modal-content">
            <h2 style="margin-bottom: 24px;"><i class="fas fa-building"></i> Add New Department</h2>
            <form id="addDepartmentForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Department Code:</label>
                        <input type="text" name="department_code" class="form-input" placeholder="e.g., IT, HR, PROD" required>
                        <small style="color: #64748b;">Short code for the department (2-5 characters)</small>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Department Name:</label>
                        <input type="text" name="department_name" class="form-input" placeholder="e.g., Information Technology" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Description:</label>
                    <textarea name="description" class="form-input" rows="3" placeholder="Brief description of the department's role and responsibilities"></textarea>
                </div>
                
                <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                    <button type="button" class="btn btn-secondary" onclick="closeAddDepartmentModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-plus"></i> Create Department
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Order Modal -->
    <div class="modal" id="viewOrderModal">
        <div class="modal-content" style="max-width: 800px;">
            <h2 style="margin-bottom: 24px;"><i class="fas fa-eye"></i> Order Details</h2>
            <div id="orderDetailsContent">
                <!-- Order details will be loaded here -->
            </div>
            <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                <button type="button" class="btn btn-secondary" onclick="closeViewOrderModal()">
                    <i class="fas fa-times"></i> Close
                </button>
                <button type="button" class="btn btn-primary" onclick="editOrderFromView()">
                    <i class="fas fa-edit"></i> Edit Order
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Order Modal -->
    <div class="modal" id="editOrderModal">
        <div class="modal-content" style="max-width: 900px;">
            <h2 style="margin-bottom: 24px;"><i class="fas fa-edit"></i> Edit Order</h2>
            <form id="editOrderForm">
                <input type="hidden" name="id" id="edit-order-id">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Customer Short Name:</label>
                        <input type="text" name="customer_short_name" id="edit-customer-short-name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">GO No:</label>
                        <input type="text" name="go_no" id="edit-go-no" class="form-input" required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Style No:</label>
                        <input type="text" name="style_no" id="edit-style-no" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">JO No:</label>
                        <input type="text" name="jo_no" id="edit-jo-no" class="form-input">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Color Code:</label>
                        <input type="text" name="color_code" id="edit-color-code" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Product Category:</label>
                        <input type="text" name="product_category" id="edit-product-category" class="form-input">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Wash Type:</label>
                        <input type="text" name="wash_type" id="edit-wash-type" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Plan Quantity:</label>
                        <input type="number" name="plan_qty" id="edit-plan-qty" class="form-input">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Target Output:</label>
                        <input type="number" name="target_output" id="edit-target-output" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Order Status:</label>
                        <select name="order_status" id="edit-order-status" class="form-input" required>
                            <option value="Open">Open</option>
                            <option value="Submit">Submit</option>
                            <option value="Loaded">Loaded</option>
                            <option value="Request">Request</option>
                            <option value="Marked">Marked</option>
                            <option value="Cancel">Cancel</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Delivery Date:</label>
                        <input type="date" name="delivery_date" id="edit-delivery-date" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">AH Date:</label>
                        <input type="date" name="ah_date" id="edit-ah-date" class="form-input">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Marker Date:</label>
                        <input type="date" name="marker_date" id="edit-marker-date" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Cut Start Date:</label>
                        <input type="date" name="cut_start_date" id="edit-cut-start-date" class="form-input">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Sewing Start Date:</label>
                        <input type="date" name="sewing_start_date" id="edit-sewing-start-date" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">SM Date:</label>
                        <input type="date" name="sm_date" id="edit-sm-date" class="form-input">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Remark:</label>
                    <textarea name="remark" id="edit-remark" class="form-input" rows="3"></textarea>
                </div>
                
                <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditOrderModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Order
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Initialize charts when page loads
        document.addEventListener('DOMContentLoaded', function() {
            initializeCharts();
            
            // Initialize filters
            filterUsers();
            filterOrders();
            
            // Check URL hash to show correct section
            const hash = window.location.hash.substring(1);
            if (hash && document.getElementById('section-' + hash)) {
                showSection(hash);
            } else {
                // Default to dashboard if no hash
                showSection('dashboard');
            }
            
            console.log('Admin panel loaded successfully');
        });
        
        function showSection(sectionName) {
            // Hide all sections
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
            });
            
            // Show selected section
            document.getElementById('section-' + sectionName).classList.add('active');
            
            // Activate corresponding nav link
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                const onclick = link.getAttribute('onclick');
                if (onclick && onclick.includes(`'${sectionName}'`)) {
                    link.classList.add('active');
                }
            });
            
            // Update URL hash to remember current section
            window.location.hash = sectionName;
        }

        function initializeCharts() {
            // Order Status Chart
            const orderCtx = document.getElementById('orderStatusChart');
            if (orderCtx) {
                new Chart(orderCtx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Open', 'Submit', 'Loaded', 'Marked'],
                        datasets: [{
                            data: [<?php echo $orderStats['open']; ?>, <?php echo $orderStats['submit']; ?>, 0, <?php echo $orderStats['marked']; ?>],
                            backgroundColor: ['#3b82f6', '#f59e0b', '#8b5cf6', '#10b981']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        }
                    }
                });
            }

            // User Role Chart
            const userCtx = document.getElementById('userRoleChart');
            if (userCtx) {
                const adminCount = <?php echo count(array_filter($users, fn($u) => $u['role'] === 'admin')); ?>;
                const managerCount = <?php echo count(array_filter($users, fn($u) => $u['role'] === 'manager')); ?>;
                const userCount = <?php echo count(array_filter($users, fn($u) => $u['role'] === 'user')); ?>;
                
                new Chart(userCtx, {
                    type: 'pie',
                    data: {
                        labels: ['Admin', 'Manager', 'User'],
                        datasets: [{
                            data: [adminCount, managerCount, userCount],
                            backgroundColor: ['#ef4444', '#3b82f6', '#6b7280']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        }
                    }
                });
            }
        }

        // Enhanced search functionality with debugging
        document.getElementById('userSearch')?.addEventListener('input', filterUsers);
        document.getElementById('roleFilter')?.addEventListener('change', filterUsers);
        document.getElementById('statusFilter')?.addEventListener('change', filterUsers);
        document.getElementById('departmentFilter')?.addEventListener('change', filterUsers);

        function filterUsers() {
            const searchTerm = document.getElementById('userSearch')?.value.toLowerCase() || '';
            const roleFilter = document.getElementById('roleFilter')?.value.toLowerCase() || '';
            const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';
            const departmentFilter = document.getElementById('departmentFilter')?.value.toLowerCase() || '';
            
            const rows = document.querySelectorAll('#usersTable tbody tr');
            let visibleCount = 0;
            
            console.log('Filtering with:', {searchTerm, roleFilter, statusFilter, departmentFilter}); // Debug
            
            rows.forEach((row, index) => {
                try {
                    const text = row.textContent.toLowerCase();
                    // Updated cell indices: 0=checkbox, 1=id, 2=avatar, 3=user_info, 4=department, 5=role, 6=status, 7=last_login, 8=actions
                    const roleCell = row.cells[5]?.textContent.toLowerCase().trim() || '';
                    const statusCell = row.cells[6]?.textContent.toLowerCase().trim() || '';
                    const deptBadge = row.cells[4]?.querySelector('.badge');
                    const deptCell = deptBadge ? deptBadge.textContent.toLowerCase().trim() : '';
                    
                    const matchesSearch = !searchTerm || text.includes(searchTerm);
                    const matchesRole = !roleFilter || roleCell.includes(roleFilter);
                    const matchesStatus = !statusFilter || statusCell.includes(statusFilter);
                    const matchesDept = !departmentFilter || deptCell.includes(departmentFilter);
                    
                    const shouldShow = matchesSearch && matchesRole && matchesStatus && matchesDept;
                    
                    if (index < 3) { // Debug first 3 rows
                        console.log(`Row ${index}:`, {
                            roleCell, statusCell, deptCell,
                            matchesSearch, matchesRole, matchesStatus, matchesDept, shouldShow
                        });
                    }
                    
                    row.style.display = shouldShow ? '' : 'none';
                    
                    if (shouldShow) visibleCount++;
                } catch (error) {
                    console.error('Error filtering row:', error, row);
                    row.style.display = ''; // Show row if error
                    visibleCount++;
                }
            });
            
            // Update result count
            updateResultCount('users', visibleCount, rows.length);
            console.log(`Filtered: ${visibleCount}/${rows.length} visible`); // Debug
        }

        function clearFilters() {
            const userSearch = document.getElementById('userSearch');
            const roleFilter = document.getElementById('roleFilter');
            const statusFilter = document.getElementById('statusFilter');
            const departmentFilter = document.getElementById('departmentFilter');
            const selectAll = document.getElementById('selectAll');
            
            if (userSearch) userSearch.value = '';
            if (roleFilter) roleFilter.value = '';
            if (statusFilter) statusFilter.value = '';
            if (departmentFilter) departmentFilter.value = '';
            if (selectAll) selectAll.checked = false;
            
            // Clear bulk selections
            document.querySelectorAll('.user-checkbox').forEach(cb => cb.checked = false);
            updateBulkActions();
            
            // Re-filter
            filterUsers();
            
            console.log('Filters cleared');
        }

        // Export functionality
        function exportUsers() {
            const table = document.getElementById('usersTable');
            const rows = Array.from(table.querySelectorAll('tbody tr')).filter(row => row.style.display !== 'none');
            
            if (rows.length === 0) {
                showNotification('No users to export', 'error');
                return;
            }
            
            const csvContent = [];
            
            // Header
            const headers = ['ID', 'Username', 'Full Name', 'Email', 'Department', 'Role', 'Status', 'Last Login'];
            csvContent.push(headers.join(','));
            
            // Data rows
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                const data = [
                    cells[0]?.textContent.replace('#', '') || '', // ID
                    cells[2]?.querySelector('strong')?.textContent || '', // Username from User Info
                    cells[2]?.textContent.split('@')[0]?.trim() || '', // Full name
                    cells[2]?.textContent.split('\n')[2]?.trim() || '', // Email
                    cells[3]?.querySelector('.badge')?.textContent || '', // Department
                    cells[4]?.textContent.trim() || '', // Role
                    cells[5]?.textContent.trim() || '', // Status
                    cells[6]?.querySelector('strong')?.textContent || 'Never' // Last Login
                ];
                
                // Escape commas and quotes
                const escapedData = data.map(cell => {
                    if (cell.includes(',') || cell.includes('"') || cell.includes('\n')) {
                        return `"${cell.replace(/"/g, '""')}"`;
                    }
                    return cell;
                });
                
                csvContent.push(escapedData.join(','));
            });
            
            // Download CSV
            const blob = new Blob([csvContent.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            
            if (link.download !== undefined) {
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', `users_export_${new Date().toISOString().split('T')[0]}.csv`);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                showNotification(`Exported ${rows.length} users successfully!`, 'success');
            } else {
                showNotification('Export not supported in this browser', 'error');
            }
        }

        function updateResultCount(type, visible, total) {
            let countElement = document.getElementById(`${type}-count`);
            if (!countElement) {
                countElement = document.createElement('div');
                countElement.id = `${type}-count`;
                countElement.style.cssText = 'margin-top: 8px; font-size: 12px; color: #64748b; font-weight: 500;';
                const searchContainer = document.querySelector(`#section-${type} .search-container`);
                if (searchContainer) {
                    searchContainer.appendChild(countElement);
                }
            }
            
            if (countElement) {
                const percentage = total > 0 ? Math.round((visible / total) * 100) : 0;
                countElement.innerHTML = `<i class="fas fa-filter" style="margin-right: 4px;"></i>Showing <strong>${visible}</strong> of <strong>${total}</strong> records (${percentage}%)`;
            }
        }

        // Bulk actions functionality
        function toggleSelectAll(checkbox) {
            const userCheckboxes = document.querySelectorAll('.user-checkbox');
            userCheckboxes.forEach(cb => {
                if (cb.closest('tr').style.display !== 'none') {
                    cb.checked = checkbox.checked;
                }
            });
            updateBulkActions();
        }

        function updateBulkActions() {
            const checkedBoxes = document.querySelectorAll('.user-checkbox:checked');
            const bulkActions = document.getElementById('bulk-actions');
            const selectedCount = document.getElementById('selected-count');
            
            if (checkedBoxes.length > 0) {
                bulkActions.style.display = 'block';
                selectedCount.textContent = `${checkedBoxes.length} user${checkedBoxes.length > 1 ? 's' : ''} selected`;
            } else {
                bulkActions.style.display = 'none';
            }
        }

        async function bulkActivate() {
            const checkedBoxes = document.querySelectorAll('.user-checkbox:checked');
            const userIds = Array.from(checkedBoxes).map(cb => cb.value);
            
            if (userIds.length === 0) return;
            
            if (!confirm(`Are you sure you want to activate ${userIds.length} user(s)?`)) return;
            
            try {
                const promises = userIds.map(async (userId) => {
                    const formData = new FormData();
                    formData.append('action', 'update_user');
                    formData.append('id', userId);
                    formData.append('status', 'active');
                    
                    // Get current user data first
                    const userResponse = await fetch(`user_process.php?action=get_user&id=${userId}`);
                    const userResult = await userResponse.json();
                    
                    if (userResult.success) {
                        const user = userResult.user;
                        formData.append('username', user.username);
                        formData.append('full_name', user.full_name);
                        formData.append('email', user.email || '');
                        formData.append('department_id', user.department_id || '');
                        formData.append('role', user.role);
                        
                        return fetch('user_process.php', {
                            method: 'POST',
                            body: formData
                        });
                    }
                });
                
                await Promise.all(promises);
                showNotification(`${userIds.length} user(s) activated successfully!`, 'success');
                // Stay on User Management page and refresh data
                showSection('users');
                setTimeout(refreshUsersData, 500);
                
            } catch (error) {
                showNotification('Error during bulk activation', 'error');
            }
        }

        async function bulkDeactivate() {
            const checkedBoxes = document.querySelectorAll('.user-checkbox:checked');
            const userIds = Array.from(checkedBoxes).map(cb => cb.value);
            
            if (userIds.length === 0) return;
            
            if (!confirm(`Are you sure you want to deactivate ${userIds.length} user(s)?`)) return;
            
            try {
                const promises = userIds.map(async (userId) => {
                    const formData = new FormData();
                    formData.append('action', 'update_user');
                    formData.append('id', userId);
                    formData.append('status', 'inactive');
                    
                    // Get current user data first
                    const userResponse = await fetch(`user_process.php?action=get_user&id=${userId}`);
                    const userResult = await userResponse.json();
                    
                    if (userResult.success) {
                        const user = userResult.user;
                        formData.append('username', user.username);
                        formData.append('full_name', user.full_name);
                        formData.append('email', user.email || '');
                        formData.append('department_id', user.department_id || '');
                        formData.append('role', user.role);
                        
                        return fetch('user_process.php', {
                            method: 'POST',
                            body: formData
                        });
                    }
                });
                
                await Promise.all(promises);
                showNotification(`${userIds.length} user(s) deactivated successfully!`, 'success');
                // Stay on User Management page and refresh data
                showSection('users');
                setTimeout(refreshUsersData, 500);
                
            } catch (error) {
                showNotification('Error during bulk deactivation', 'error');
            }
        }

        async function bulkDelete() {
            const checkedBoxes = document.querySelectorAll('.user-checkbox:checked');
            const userIds = Array.from(checkedBoxes).map(cb => cb.value);
            
            if (userIds.length === 0) return;
            
            if (!confirm(`Are you sure you want to delete ${userIds.length} user(s)? This action cannot be undone.`)) return;
            
            try {
                const promises = userIds.map(userId => {
                    const formData = new FormData();
                    formData.append('action', 'delete_user');
                    formData.append('id', userId);
                    
                    return fetch('user_process.php', {
                        method: 'POST',
                        body: formData
                    });
                });
                
                await Promise.all(promises);
                showNotification(`${userIds.length} user(s) deleted successfully!`, 'success');
                // Stay on User Management page and refresh data
                showSection('users');
                setTimeout(refreshUsersData, 500);
                
            } catch (error) {
                showNotification('Error during bulk deletion', 'error');
            }
        }

        document.getElementById('orderSearch')?.addEventListener('input', function() {
            filterOrders();
        });
        
        document.getElementById('orderStatusFilter')?.addEventListener('change', function() {
            filterOrders();
        });
        
        document.getElementById('customerFilter')?.addEventListener('change', function() {
            filterOrders();
        });
        
        document.getElementById('productCategoryFilter')?.addEventListener('change', function() {
            filterOrders();
        });

        function filterOrders() {
            const searchTerm = document.getElementById('orderSearch')?.value.toLowerCase() || '';
            const statusFilter = document.getElementById('orderStatusFilter')?.value.toLowerCase() || '';
            const customerFilter = document.getElementById('customerFilter')?.value.toLowerCase() || '';
            const categoryFilter = document.getElementById('productCategoryFilter')?.value.toLowerCase() || '';
            
            const rows = document.querySelectorAll('#ordersTable tbody tr');
            let visibleCount = 0;
            
            rows.forEach(row => {
                try {
                    const text = row.textContent.toLowerCase();
                    // Updated cell indices after removing Style column: 0=checkbox, 1=id, 2=go_no, 3=buyer, 4=category, 5=qty, 6=status, 7=ah_date, 8=delivery_date, 9=actions
                    const statusCell = row.cells[6]?.textContent.toLowerCase().trim() || '';
                    const customerCell = row.cells[3]?.textContent.toLowerCase().trim() || '';
                    const categoryCell = row.cells[4]?.textContent.toLowerCase().trim() || '';
                    
                    const matchesSearch = !searchTerm || text.includes(searchTerm);
                    const matchesStatus = !statusFilter || statusCell.includes(statusFilter);
                    const matchesCustomer = !customerFilter || customerCell.includes(customerFilter);
                    const matchesCategory = !categoryFilter || categoryCell.includes(categoryFilter);
                    
                    const shouldShow = matchesSearch && matchesStatus && matchesCustomer && matchesCategory;
                    
                    row.style.display = shouldShow ? '' : 'none';
                    
                    if (shouldShow) visibleCount++;
                } catch (error) {
                    console.error('Error filtering order row:', error);
                    row.style.display = '';
                    visibleCount++;
                }
            });
            
            // Update result count
            updateResultCount('orders', visibleCount, rows.length);
        }

        function clearOrderFilters() {
            const orderSearch = document.getElementById('orderSearch');
            const statusFilter = document.getElementById('orderStatusFilter');
            const customerFilter = document.getElementById('customerFilter');
            const categoryFilter = document.getElementById('productCategoryFilter');
            const selectAll = document.getElementById('selectAllOrders');
            
            if (orderSearch) orderSearch.value = '';
            if (statusFilter) statusFilter.value = '';
            if (customerFilter) customerFilter.value = '';
            if (categoryFilter) categoryFilter.value = '';
            if (selectAll) selectAll.checked = false;
            
            // Clear bulk selections
            document.querySelectorAll('.order-checkbox').forEach(cb => cb.checked = false);
            updateOrderBulkActions();
            
            // Re-filter
            filterOrders();
        }

        // Order bulk actions
        function toggleSelectAllOrders(checkbox) {
            const orderCheckboxes = document.querySelectorAll('.order-checkbox');
            orderCheckboxes.forEach(cb => {
                if (cb.closest('tr').style.display !== 'none') {
                    cb.checked = checkbox.checked;
                }
            });
            updateOrderBulkActions();
        }

        function updateOrderBulkActions() {
            const checkedBoxes = document.querySelectorAll('.order-checkbox:checked');
            const bulkActions = document.getElementById('order-bulk-actions');
            const selectedCount = document.getElementById('order-selected-count');
            
            if (checkedBoxes.length > 0) {
                bulkActions.style.display = 'block';
                selectedCount.textContent = `${checkedBoxes.length} order${checkedBoxes.length > 1 ? 's' : ''} selected`;
            } else {
                bulkActions.style.display = 'none';
            }
        }

        async function bulkUpdateOrderStatus(newStatus) {
            const checkedBoxes = document.querySelectorAll('.order-checkbox:checked');
            const orderIds = Array.from(checkedBoxes).map(cb => cb.value);
            
            if (orderIds.length === 0) return;
            
            if (!confirm(`Are you sure you want to update ${orderIds.length} order(s) to "${newStatus}" status?`)) return;
            
            try {
                const promises = orderIds.map(async (orderId) => {
                    const formData = new FormData();
                    formData.append('action', 'update_order_status');
                    formData.append('id', orderId);
                    formData.append('order_status', newStatus);
                    
                    return fetch('../process.php', {
                        method: 'POST',
                        body: formData
                    });
                });
                
                await Promise.all(promises);
                showNotification(`${orderIds.length} order(s) updated to "${newStatus}" successfully!`, 'success');
                // Stay on Order Management page and refresh data
                showSection('orders');
                setTimeout(() => location.reload(), 1000);
                
            } catch (error) {
                showNotification('Error during bulk status update', 'error');
            }
        }

        document.getElementById('departmentSearch')?.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#departmentsTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });

        // Modal functions
        function showAddUserModal() {
            document.getElementById('addUserModal').classList.add('show');
        }

        function closeAddUserModal() {
            document.getElementById('addUserModal').classList.remove('show');
            document.getElementById('addUserForm').reset();
        }

        function showEditUserModal() {
            document.getElementById('editUserModal').classList.add('show');
        }

        function closeEditUserModal() {
            document.getElementById('editUserModal').classList.remove('show');
            document.getElementById('editUserForm').reset();
        }

        function showChangePasswordModal() {
            const userId = document.getElementById('edit-user-id').value;
            document.getElementById('password-user-id').value = userId;
            closeEditUserModal();
            document.getElementById('changePasswordModal').classList.add('show');
        }

        function closeChangePasswordModal() {
            document.getElementById('changePasswordModal').classList.remove('show');
            document.getElementById('changePasswordForm').reset();
        }

        function showAddDepartmentModal() {
            document.getElementById('addDepartmentModal').classList.add('show');
        }

        function closeAddDepartmentModal() {
            document.getElementById('addDepartmentModal').classList.remove('show');
            document.getElementById('addDepartmentForm').reset();
        }

        // Enhanced user data refresh function
        async function refreshUsersData() {
            try {
                // Show loading indicator
                const usersTable = document.getElementById('usersTable');
                const tbody = usersTable.querySelector('tbody');
                const originalContent = tbody.innerHTML;
                
                tbody.innerHTML = '<tr><td colspan="9" style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>';
                
                // Fetch fresh data
                const response = await fetch(window.location.href);
                const text = await response.text();
                
                // Parse the response to extract user table content
                const parser = new DOMParser();
                const doc = parser.parseFromString(text, 'text/html');
                const newTbody = doc.querySelector('#usersTable tbody');
                
                if (newTbody) {
                    tbody.innerHTML = newTbody.innerHTML;
                    
                    // Reapply current filters
                    setTimeout(filterUsers, 100);
                    
                    // Reset bulk selections
                    document.getElementById('selectAll').checked = false;
                    updateBulkActions();
                } else {
                    tbody.innerHTML = originalContent;
                    showNotification('Failed to refresh user data', 'error');
                }
                
            } catch (error) {
                console.error('Error refreshing users:', error);
                showNotification('Error refreshing user data', 'error');
            }
        }

        // Add user form
        document.getElementById('addUserForm')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'create_user');
            
            try {
                const response = await fetch('user_process.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('User created successfully!', 'success');
                    closeAddUserModal();
                    // Stay on User Management page and refresh data
                    showSection('users');
                    setTimeout(refreshUsersData, 500);
                } else {
                    showNotification('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        });

        // Edit user form
        document.getElementById('editUserForm')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'update_user');
            
            try {
                const response = await fetch('user_process.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('User updated successfully!', 'success');
                    closeEditUserModal();
                    // Stay on User Management page and refresh data
                    showSection('users');
                    setTimeout(refreshUsersData, 500);
                } else {
                    showNotification('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        });

        // Change password form
        document.getElementById('changePasswordForm')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const newPassword = document.getElementById('new-password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            
            if (newPassword !== confirmPassword) {
                showNotification('Passwords do not match!', 'error');
                return;
            }
            
            if (newPassword.length < 6) {
                showNotification('Password must be at least 6 characters long!', 'error');
                return;
            }
            
            const formData = new FormData(this);
            formData.append('action', 'update_password');
            
            try {
                const response = await fetch('user_process.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('Password updated successfully!', 'success');
                    closeChangePasswordModal();
                } else {
                    showNotification('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        });

        async function editUser(userId) {
            try {
                const response = await fetch(`user_process.php?action=get_user&id=${userId}`);
                const result = await response.json();
                
                if (result.success) {
                    const user = result.user;
                    
                    // Fill form with user data
                    document.getElementById('edit-user-id').value = user.id;
                    document.getElementById('edit-username').value = user.username;
                    document.getElementById('edit-full-name').value = user.full_name;
                    document.getElementById('edit-email').value = user.email || '';
                    document.getElementById('edit-department').value = user.department_id || '';
                    document.getElementById('edit-role').value = user.role;
                    document.getElementById('edit-status').value = user.status;
                    
                    showEditUserModal();
                } else {
                    showNotification('Error loading user data: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        }

        async function deleteUser(userId) {
            if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('action', 'delete_user');
                formData.append('id', userId);
                
                const response = await fetch('user_process.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('User deleted successfully!', 'success');
                    // Stay on User Management page and refresh data
                    showSection('users');
                    setTimeout(refreshUsersData, 500);
                } else {
                    showNotification('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        }

        // Notification system
        function showNotification(message, type = 'info') {
            // Remove existing notifications
            const existingNotifications = document.querySelectorAll('.notification');
            existingNotifications.forEach(n => n.remove());
            
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#16a34a' : type === 'error' ? '#dc2626' : '#2563eb'};
                color: white;
                padding: 16px 24px;
                border-radius: 8px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                z-index: 10000;
                max-width: 400px;
                word-wrap: break-word;
                animation: slideIn 0.3s ease-out;
            `;
            
            const icon = type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle';
            notification.innerHTML = `<i class="fas fa-${icon}" style="margin-right: 8px;"></i>${message}`;
            
            document.body.appendChild(notification);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.style.animation = 'slideOut 0.3s ease-in forwards';
                    setTimeout(() => notification.remove(), 300);
                }
            }, 5000);
        }

        // Add CSS for notification animations
        const notificationStyles = document.createElement('style');
        notificationStyles.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(notificationStyles);

        function editDepartment(departmentId) {
            alert('Edit department functionality - ID: ' + departmentId);
        }

        function viewDepartmentUsers(departmentId) {
            alert('View department users - ID: ' + departmentId);
        }

        // Add department form
        document.getElementById('addDepartmentForm')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'create_department');
            
            try {
                // Simulate department creation
                alert('Department creation functionality - coming soon!');
                closeAddDepartmentModal();
            } catch (error) {
                alert('Network error occurred');
            }
        });

        // Modal functions for orders
        function showViewOrderModal() {
            document.getElementById('viewOrderModal').classList.add('show');
        }

        function closeViewOrderModal() {
            document.getElementById('viewOrderModal').classList.remove('show');
        }

        function showEditOrderModal() {
            document.getElementById('editOrderModal').classList.add('show');
        }

        function closeEditOrderModal() {
            document.getElementById('editOrderModal').classList.remove('show');
            document.getElementById('editOrderForm').reset();
        }

        let currentOrderId = null;

        async function viewOrder(orderId) {
            currentOrderId = orderId;
            try {
                const response = await fetch(`../process.php?action=get_order&id=${orderId}`);
                const result = await response.json();
                
                if (result.success) {
                    const order = result.data;
                    displayOrderDetails(order);
                    showViewOrderModal();
                } else {
                    showNotification('Error loading order data: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        }

        function displayOrderDetails(order) {
            const content = document.getElementById('orderDetailsContent');
            content.innerHTML = `
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                    <div>
                        <h3><i class="fas fa-info-circle"></i> Order Information</h3>
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Order ID:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">#${order.id}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">GO No:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.go_no || 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Style No:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.style_no || 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">JO No:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.jo_no || 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Customer:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.customer_short_name || 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Color Code:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.color_code || 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Product Category:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.product_category || 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Wash Type:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.wash_type || 'N/A'}</td></tr>
                        </table>
                    </div>
                    
                    <div>
                        <h3><i class="fas fa-chart-line"></i> Production Details</h3>
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Plan Quantity:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.plan_qty ? parseInt(order.plan_qty).toLocaleString() : 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Target Output:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.target_output ? parseInt(order.target_output).toLocaleString() : 'N/A'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Order Status:</td><td style="padding: 8px; border-bottom: 1px solid #eee;"><span class="badge badge-${getStatusBadgeClass(order.order_status)}">${order.order_status || 'Open'}</span></td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Delivery Date:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.delivery_date ? new Date(order.delivery_date).toLocaleDateString('vi-VN') : 'Not set'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">AH Date:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.ah_date ? new Date(order.ah_date).toLocaleDateString('vi-VN') : 'Not set'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Marker Date:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.marker_date ? new Date(order.marker_date).toLocaleDateString('vi-VN') : 'Not set'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Cut Start Date:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.cut_start_date ? new Date(order.cut_start_date).toLocaleDateString('vi-VN') : 'Not set'}</td></tr>
                            <tr><td style="padding: 8px; font-weight: bold; border-bottom: 1px solid #eee;">Sewing Start Date:</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.sewing_start_date ? new Date(order.sewing_start_date).toLocaleDateString('vi-VN') : 'Not set'}</td></tr>
                        </table>
                    </div>
                </div>
                
                ${order.remark ? `
                <div style="margin-top: 24px;">
                    <h3><i class="fas fa-comment"></i> Remark</h3>
                    <div style="padding: 12px; background: #f8fafc; border-radius: 8px; border-left: 4px solid #3b82f6;">
                        ${order.remark}
                    </div>
                </div>
                ` : ''}
            `;
        }

        function getStatusBadgeClass(status) {
            const statusMap = {
                'Open': 'info',
                'Submit': 'warning',
                'Loaded': 'warning',
                'Request': 'warning',
                'Marked': 'success',
                'Cancel': 'danger'
            };
            return statusMap[status] || 'secondary';
        }

        function editOrderFromView() {
            closeViewOrderModal();
            editOrder(currentOrderId);
        }

        async function editOrder(orderId) {
            try {
                const response = await fetch(`../process.php?action=get_order&id=${orderId}`);
                const result = await response.json();
                
                if (result.success) {
                    const order = result.data;
                    
                    // Fill form with order data
                    document.getElementById('edit-order-id').value = order.id;
                    document.getElementById('edit-customer-short-name').value = order.customer_short_name || '';
                    document.getElementById('edit-go-no').value = order.go_no || '';
                    document.getElementById('edit-style-no').value = order.style_no || '';
                    document.getElementById('edit-jo-no').value = order.jo_no || '';
                    document.getElementById('edit-color-code').value = order.color_code || '';
                    document.getElementById('edit-product-category').value = order.product_category || '';
                    document.getElementById('edit-wash-type').value = order.wash_type || '';
                    document.getElementById('edit-plan-qty').value = order.plan_qty || '';
                    document.getElementById('edit-target-output').value = order.target_output || '';
                    document.getElementById('edit-order-status').value = order.order_status || 'Open';
                    document.getElementById('edit-delivery-date').value = order.delivery_date || '';
                    document.getElementById('edit-ah-date').value = order.ah_date || '';
                    document.getElementById('edit-marker-date').value = order.marker_date || '';
                    document.getElementById('edit-cut-start-date').value = order.cut_start_date || '';
                    document.getElementById('edit-sewing-start-date').value = order.sewing_start_date || '';
                    document.getElementById('edit-sm-date').value = order.sm_date || '';
                    document.getElementById('edit-remark').value = order.remark || '';
                    
                    showEditOrderModal();
                } else {
                    showNotification('Error loading order data: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        }

        // Edit order form submission
        document.getElementById('editOrderForm')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'update_order');
            
            try {
                const response = await fetch('../process.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('Order updated successfully!', 'success');
                    closeEditOrderModal();
                    // Stay on Order Management page and refresh data
                    showSection('orders');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotification('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showNotification('Network error occurred', 'error');
            }
        });

        function exportOrders() {
            const table = document.getElementById('ordersTable');
            const rows = Array.from(table.querySelectorAll('tbody tr')).filter(row => row.style.display !== 'none');
            
            if (rows.length === 0) {
                showNotification('No orders to export', 'error');
                return;
            }
            
            const csvContent = [];
            
            // Header (removed Style)
            const headers = ['ID', 'GO No', 'Customer', 'Category', 'Quantity', 'Status', 'AH Date', 'Delivery Date'];
            csvContent.push(headers.join(','));
            
            // Data rows
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                const data = [
                    cells[1]?.textContent.replace('#', '') || '', // ID
                    cells[2]?.textContent || '', // GO No
                    cells[3]?.textContent || '', // Customer
                    cells[4]?.textContent || '', // Category
                    cells[5]?.textContent.replace(',', '') || '', // Quantity (remove commas)
                    cells[6]?.textContent.trim() || '', // Status
                    cells[7]?.textContent || '', // AH Date
                    cells[8]?.textContent || '' // Delivery Date
                ];
                
                // Escape commas and quotes
                const escapedData = data.map(cell => {
                    if (cell.includes(',') || cell.includes('"') || cell.includes('\n')) {
                        return `"${cell.replace(/"/g, '""')}"`;
                    }
                    return cell;
                });
                
                csvContent.push(escapedData.join(','));
            });
            
            // Download CSV
            const blob = new Blob([csvContent.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            
            if (link.download !== undefined) {
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', `orders_export_${new Date().toISOString().split('T')[0]}.csv`);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                showNotification(`Exported ${rows.length} orders successfully!`, 'success');
            } else {
                showNotification('Export not supported in this browser', 'error');
            }
        }

        function showAddOrderModal() {
            // Placeholder for add order functionality
            showNotification('Add Order functionality - coming soon!', 'info');
        }

        function filterOrderHistory() {
            const dateFrom = document.getElementById('dateFrom').value;
            const dateTo = document.getElementById('dateTo').value;
            const status = document.getElementById('historyStatusFilter').value;
            
            // Build query parameters
            const params = new URLSearchParams();
            if (dateFrom) params.append('date_from', dateFrom);
            if (dateTo) params.append('date_to', dateTo);
            if (status) params.append('action', status);
            params.append('limit', '100');
            
            // Fetch activity logs
            fetch(`../process.php?action=get_activity_logs&${params.toString()}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayActivityLogs(data.logs, data.total);
                    } else {
                        alert('Error loading activity logs: ' + (data.error || 'Unknown error'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error loading activity logs');
                });
        }
        
        function displayActivityLogs(logs, total) {
            const container = document.getElementById('activity-logs-container');
            if (!container) {
                // Create container if doesn't exist
                const section = document.getElementById('section-order-history');
                const card = section.querySelector('.content-card');
                const newContainer = document.createElement('div');
                newContainer.id = 'activity-logs-container';
                newContainer.innerHTML = '<h3>Activity Logs</h3>';
                card.appendChild(newContainer);
            }
            
            let html = `<div style="margin-bottom: 12px;">
                <strong>Total Records: ${total}</strong>
            </div>
            <div style="max-height: 400px; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 8px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background-color: #f8f9fa; position: sticky; top: 0;">
                        <tr>
                            <th style="padding: 8px; border-bottom: 1px solid #dee2e6;">Time</th>
                            <th style="padding: 8px; border-bottom: 1px solid #dee2e6;">User</th>
                            <th style="padding: 8px; border-bottom: 1px solid #dee2e6;">Order</th>
                            <th style="padding: 8px; border-bottom: 1px solid #dee2e6;">Action</th>
                            <th style="padding: 8px; border-bottom: 1px solid #dee2e6;">Changes</th>
                        </tr>
                    </thead>
                    <tbody>`;
            
            logs.forEach(log => {
                const date = new Date(log.created_at);
                const timeStr = date.toLocaleString('vi-VN');
                const orderInfo = log.go_no ? `${log.go_no} (${log.customer_short_name || ''})` : (log.order_id || 'System');
                const userInfo = log.full_name || log.username || 'System';
                
                let changes = '';
                if (log.old_value && log.new_value) {
                    changes = `${log.old_value} → ${log.new_value}`;
                } else if (log.new_value) {
                    changes = log.new_value;
                }
                
                html += `<tr>
                    <td style="padding: 6px 8px; border-bottom: 1px solid #f1f5f9; font-size: 12px;">${timeStr}</td>
                    <td style="padding: 6px 8px; border-bottom: 1px solid #f1f5f9;">${userInfo}</td>
                    <td style="padding: 6px 8px; border-bottom: 1px solid #f1f5f9;">${orderInfo}</td>
                    <td style="padding: 6px 8px; border-bottom: 1px solid #f1f5f9;"><code>${log.action}</code></td>
                    <td style="padding: 6px 8px; border-bottom: 1px solid #f1f5f9; font-size: 12px; max-width: 200px; word-break: break-word;">${changes}</td>
                </tr>`;
            });
            
            html += `</tbody></table></div>`;
            
            document.getElementById('activity-logs-container').innerHTML = `<h3>Activity Logs</h3>${html}`;
        }
        
        // Load recent activity logs on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (document.getElementById('section-order-history')) {
                // Auto load recent logs
                fetch('../process.php?action=get_activity_logs&limit=20')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            displayActivityLogs(data.logs, data.total);
                        }
                    })
                    .catch(error => console.error('Error loading initial logs:', error));
            }
        });

        // Add keyboard shortcut for quick navigation
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'k') {
                e.preventDefault();
                document.getElementById('userSearch')?.focus();
            }
        });
    </script>
</body>
</html>
