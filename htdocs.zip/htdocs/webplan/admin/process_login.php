<?php
session_start();
require_once '../models/UserModel.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit();
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    header('Location: ../login.php?error=invalid&username=' . urlencode($username));
    exit();
}

try {
    $userModel = new UserModel();
    $user = $userModel->authenticate($username, $password);
    
    if ($user) {
        // Đăng nhập thành công
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_data'] = $user;
        
        // Ghi log đăng nhập
        $userModel->logUserActivity($user['id'], 'login', 'User logged in successfully');
        
        // Chuyển hướng đến trang chính
        header('Location: ../index.php');
        exit();
    } else {
        // Đăng nhập thất bại
        header('Location: ../login.php?error=invalid&username=' . urlencode($username));
        exit();
    }
    
} catch (Exception $e) {
    error_log("Login error: " . $e->getMessage());
    header('Location: ../login.php?error=system&username=' . urlencode($username));
    exit();
}
?>
