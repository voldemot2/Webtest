<?php
// Redirect tới admin panel
header('Location: admin.php');
exit();
?>
