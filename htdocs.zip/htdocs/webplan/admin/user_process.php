<?php
require_once '../auth.php';
require_once '../models/UserModel.php';
require_once '../models/DepartmentModel.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    $userModel = new UserModel();
    $departmentModel = new DepartmentModel();
    
    switch ($action) {
        case 'create_user':
            $data = [
                'username' => trim($_POST['username']),
                'password' => $_POST['password'],
                'full_name' => trim($_POST['full_name']),
                'email' => trim($_POST['email']),
                'department_id' => intval($_POST['department_id']),
                'role' => $_POST['role'],
                'status' => 'active'
            ];
            
            // Validation
            if (empty($data['username']) || empty($data['password']) || empty($data['full_name'])) {
                echo json_encode(['success' => false, 'message' => 'Required fields missing']);
                exit();
            }
            
            // Check if username exists
            $existingUser = $userModel->getUserByUsername($data['username']);
            if ($existingUser) {
                echo json_encode(['success' => false, 'message' => 'Username already exists']);
                exit();
            }
            
            $result = $userModel->createUser($data);
            
            if ($result) {
                logUserActivity('create_user', "Created new user: {$data['username']}");
                echo json_encode(['success' => true, 'message' => 'User created successfully', 'user_id' => $result]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create user']);
            }
            break;
            
        case 'update_user':
            $id = intval($_POST['id']);
            $data = [
                'username' => trim($_POST['username']),
                'full_name' => trim($_POST['full_name']),
                'email' => trim($_POST['email']),
                'department_id' => intval($_POST['department_id']),
                'role' => $_POST['role'],
                'status' => $_POST['status']
            ];
            
            $result = $userModel->updateUser($id, $data);
            
            if ($result) {
                logUserActivity('update_user', "Updated user ID: {$id}");
                echo json_encode(['success' => true, 'message' => 'User updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update user']);
            }
            break;
            
        case 'delete_user':
            $id = intval($_POST['id']);
            
            // Không cho phép xóa chính mình
            if ($id == $_SESSION['user_id']) {
                echo json_encode(['success' => false, 'message' => 'Cannot delete yourself']);
                exit();
            }
            
            $result = $userModel->deleteUser($id);
            
            if ($result) {
                logUserActivity('delete_user', "Deleted user ID: {$id}");
                echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
            }
            break;
            
        case 'update_password':
            $id = intval($_POST['id']);
            $new_password = $_POST['new_password'];
            
            if (empty($new_password)) {
                echo json_encode(['success' => false, 'message' => 'Password cannot be empty']);
                exit();
            }
            
            $result = $userModel->updatePassword($id, $new_password);
            
            if ($result) {
                logUserActivity('update_password', "Updated password for user ID: {$id}");
                echo json_encode(['success' => true, 'message' => 'Password updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update password']);
            }
            break;
            
        case 'get_user':
            $id = intval($_GET['id']);
            $user = $userModel->getUserById($id);
            
            if ($user) {
                // Remove sensitive data
                unset($user['password_hash']);
                echo json_encode(['success' => true, 'user' => $user]);
            } else {
                echo json_encode(['success' => false, 'message' => 'User not found']);
            }
            break;
            
        case 'get_departments':
            $departments = $departmentModel->getAllDepartments();
            echo json_encode(['success' => true, 'departments' => $departments]);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Unknown action']);
            break;
    }
    
} catch (Exception $e) {
    error_log("User process error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'System error occurred']);
}
?>
