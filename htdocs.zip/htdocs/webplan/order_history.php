<?php
require_once 'auth.php';

// Kiểm tra đăng nhập
$currentUser = checkLogin();

// Chỉ cho phép manager và admin xem logs
if ($currentUser['role'] !== 'admin' && $currentUser['role'] !== 'manager') {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History - SPS Planning System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="libs/fontawesome/all.min.css">
    <style>
        /* Reset và override các style có thể conflict */
        * {
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            line-height: 1.5;
        }
        
        .history-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
        }
        
        .page-header {
            background: white;
            padding: 12px 16px;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            margin: 0;
            color: #1f2937;
            font-size: 22px;
            font-weight: 600;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            background: #6366f1;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 500;
            font-size: 13px;
            transition: all 0.2s;
        }
        
        .back-btn:hover {
            background: #4f46e5;
            transform: translateY(-1px);
        }
        
        .filters-panel {
            background: white;
            padding: 12px 16px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            margin-bottom: 16px;
        }
        
        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 10px;
            margin-bottom: 12px;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        
        .filter-group label {
            font-weight: 500;
            color: #374151;
            margin-bottom: 4px;
            font-size: 13px;
        }
        
        .form-input {
            padding: 8px 10px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 13px;
            transition: border-color 0.2s, box-shadow 0.2s;
            background: white;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #6366f1;
            box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.1);
        }
        
        .filter-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 14px;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
        }
        
        .btn-primary {
            background: #6366f1;
            color: white;
        }
        
        .btn-primary:hover {
            background: #4f46e5;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        
        .btn-secondary:hover {
            background: #e5e7eb;
        }
        
        .logs-panel {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            height: 530px;
        }
        
        .panel-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
            background: #f9fafb;
            height: 40px;
        }
        
        .stats-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 0;
        }
        
        .stats-info {
            font-weight: 600;
            color: #1f2937;
        }
        
        .records-info {
            color: #6b7280;
            font-size: 14px;
        }
        
        .table-container {
            /* Đây là phần quan trọng để fix scroll */
            position: relative;
            overflow: auto;
            height: 430px;
            border: none;
        }
        
        .logs-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }
        
        .logs-table thead {
            position: sticky;
            top: 0;
            z-index: 10;
            background: #f8fafc;
        }
        
        .logs-table th {
            padding: 16px 12px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid #e5e7eb;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .logs-table td {
            padding: 12px 12px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 14px;
            vertical-align: top;
        }
        
        .logs-table tbody tr:hover {
            background: #f8fafc;
        }
        
        .time-cell {
            font-size: 12px;
            color: #6b7280;
            white-space: nowrap;
            min-width: 140px;
        }
        
        .user-cell {
            min-width: 120px;
        }
        
        .user-name {
            font-weight: 500;
            color: #1f2937;
        }
        
        .user-role {
            font-size: 12px;
            color: #6b7280;
            text-transform: capitalize;
        }
        
        .order-cell {
            min-width: 150px;
        }
        
        .order-number {
            font-weight: 500;
            color: #1f2937;
        }
        
        .customer-name {
            font-size: 12px;
            color: #6b7280;
        }
        
        .action-cell {
            min-width: 140px;
        }
        
        .action-code {
            background: #e0e7ff;
            color: #3730a3;
            padding: 4px 8px;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            font-weight: 500;
        }
        
        .changes-cell {
            max-width: 300px;
            word-break: break-word;
            font-size: 13px;
            line-height: 1.4;
        }
        
        .change-old {
            color: #dc2626;
            background: #fef2f2;
            padding: 2px 6px;
            border-radius: 4px;
            margin: 2px 0;
            display: block;
        }
        
        .change-new {
            color: #059669;
            background: #f0fdf4;
            padding: 2px 6px;
            border-radius: 4px;
            margin: 2px 0;
            display: block;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-icon {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .loading {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .loading i {
            font-size: 24px;
            margin-bottom: 12px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 16px;
            background: #f9fafb;
            border-top: 1px solid #e5e7eb;
            height: 60px;
        }
        
        .pagination button {
            padding: 8px 16px;
            border: 1px solid #d1d5db;
            background: white;
            color: #374151;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .pagination button:hover:not(:disabled) {
            background: #f3f4f6;
            border-color: #9ca3af;
        }
        
        .pagination button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .pagination .current-page {
            background: #6366f1;
            color: white;
            border-color: #6366f1;
        }
        
        .pagination span {
            color: #6b7280;
            padding: 0 8px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .history-container {
                padding: 12px;
            }
            
            .page-header {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .filters-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-actions {
                justify-content: center;
            }
            
            .logs-panel {
                height: 500px;
            }
            
            .table-container {
                height: 400px;
            }
            
            .logs-table {
                min-width: 800px; /* Force horizontal scroll on mobile */
            }
            
            .stats-row {
                flex-direction: column;
                gap: 8px;
                text-align: center;
            }
        }
        
        /* Override any conflicting styles from main stylesheet */
        .history-container * {
            box-sizing: border-box;
        }
        
        .history-container table {
            border-collapse: collapse;
            width: 100%;
        }
        
        .history-container input, .history-container select, .history-container button {
            font-family: inherit;
        }
    </style>
</head>
<body>
    <div class="history-container">
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-history"></i> Order History & Activity Logs
            </h1>
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Planning
            </a>
        </div>
        
        <div class="filters-panel">
            <div class="filters-grid">
                <div class="filter-group">
                    <label>Date From:</label>
                    <input type="date" id="dateFrom" class="form-input">
                </div>
                <div class="filter-group">
                    <label>Date To:</label>
                    <input type="date" id="dateTo" class="form-input">
                </div>
                <div class="filter-group">
                    <label>Action:</label>
                    <select id="actionFilter" class="form-input">
                        <option value="">All Actions</option>
                        <option value="update_field">Field Updates</option>
                        <option value="create">Create Order</option>
                        <option value="update_order_sequence">Reorder</option>
                        <option value="delete">Delete</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Order ID:</label>
                    <input type="number" id="orderIdFilter" class="form-input" placeholder="Order ID">
                </div>
            </div>
            <div class="filter-actions">
                <button id="btnFilter" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Apply Filters
                </button>
                <button id="btnReset" class="btn btn-secondary">
                    <i class="fas fa-refresh"></i> Reset
                </button>
            </div>
        </div>
        
        <div class="logs-panel">
            <div class="panel-header">
                <div class="stats-row">
                    <div id="statsInfo" class="stats-info">Loading...</div>
                    <div id="recordsInfo" class="records-info"></div>
                </div>
            </div>
            
            <div class="table-container">
                <div id="logsContainer">
                    <div class="loading">
                        <i class="fas fa-spinner fa-spin"></i>
                        <div>Loading activity logs...</div>
                    </div>
                </div>
            </div>
            
            <div class="pagination" id="paginationContainer"></div>
        </div>
    </div>
    
    <script src="scr/api.js"></script>
    <script>
        // Define fetchActivityLogs function if not available from api.js
        async function fetchActivityLogs(filters = {}) {
            const params = new URLSearchParams();
            
            // Default values
            params.append('page', filters.page || 1);
            params.append('limit', filters.limit || 50);
            
            // Optional filters
            if (filters.order_id) params.append('order_id', filters.order_id);
            if (filters.user_id) params.append('user_id', filters.user_id);
            if (filters.action) params.append('action', filters.action);
            if (filters.date_from) params.append('date_from', filters.date_from);
            if (filters.date_to) params.append('date_to', filters.date_to);
            
            try {
                const response = await fetch(`process.php?action=get_activity_logs&${params.toString()}`);
                const data = await response.json();
                
                if (!data.success) {
                    throw new Error(data.error || 'Failed to fetch activity logs');
                }
                
                return data;
            } catch (error) {
                console.error('Error fetching activity logs:', error);
                return {
                    error: true,
                    message: error.message,
                    logs: [],
                    total: 0
                };
            }
        }
        
        let currentPage = 1;
        let currentFilters = {};
        
        // Load logs khi trang load
        document.addEventListener('DOMContentLoaded', function() {
            loadLogs();
            
            // Bind events
            document.getElementById('btnFilter').addEventListener('click', applyFilters);
            document.getElementById('btnReset').addEventListener('click', resetFilters);
        });
        
        async function loadLogs(page = 1) {
            currentPage = page;
            
            const params = new URLSearchParams();
            params.append('page', page);
            params.append('limit', 50);
            
            // Add current filters
            if (currentFilters.date_from) params.append('date_from', currentFilters.date_from);
            if (currentFilters.date_to) params.append('date_to', currentFilters.date_to);
            if (currentFilters.action) params.append('action_filter', currentFilters.action);
            if (currentFilters.order_id) params.append('order_id', currentFilters.order_id);
            
            const url = `process.php?action=get_activity_logs&${params.toString()}`;
            
            try {
                const response = await fetch(url);
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                
                const text = await response.text();
                
                let data;
                try {
                    data = JSON.parse(text);
                } catch (parseError) {
                    throw new Error(`Invalid JSON response: ${text.substring(0, 100)}...`);
                }
                
                if (!data.success) {
                    throw new Error(data.error || 'API returned success=false');
                }
                
                displayLogs(data);
                
            } catch (error) {
                document.getElementById('logsContainer').innerHTML = 
                    `<div style="text-align: center; padding: 40px; color: #dc3545;">
                        <i class="fas fa-exclamation-triangle"></i> Error loading logs: ${error.message}
                    </div>`;
            }
        }
        
        function displayLogs(data) {
            const { logs, total, page, total_pages } = data;
            
            // Update stats
            document.getElementById('statsInfo').textContent = `Total: ${total} records`;
            document.getElementById('recordsInfo').textContent = 
                `Page ${page} of ${total_pages} (${logs.length} records shown)`;
            
            // Generate table HTML
            let html = `
                <table class="logs-table">
                    <thead>
                        <tr>
                            <th class="time-cell">Time</th>
                            <th class="user-cell">User</th>
                            <th class="order-cell">Order</th>
                            <th class="action-cell">Action</th>
                            <th class="changes-cell">Changes</th>
                        </tr>
                    </thead>
                    <tbody>`;
            
            if (logs.length === 0) {
                html += `<tr><td colspan="5" class="empty-state">
                    <div class="empty-icon">📊</div>
                    <div><strong>No activity logs found</strong></div>
                    <div>Try adjusting your filters or check back later.</div>
                </td></tr>`;
            } else {
                logs.forEach(log => {
                    const date = new Date(log.created_at);
                    const timeStr = date.toLocaleString('vi-VN', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                    
                    const orderInfo = log.go_no ? 
                        `<div class="order-number">${log.go_no}</div><div class="customer-name">${log.customer_short_name || ''}</div>
                         <div style="margin-top: 4px;"><a href="order_timeline.php?order_id=${log.order_id}" style="color: #6366f1; font-size: 11px; text-decoration: none;"><i class="fas fa-clock"></i> Timeline</a></div>` : 
                        (log.order_id ? `<div class="order-number">Order #${log.order_id}</div>
                         <div style="margin-top: 4px;"><a href="order_timeline.php?order_id=${log.order_id}" style="color: #6366f1; font-size: 11px; text-decoration: none;"><i class="fas fa-clock"></i> Timeline</a></div>` : 
                         '<div class="order-number">System</div>');
                    
                    const userInfo = `<div class="user-name">${log.full_name || log.username || 'System'}</div><div class="user-role">${log.role || ''}</div>`;
                    
                    let changes = '';
                    if (log.old_value && log.new_value) {
                        // Try to make JSON more readable
                        let oldVal = log.old_value;
                        let newVal = log.new_value;
                        try {
                            if (oldVal.startsWith('{') || oldVal.startsWith('[')) {
                                const parsed = JSON.parse(oldVal);
                                oldVal = typeof parsed === 'object' ? JSON.stringify(parsed, null, 2) : oldVal;
                            }
                            if (newVal.startsWith('{') || newVal.startsWith('[')) {
                                const parsed = JSON.parse(newVal);
                                newVal = typeof parsed === 'object' ? JSON.stringify(parsed, null, 2) : newVal;
                            }
                        } catch (e) {
                            // Keep original if not JSON
                        }
                        changes = `<div class="change-old">Old: ${oldVal}</div><div class="change-new">New: ${newVal}</div>`;
                    } else if (log.new_value) {
                        changes = `<div class="change-new">${log.new_value}</div>`;
                    } else if (log.old_value) {
                        changes = `<div class="change-old">${log.old_value}</div>`;
                    }
                    
                    html += `<tr>
                        <td class="time-cell">${timeStr}</td>
                        <td class="user-cell">${userInfo}</td>
                        <td class="order-cell">${orderInfo}</td>
                        <td class="action-cell"><span class="action-code">${log.action}</span></td>
                        <td class="changes-cell">${changes}</td>
                    </tr>`;
                });
            }
            
            html += `</tbody></table>`;
            
            document.getElementById('logsContainer').innerHTML = html;
            
            // Generate pagination
            generatePagination(page, total_pages);
        }
        
        function generatePagination(currentPage, totalPages) {
            const container = document.getElementById('paginationContainer');
            
            if (totalPages <= 1) {
                container.innerHTML = '';
                return;
            }
            
            let html = '';
            
            // Previous button
            html += `<button onclick="loadLogs(${currentPage - 1})" ${currentPage <= 1 ? 'disabled' : ''}>
                <i class="fas fa-chevron-left"></i> Previous
            </button>`;
            
            // Page numbers
            const startPage = Math.max(1, currentPage - 2);
            const endPage = Math.min(totalPages, currentPage + 2);
            
            if (startPage > 1) {
                html += `<button onclick="loadLogs(1)">1</button>`;
                if (startPage > 2) html += `<span>...</span>`;
            }
            
            for (let i = startPage; i <= endPage; i++) {
                html += `<button onclick="loadLogs(${i})" ${i === currentPage ? 'class="current-page"' : ''}>${i}</button>`;
            }
            
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) html += `<span>...</span>`;
                html += `<button onclick="loadLogs(${totalPages})">${totalPages}</button>`;
            }
            
            // Next button
            html += `<button onclick="loadLogs(${currentPage + 1})" ${currentPage >= totalPages ? 'disabled' : ''}>
                Next <i class="fas fa-chevron-right"></i>
            </button>`;
            
            container.innerHTML = html;
        }
        
        function applyFilters() {
            currentFilters = {};
            
            const dateFrom = document.getElementById('dateFrom').value;
            const dateTo = document.getElementById('dateTo').value;
            const action = document.getElementById('actionFilter').value;
            const orderId = document.getElementById('orderIdFilter').value;
            
            if (dateFrom) currentFilters.date_from = dateFrom;
            if (dateTo) currentFilters.date_to = dateTo;
            if (action) currentFilters.action = action;
            if (orderId) currentFilters.order_id = orderId;
            
            loadLogs(1); // Reset to first page
        }
        
        function resetFilters() {
            document.getElementById('dateFrom').value = '';
            document.getElementById('dateTo').value = '';
            document.getElementById('actionFilter').value = '';
            document.getElementById('orderIdFilter').value = '';
            currentFilters = {};
            loadLogs(1);
        }
    </script>
</body>
</html>
