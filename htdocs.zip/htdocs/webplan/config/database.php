<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    private $conn;

    public function __construct() {
        // Cấu hình kết nối MySQL trên XAMPP
        $this->host = 'localhost';  // hoặc 127.0.0.1
        $this->db_name = 'webplan_db';
        $this->username = 'root';
        $this->password = '';  // XAMPP mặc định không có password cho root
        $this->port = 3306;  // Port mặc định của MySQL trên XAMPP
    }

    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8mb4");
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
}
?>
