<?php
// Tắt hiển thị lỗi để tránh làm hỏng JSON response
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Đảm bảo output sạch
ob_start();

header('Content-Type: application/json; charset=utf-8');

require_once 'auth.php';
require_once 'models/OrderModel.php';

try {
    // Kiểm tra đăng nhập
    $currentUser = checkLogin();

    // Khởi tạo model
    $orderModel = new OrderModel();

    $action = $_GET['action'] ?? $_POST['action'] ?? '';

    // Debug: Log action để kiểm tra
    error_log("Process.php - Action received: " . $action);
    
    // Nếu là POST request với JSON, kiểm tra action trong JSON body
    if (empty($action) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        if (isset($input['action'])) {
            $action = $input['action'];
            error_log("Process.php - Action from JSON: " . $action);
        }
    }

    // Hàm xử lý giá trị ngày cho đúng chuẩn NULL
    function normalize_date_field($value) {
        if ($value === 'null' || $value === '') {
            return null;
        }
        return $value;
    }

switch ($action) {
    case 'get_orders':
        // Kiểm tra quyền đọc
        if (!checkPermission('planning_read') && !checkPermission('ah_read') && 
            !checkPermission('sm_read') && !checkPermission('cmd_read')) {
            echo json_encode(['error' => 'Unauthorized access']);
            exit();
        }
        
        $orders = $orderModel->getAllOrders();
        echo json_encode($orders);
        break;

case 'update_order_field':
    // Kiểm tra quyền ghi dựa trên department
    $hasWritePermission = false;
    $userDept = getUserDepartment();
    
    switch ($userDept) {
        case 'PLAN':
            $hasWritePermission = checkPermission('planning_write');
            break;
        case 'AH':
            $hasWritePermission = checkPermission('ah_write');
            break;
        case 'SM':
            $hasWritePermission = checkPermission('sm_write');
            break;
        case 'CMD':
            $hasWritePermission = checkPermission('cmd_write');
            break;
        case 'SAMPLE':
            $hasWritePermission = checkPermission('sample_write');
            break;
        default:
            // Cho phép admin hoặc kiểm tra theo field cụ thể
            if (isAdmin()) {
                $hasWritePermission = true;
            } else {
                // Kiểm tra permission theo field nếu không phải admin
                $field = $_POST['field'] ?? '';
                if ($field === 'order_status') {
                    $new_status = $_POST['value'] ?? '';
                    if (in_array($new_status, ['Check', 'Complete'])) {
                        $hasWritePermission = checkPermission('sample_write');
                    }
                }
            }
    }
    
    if (!$hasWritePermission) {
        // Thêm một lần kiểm tra cuối cho Sample permissions
        $field = $_POST['field'] ?? '';
        $value = $_POST['value'] ?? '';
        
        if ($field === 'order_status' && in_array($value, ['Check', 'Complete'])) {
            $hasWritePermission = checkPermission('sample_write');
            error_log("Sample status update attempted. Permission check result: " . ($hasWritePermission ? 'granted' : 'denied'));
        }
    }
    
    if (!$hasWritePermission) {
        echo json_encode(['success' => false, 'error' => 'Unauthorized access - You need sample_write permission to change order status to Check/Complete']);
        exit();
    }
    
    $order_id = $_POST['order_id'];
    $field = $_POST['field'];
    $value = $_POST['value'];

    // Nếu là trường ngày thì chuẩn hóa giá trị
    $date_fields = ['delivery_date', 'marker_date', 'cut_start_date', 'sewing_start_date', 'ah_date', 'sm_date'];
    if (in_array($field, $date_fields)) {
        $value = normalize_date_field($value);
    }
    
    // Ghi log hoạt động
    $old_order = $orderModel->getOrderById($order_id);
    $old_value = $old_order ? $old_order[$field] : null;
    
    $result = $orderModel->updateOrderField($order_id, $field, $value);
    
    if ($result) {
        // Ghi log với user_id
        $orderModel->logActivityWithUser($order_id, "update_field_$field", $old_value, $value, $currentUser['id']);
        
        // Log user activity
        logUserActivity("update_order_field", "Updated order $order_id field $field from '$old_value' to '$value'");
        
        // Nếu đổi sang Loaded thì cập nhật thứ tự (move về cuối)
        if ($field == 'order_status' && $value == 'Loaded') {
            $all_orders = $orderModel->getAllOrders();
            $max_order = count($all_orders);
            $orderModel->updateOrderField($order_id, 'display_order', $max_order);
        }
        
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Không thể cập nhật trường']);
    }
    break;
    // bản vip có fields
case 'update_order_fields':
    $input = json_decode(file_get_contents('php://input'), true);
    $order_id = $input['order_id'] ?? null;
    $fields = $input['fields'] ?? [];

    // Chuẩn hóa các trường ngày
    $date_fields = ['delivery_date', 'marker_date', 'cut_start_date', 'sewing_start_date', 'ah_date', 'sm_date'];
    foreach ($date_fields as $date_field) {
        if (isset($fields[$date_field])) {
            $fields[$date_field] = normalize_date_field($fields[$date_field]);
        }
    }

    if (!$order_id || !is_array($fields) || empty($fields)) {
        echo json_encode(['success' => false, 'error' => 'Thiếu dữ liệu']);
        exit;
    }
    
    // Ghi log hoạt động
    $old_order = $orderModel->getOrderById($order_id);
    
    $result = $orderModel->updateOrderFields($order_id, $fields);
    
    if ($result) {
        // Ghi log cho từng field thay đổi
        foreach ($fields as $field => $new_value) {
            $old_value = $old_order ? $old_order[$field] : null;
            if ($old_value != $new_value) {
                $orderModel->logActivityWithUser($order_id, "update_field_$field", $old_value, $new_value, $currentUser['id']);
            }
        }
        
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Không thể cập nhật dữ liệu']);
    }
    exit;

    case 'update_order_full':
        $id = intval($_POST['id']);
        
        // Chuẩn bị dữ liệu
        $order_data = [
            'customer_short_name' => $_POST['customer_short_name'] ?? '',
            'go_no' => $_POST['go_no'] ?? '',
            'style_no' => $_POST['style_no'] ?? '',
            'jo_no' => $_POST['jo_no'] ?? '',
            'color_code' => $_POST['color_code'] ?? '',
            'product_category' => $_POST['product_category'] ?? '',
            'wash_type' => $_POST['wash_type'] ?? '',
            'plan_qty' => intval($_POST['plan_qty']),
            'target_output' => intval($_POST['target_output']),
            'delivery_date' => $_POST['delivery_date'] ?? '',
            'marker_date' => $_POST['marker_date'] ?? '',
            'cut_start_date' => $_POST['cut_start_date'] ?? '',
            'sewing_start_date' => $_POST['sewing_start_date'] ?? '',
            'sample_type' => $_POST['sample_type'] ?? '',
            'ah_date' => $_POST['ah_date'] ?? '',
            'sm_date' => $_POST['sm_date'] ?? '',
            'remark' => $_POST['remark'] ?? '',
            'order_status' => $_POST['order_status'] ?? '',
            'display_order' => 0
        ];
        // Chuẩn hóa các trường ngày
        $date_fields = ['delivery_date', 'marker_date', 'cut_start_date', 'sewing_start_date', 'ah_date', 'sm_date'];
        foreach ($date_fields as $date_field) {
            if (isset($order_data[$date_field])) {
                $order_data[$date_field] = normalize_date_field($order_data[$date_field]);
            }
        }
        
        // Ghi log hoạt động
        $old_order = null;
        if ($id > 0) {
            $old_order = $orderModel->getOrderById($id);
        }
        
        if ($old_order) {
            // Cập nhật order hiện tại
            $result = $orderModel->updateOrder($id, $order_data);
            $action_log = 'update_order_full';
        } else {
            // Tạo order mới
            if ($id <= 0) {
                // Lấy display_order tiếp theo
                $all_orders = $orderModel->getAllOrders();
                $order_data['display_order'] = count($all_orders);
            }
            $result = $orderModel->createOrder($order_data);
            $action_log = 'create_order';
        }
        
        if ($result) {
            $final_id = $old_order ? $id : $result;
            $orderModel->logActivityWithUser($final_id, $action_log, 
                $old_order ? json_encode($old_order) : null, 
                json_encode($order_data), $currentUser['id']);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Không thể lưu dữ liệu']);
        }
        break;

    case 'get_activity_logs':
        // Chỉ admin và manager có thể xem logs
        if (!checkPermission('admin') && $currentUser['role'] != 'manager') {
            echo json_encode(['success' => false, 'error' => 'Unauthorized access. Only admin and manager can view logs.']);
            exit();
        }
        
        $page = intval($_GET['page'] ?? 1);
        $limit = intval($_GET['limit'] ?? 50);
        $order_id = $_GET['order_id'] ?? null;
        $user_id = $_GET['user_id'] ?? null; 
        $action_filter = $_GET['action_filter'] ?? null; // Đổi từ 'action' thành 'action_filter'
        $date_from = $_GET['date_from'] ?? null;
        $date_to = $_GET['date_to'] ?? null;
        
        $offset = ($page - 1) * $limit;
        
        // Build query với điều kiện lọc
        $where_conditions = [];
        $params = [];
        
        if ($order_id) {
            $where_conditions[] = "al.order_id = :order_id";
            $params[':order_id'] = $order_id;
        }
        
        if ($user_id) {
            $where_conditions[] = "al.user_id = :user_id";
            $params[':user_id'] = $user_id;
        }
        
        if ($action_filter) {
            $where_conditions[] = "al.action LIKE :action";
            $params[':action'] = "%$action_filter%";
        }
        
        if ($date_from) {
            $where_conditions[] = "DATE(al.created_at) >= :date_from";
            $params[':date_from'] = $date_from;
        }
        
        if ($date_to) {
            $where_conditions[] = "DATE(al.created_at) <= :date_to";
            $params[':date_to'] = $date_to;
        }
        
        $where_clause = empty($where_conditions) ? '' : 'WHERE ' . implode(' AND ', $where_conditions);
        
        // Query logs với pagination
                
        $query = "SELECT al.*, 
                         u.username, u.full_name, u.role,
                         o.go_no, o.customer_short_name
                  FROM activity_logs al 
                  LEFT JOIN users u ON al.user_id = u.id 
                  LEFT JOIN orders o ON al.order_id = o.id
                  $where_clause
                  ORDER BY al.created_at DESC 
                  LIMIT :limit OFFSET :offset";
        
        $stmt = $orderModel->getConnection()->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Query total count
        $count_query = "SELECT COUNT(*) as total FROM activity_logs al $where_clause";
        $count_stmt = $orderModel->getConnection()->prepare($count_query);
        foreach ($params as $key => $value) {
            $count_stmt->bindValue($key, $value);
        }
        $count_stmt->execute();
        $total = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        echo json_encode([
            'success' => true,
            'logs' => $logs,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'total_pages' => ceil($total / $limit)
        ]);
        break;

    case 'test_db_connection':
        try {
            $conn = $orderModel->getConnection();
            $query = "SELECT 1 as test";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $result = $stmt->fetch();
            
            echo json_encode([
                'success' => true,
                'message' => 'Database connection OK',
                'test_result' => $result
            ]);
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'error' => 'Database connection failed',
                'debug' => $e->getMessage()
            ]);
        }
        break;

    case 'get_order_info':
        // Chỉ admin và manager có thể xem thông tin order
        if (!checkPermission('admin') && $currentUser['role'] != 'manager') {
            echo json_encode(['success' => false, 'error' => 'Unauthorized access. Only admin and manager can view order info.']);
            exit();
        }
        
        $order_id = intval($_GET['order_id'] ?? 0);
        if (!$order_id) {
            echo json_encode(['success' => false, 'error' => 'Order ID is required.']);
            exit();
        }
        
        try {
            // Try to get from orders table first (this should work now)
            $query = "SELECT 
                        o.id,
                        o.customer_short_name,
                        o.go_no,
                        o.style_no,
                        o.jo_no,
                        o.color_code,
                        o.product_category,
                        o.wash_type,
                        o.plan_qty,
                        o.target_output,
                        o.delivery_date,
                        o.marker_date,
                        o.cut_start_date,
                        o.sewing_start_date,
                        o.sample_type,
                        o.ah_date,
                        o.sm_date,
                        o.remark,
                        o.order_status as status,
                        o.display_order,
                        o.created_at,
                        o.updated_at
                      FROM orders o 
                      WHERE o.id = :order_id";
            
            $stmt = $orderModel->getConnection()->prepare($query);
            $stmt->bindValue(':order_id', $order_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($order) {
                // Order found in orders table
                echo json_encode([
                    'success' => true,
                    'order' => $order,
                    'source' => 'orders_table'
                ]);
                exit();
            }
            
            // If not found in orders table, try to get basic info from activity_logs
            $query = "SELECT 
                        order_id as id,
                        COUNT(*) as activity_count,
                        MIN(created_at) as first_activity,
                        MAX(created_at) as last_activity
                      FROM activity_logs 
                      WHERE order_id = :order_id 
                      GROUP BY order_id";
            
            $stmt = $orderModel->getConnection()->prepare($query);
            $stmt->bindValue(':order_id', $order_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $basicInfo = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$basicInfo) {
                echo json_encode(['success' => false, 'error' => 'Order not found in both orders table and activity logs.']);
                exit();
            }
            
            // Get the most recent activity log data to reconstruct order info
            $query = "SELECT new_value, old_value, action, created_at
                      FROM activity_logs 
                      WHERE order_id = :order_id 
                      ORDER BY created_at DESC 
                      LIMIT 10";
            
            $stmt = $orderModel->getConnection()->prepare($query);
            $stmt->bindValue(':order_id', $order_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Build order info from logs (fallback method)
            $order = [
                'id' => $order_id,
                'go_no' => "Order #$order_id",
                'customer_short_name' => 'Unknown Customer',
                'sample_type' => 'Regular Order',
                'cut_start_date' => null,
                'sewing_start_date' => null,
                'delivery_date' => null,
                'status' => 'Active',
                'created_at' => $basicInfo['first_activity'],
                'activity_count' => $basicInfo['activity_count']
            ];
            
            // Try to extract more detailed info from logs
            foreach ($logs as $log) {
                if ($log['new_value']) {
                    // Try to parse as JSON first
                    $data = json_decode($log['new_value'], true);
                    if ($data && is_array($data)) {
                        foreach ($data as $key => $value) {
                            if (array_key_exists($key, $order) && $value) {
                                $order[$key] = $value;
                            }
                        }
                    } else {
                        // If not JSON, check specific fields based on action
                        if (strpos($log['action'], 'go_no') !== false) {
                            $order['go_no'] = $log['new_value'];
                        } else if (strpos($log['action'], 'customer') !== false) {
                            $order['customer_short_name'] = $log['new_value'];
                        } else if (strpos($log['action'], 'sample_type') !== false) {
                            $order['sample_type'] = $log['new_value'];
                        }
                    }
                }
            }
            
            echo json_encode([
                'success' => true,
                'order' => $order,
                'source' => 'activity_logs'
            ]);
            
        } catch (Exception $e) {
            error_log("Error getting order info: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            
            // Show detailed error for debugging
            echo json_encode([
                'success' => false, 
                'error' => 'Database error occurred.',
                'debug' => $e->getMessage(),
                'order_id' => $order_id
            ]);
        }
        break;

    case 'update_order_sequence':
        $ids = json_decode(file_get_contents('php://input'), true);
        
        if (!is_array($ids) || empty($ids)) {
            echo json_encode(['success' => false, 'error' => 'Dữ liệu không hợp lệ']);
            break;
        }
        
        $result = $orderModel->updateOrderSequence($ids);
        
        if ($result) {
            $orderModel->logActivityWithUser(null, 'update_order_sequence', null, json_encode($ids), $currentUser['id']);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Không thể cập nhật thứ tự']);
        }
        break;

    case 'save_multiple_orders':
        // Kiểm tra quyền AH
        if (!checkPermission('ah_write')) {
            echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
            break;
        }
        
        // Đọc input JSON
        $rawInput = file_get_contents('php://input');
        error_log("Process.php - Raw input: " . $rawInput);
        
        $input = json_decode($rawInput, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['success' => false, 'error' => 'Invalid JSON input: ' . json_last_error_msg()]);
            break;
        }
        
        $orders = $input['orders'] ?? [];
        
        if (!is_array($orders) || empty($orders)) {
            echo json_encode(['success' => false, 'error' => 'No orders provided']);
            break;
        }
        
        $successCount = 0;
        $errors = [];
        
        foreach ($orders as $index => $orderData) {
            try {
                // Validate required fields
                $requiredFields = ['customer_short_name', 'go_no', 'style_no'];
                foreach ($requiredFields as $field) {
                    if (empty($orderData[$field])) {
                        throw new Exception("Missing required field: $field");
                    }
                }
                
                // Normalize date fields
                $orderData['ah_date'] = normalize_date_field($orderData['ah_date'] ?? '');
                $orderData['delivery_date'] = normalize_date_field($orderData['delivery_date'] ?? '');
                $orderData['marker_date'] = normalize_date_field($orderData['marker_date'] ?? '');
                $orderData['cut_start_date'] = normalize_date_field($orderData['cut_start_date'] ?? '');
                $orderData['sewing_start_date'] = normalize_date_field($orderData['sewing_start_date'] ?? '');
                $orderData['sm_date'] = normalize_date_field($orderData['sm_date'] ?? '');
                
                // Set default values
                $orderData['order_status'] = $orderData['order_status'] ?? 'Open';
                $orderData['display_order'] = $orderData['display_order'] ?? 0;
                
                // Đảm bảo các trường numeric hợp lệ và có giá trị mặc định
                $orderData['plan_qty'] = !empty($orderData['plan_qty']) ? intval($orderData['plan_qty']) : 1;
                $orderData['target_output'] = 1; // Luôn mặc định là 1, người dùng không được nhập
                
                // Đảm bảo các trường text có giá trị mặc định
                $textFields = ['jo_no', 'color_code', 'product_category', 'wash_type', 'sample_type', 'remark'];
                foreach ($textFields as $field) {
                    if (!isset($orderData[$field]) || $orderData[$field] === '') {
                        $orderData[$field] = null;
                    }
                }
                
                // Insert order
                $orderId = $orderModel->createOrder($orderData);
                
                if ($orderId) {
                    $successCount++;
                    // Log activity
                    $orderModel->logActivityWithUser(
                        $orderId, 
                        'create_order_bulk', 
                        null, 
                        json_encode($orderData), 
                        $currentUser['id']
                    );
                } else {
                    $errors[] = "Row " . ($index + 1) . ": Failed to create order";
                }
                
            } catch (Exception $e) {
                $errors[] = "Row " . ($index + 1) . ": " . $e->getMessage();
                error_log("Process.php - Error creating order: " . $e->getMessage());
            }
        }
        
        if ($successCount > 0) {
            $message = "Successfully created $successCount orders";
            if (!empty($errors)) {
                $message .= ". Errors: " . implode("; ", $errors);
            }
            echo json_encode(['success' => true, 'message' => $message, 'created_count' => $successCount]);
        } else {
            echo json_encode(['success' => false, 'error' => 'No orders were created. Errors: ' . implode("; ", $errors)]);
        }
        break;

    case 'get_order_status_report':
        // Kiểm tra quyền truy cập (chỉ admin và manager)
        if ($currentUser['role'] !== 'admin' && $currentUser['role'] !== 'manager') {
            echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
            exit();
        }

        try {
            // Query để lấy tất cả orders với thông tin từ activity logs
            $query = "
                SELECT DISTINCT
                    o.id,
                    o.go_no,
                    o.customer_short_name as customer,
                    o.sample_type,
                    o.order_status as current_status,
                    
                    -- Create date từ action 'create_order' hoặc 'create_order_bulk'
                    (SELECT al.created_at 
                     FROM activity_logs al 
                     WHERE al.order_id = o.id 
                       AND (al.action = 'create_order' OR al.action = 'create_order_bulk')
                     ORDER BY al.created_at ASC 
                     LIMIT 1) as create_date,
                    
                    -- Submit date từ action 'update_field_order_status' với new_value 'Submit'
                    (SELECT al.created_at 
                     FROM activity_logs al 
                     WHERE al.order_id = o.id 
                       AND al.action = 'update_field_order_status' 
                       AND al.new_value = 'Submit'
                     ORDER BY al.created_at ASC 
                     LIMIT 1) as submit_date,
                    
                    -- Maker date từ action 'update_field_order_status' với new_value 'Marked'
                    (SELECT al.created_at 
                     FROM activity_logs al 
                     WHERE al.order_id = o.id 
                       AND al.action = 'update_field_order_status' 
                       AND al.new_value = 'Marked'
                     ORDER BY al.created_at ASC 
                     LIMIT 1) as maker_date,
                    
                    -- Load date từ action 'update_field_order_status' với new_value 'Loaded'
                    (SELECT al.created_at 
                     FROM activity_logs al 
                     WHERE al.order_id = o.id 
                       AND al.action = 'update_field_order_status' 
                       AND al.new_value = 'Loaded'
                     ORDER BY al.created_at ASC 
                     LIMIT 1) as load_date
                     
                FROM orders o
                ORDER BY o.id DESC
            ";
            
            $stmt = $orderModel->getConnection()->prepare($query);
            $stmt->execute();
            $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'orders' => $orders
            ]);
            
        } catch (Exception $e) {
            error_log("Error in get_order_status_report: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'error' => 'Error retrieving report data: ' . $e->getMessage()
            ]);
        }
        break;

    case 'get_current_user':
        // Debug endpoint để lấy thông tin user hiện tại
        echo json_encode([
            'success' => true,
            'user' => $currentUser
        ]);
        break;

    case 'check_permission':
        // Debug endpoint để kiểm tra permission
        $permission = $_GET['permission'] ?? '';
        if (empty($permission)) {
            echo json_encode(['error' => 'Permission parameter required']);
            break;
        }
        
        $hasPermission = checkPermission($permission);
        echo json_encode([
            'success' => true,
            'permission' => $permission,
            'hasPermission' => $hasPermission,
            'userRole' => $currentUser['role'],
            'userDepartment' => getUserDepartment()
        ]);
        break;

    case 'get_order':
        // Get single order by ID for admin panel
        if (!isAdmin() && !checkPermission('planning_read')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
            break;
        }
        
        $orderId = $_GET['id'] ?? '';
        if (empty($orderId)) {
            echo json_encode(['success' => false, 'message' => 'Order ID required']);
            break;
        }
        
        try {
            $order = $orderModel->getOrderById($orderId);
            if ($order) {
                echo json_encode(['success' => true, 'data' => $order]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Order not found']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error retrieving order: ' . $e->getMessage()]);
        }
        break;

    case 'update_order':
        // Update order for admin panel
        if (!isAdmin() && !checkPermission('planning_write')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
            break;
        }
        
        $orderId = $_POST['id'] ?? '';
        if (empty($orderId)) {
            echo json_encode(['success' => false, 'message' => 'Order ID required']);
            break;
        }
        
        try {
            // Get current order data for logging
            $currentOrder = $orderModel->getOrderById($orderId);
            if (!$currentOrder) {
                echo json_encode(['success' => false, 'message' => 'Order not found']);
                break;
            }
            
            // Prepare update data
            $updateData = [
                'customer_short_name' => $_POST['customer_short_name'] ?? '',
                'go_no' => $_POST['go_no'] ?? '',
                'style_no' => $_POST['style_no'] ?? '',
                'jo_no' => $_POST['jo_no'] ?? '',
                'color_code' => $_POST['color_code'] ?? '',
                'product_category' => $_POST['product_category'] ?? '',
                'wash_type' => $_POST['wash_type'] ?? '',
                'plan_qty' => $_POST['plan_qty'] ?? null,
                'target_output' => $_POST['target_output'] ?? null,
                'order_status' => $_POST['order_status'] ?? 'Open',
                'delivery_date' => $_POST['delivery_date'] ?: null,
                'ah_date' => $_POST['ah_date'] ?: null,
                'marker_date' => $_POST['marker_date'] ?: null,
                'cut_start_date' => $_POST['cut_start_date'] ?: null,
                'sewing_start_date' => $_POST['sewing_start_date'] ?: null,
                'sm_date' => $_POST['sm_date'] ?: null,
                'remark' => $_POST['remark'] ?? ''
            ];
            
            // Update order
            $result = $orderModel->updateOrder($orderId, $updateData);
            
            if ($result) {
                // Log activity
                logUserActivity('update_order', "Updated order {$currentOrder['go_no']} via admin panel", $orderId);
                
                echo json_encode(['success' => true, 'message' => 'Order updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update order']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating order: ' . $e->getMessage()]);
        }
        break;

    case 'update_order_status':
        // Bulk update order status for admin panel
        if (!isAdmin() && !checkPermission('planning_write')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
            break;
        }
        
        $orderId = $_POST['id'] ?? '';
        $newStatus = $_POST['order_status'] ?? '';
        
        if (empty($orderId) || empty($newStatus)) {
            echo json_encode(['success' => false, 'message' => 'Order ID and status required']);
            break;
        }
        
        try {
            // Get current order data for logging
            $currentOrder = $orderModel->getOrderById($orderId);
            if (!$currentOrder) {
                echo json_encode(['success' => false, 'message' => 'Order not found']);
                break;
            }
            
            // Update order status
            $result = $orderModel->updateOrder($orderId, ['order_status' => $newStatus]);
            
            if ($result) {
                // Log activity
                $oldStatus = $currentOrder['order_status'] ?? 'Open';
                logUserActivity('update_order_status', "Changed order {$currentOrder['go_no']} status from {$oldStatus} to {$newStatus}", $orderId);
                
                echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update order status']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating order status: ' . $e->getMessage()]);
        }
        break;

    default:
        error_log("Process.php - Unknown action: '$action'. REQUEST_METHOD: " . $_SERVER['REQUEST_METHOD']);
        echo json_encode(['error' => 'Unknown action', 'received_action' => $action, 'method' => $_SERVER['REQUEST_METHOD']]);
}

} catch (Exception $e) {
    // Log error và trả về JSON error response
    error_log("Process.php error: " . $e->getMessage());
    
    // Clear any previous output
    if (ob_get_length()) {
        ob_clean();
    }
    
    echo json_encode([
        'error' => 'System error occurred', 
        'message' => $e->getMessage(),
        'action' => $action ?? 'unknown'
    ]);
}

// Đảm bảo output sạch - chỉ có JSON
if (ob_get_length()) {
    ob_end_flush();
} else {
    ob_end_clean();
}
?>
