<?php
// api_banhang.php
header('Content-Type: application/json; charset=utf-8');
require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_products':
        $stmt = $pdo->query('SELECT * FROM products');
        echo json_encode($stmt->fetchAll());
        break;
    case 'add_product':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('INSERT INTO products (name, price, stock) VALUES (?, ?, ?)');
        $stmt->execute([$data['name'], $data['price'], $data['stock']]);
        echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
        break;
    case 'update_product':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('UPDATE products SET name=?, price=?, stock=? WHERE id=?');
        $stmt->execute([$data['name'], $data['price'], $data['stock'], $data['id']]);
        echo json_encode(['success' => true]);
        break;
    case 'delete_product':
        $id = $_GET['id'] ?? 0;
        $stmt = $pdo->prepare('DELETE FROM products WHERE id=?');
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
        break;
    case 'get_import_history':
        $stmt = $pdo->query('SELECT * FROM import_history ORDER BY timestamp DESC');
        echo json_encode($stmt->fetchAll());
        break;
    case 'add_import':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('INSERT INTO import_history (product_id, quantity, import_price, total_cost, notes) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$data['product_id'], $data['quantity'], $data['import_price'], $data['total_cost'], $data['notes']]);
        // Update product stock
        $stmt2 = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
        $stmt2->execute([$data['quantity'], $data['product_id']]);
        echo json_encode(['success' => true]);
        break;
    case 'delete_import':
        $id = $_GET['id'] ?? 0;
        if ($id) {
            // Lấy thông tin đơn nhập để cập nhật tồn kho
            $stmt = $pdo->prepare('SELECT product_id, quantity FROM import_history WHERE id=?');
            $stmt->execute([$id]);
            $import = $stmt->fetch();
            if ($import) {
                // Trừ số lượng khỏi tồn kho sản phẩm
                $stmt2 = $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
                $stmt2->execute([$import['quantity'], $import['product_id']]);
                // Xóa đơn nhập
                $stmt3 = $pdo->prepare('DELETE FROM import_history WHERE id=?');
                $stmt3->execute([$id]);
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Không tìm thấy đơn nhập']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'ID không hợp lệ']);
        }
        break;
    case 'get_sales_history':
        $stmt = $pdo->query('SELECT * FROM sales_history ORDER BY timestamp DESC');
        $sales = $stmt->fetchAll();
        foreach ($sales as &$sale) {
            $stmt2 = $pdo->prepare('SELECT * FROM sales_items WHERE sales_history_id = ?');
            $stmt2->execute([$sale['id']]);
            $sale['items'] = $stmt2->fetchAll();
        }
        echo json_encode($sales);
        break;
    case 'add_sale':
        $data = json_decode(file_get_contents('php://input'), true);
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('INSERT INTO sales_history (customer_name, customer_phone, total_amount) VALUES (?, ?, ?)');
            $stmt->execute([$data['customer_name'], $data['customer_phone'], $data['total_amount']]);
            $saleId = $pdo->lastInsertId();
            foreach ($data['items'] as $item) {
                $stmt2 = $pdo->prepare('INSERT INTO sales_items (sales_history_id, product_id, quantity, sale_price, total_item_price) VALUES (?, ?, ?, ?, ?)');
                $stmt2->execute([$saleId, $item['product_id'], $item['quantity'], $item['sale_price'], $item['total_item_price']]);
                // Update product stock
                $stmt3 = $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
                $stmt3->execute([$item['quantity'], $item['product_id']]);
            }
            $pdo->commit();
            echo json_encode(['success' => true, 'id' => $saleId]);
        } catch (Exception $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['error' => 'Failed to save sale']);
        }
        break;
    case 'delete_sale':
        $id = $_GET['id'] ?? 0;
        if ($id) {
            $pdo->beginTransaction();
            try {
                // Lấy các sản phẩm trong đơn hàng
                $stmt = $pdo->prepare('SELECT product_id, quantity FROM sales_items WHERE sales_history_id = ?');
                $stmt->execute([$id]);
                $items = $stmt->fetchAll();
                // Tăng lại tồn kho cho từng sản phẩm
                foreach ($items as $item) {
                    $stmt2 = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
                    $stmt2->execute([$item['quantity'], $item['product_id']]);
                }
                // Xóa các item trong đơn hàng
                $stmt3 = $pdo->prepare('DELETE FROM sales_items WHERE sales_history_id = ?');
                $stmt3->execute([$id]);
                // Xóa đơn hàng
                $stmt4 = $pdo->prepare('DELETE FROM sales_history WHERE id = ?');
                $stmt4->execute([$id]);
                $pdo->commit();
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                $pdo->rollBack();
                echo json_encode(['success' => false, 'error' => 'Lỗi khi xóa đơn hàng']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'ID không hợp lệ']);
        }
        break;
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action']);
}
?>
