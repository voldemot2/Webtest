// Hiển thị danh sách sản phẩm tồn kho
function renderInventory() {
    const container = document.getElementById('inventoryListContainer');
    if (!container) {
        console.error("Element with ID 'inventoryListContainer' not found.");
        return;
    }
    container.innerHTML = '';
    const noInventoryMessage = document.getElementById('noInventoryMessage');
    if (noInventoryMessage) {
        if (products.length === 0) {
            noInventoryMessage.classList.remove('hidden');
        } else {
            noInventoryMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noInventoryMessage' not found.");
    }
    if (products.length === 0) {
        return;
    }
    products.forEach(product => {
        const inventoryDiv = document.createElement('div');
        inventoryDiv.className = 'inventory-item';
        // Hiển thị giá không có số 0 sau dấu thập phân
        const priceDisplay = Number(product.price).toLocaleString('vi-VN');
        inventoryDiv.innerHTML = `
            <div class="inventory-info">
                <div class="inventory-name">${product.name}</div>
                <div class="inventory-stock">Giá: ${priceDisplay} VNĐ | Tồn kho: <span class="font-bold text-blue-600">${product.stock}</span></div>
            </div>
            <div class="inventory-actions">
                <button class="edit-btn" onclick="editProduct('${product.id}')">Sửa</button>
                <button class="delete-btn" onclick="deleteProduct('${product.id}')">Xóa</button>
            </div>
        `;
        container.appendChild(inventoryDiv);
    });
}
// Thêm mới hoặc cập nhật sản phẩm trong kho
function addUpdateProduct() {
    const nameInput = document.getElementById('inventoryProductName');
    const priceInput = document.getElementById('inventoryProductPrice');
    const stockInput = document.getElementById('inventoryInitialStock');
    if (!nameInput || !priceInput || !stockInput) {
        console.error("Inventory input elements not found.");
        return;
    }
    const name = nameInput.value.trim();
    // Lưu giá là số nguyên nếu không có phần thập phân
    let price = parseFloat(priceInput.value);
    price = isNaN(price) ? 0 : (Number.isInteger(price) ? price : parseFloat(price));
    const initialStock = parseInt(stockInput.value);
    if (!name || isNaN(price) || price <= 0 || isNaN(initialStock) || initialStock < 0) {
        showMessage('Vui lòng nhập đầy đủ và đúng định dạng thông tin sản phẩm (tên, giá > 0, tồn kho >= 0).', 'error');
        return;
    }
    if (currentEditingProductId) {
        // Gọi API cập nhật sản phẩm
        fetch('api_banhang.php?action=update_product', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: currentEditingProductId, name, price, stock: initialStock })
        })
        .then(res => res.json())
        .then(() => {
            showMessage('Cập nhật sản phẩm thành công!', 'success');
            loadAllData().then(() => {
                resetInventoryForm();
                renderInventory();
                renderSalesProducts();
                loadImportProductOptions();
            });
        });
    } else {
        // Gọi API thêm sản phẩm mới
        fetch('api_banhang.php?action=add_product', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, price, stock: initialStock })
        })
        .then(res => res.json())
        .then(() => {
            showMessage('Thêm sản phẩm thành công!', 'success');
            loadAllData().then(() => {
                resetInventoryForm();
                renderInventory();
                renderSalesProducts();
                loadImportProductOptions();
            });
        });
    }
}
// Hiển thị thông tin sản phẩm lên form để chỉnh sửa
function editProduct(id) {
    // Đảm bảo so sánh id đúng kiểu (string/number)
    const productToEdit = products.find(p => p.id == id);
    if (productToEdit) {
        const nameInput = document.getElementById('inventoryProductName');
        const priceInput = document.getElementById('inventoryProductPrice');
        const stockInput = document.getElementById('inventoryInitialStock');
        const addUpdateBtn = document.getElementById('addUpdateProductBtn');
        if (nameInput && priceInput && stockInput && addUpdateBtn) {
            nameInput.value = productToEdit.name;
            // Hiển thị giá không có số 0 thừa sau dấu thập phân khi sửa
            priceInput.value = Number(productToEdit.price).toString();
            stockInput.value = productToEdit.stock;
            currentEditingProductId = id;
            addUpdateBtn.textContent = 'Cập Nhật Sản Phẩm';
            showMessage(`Đang sửa sản phẩm: "${productToEdit.name}"`, 'info');
        } else {
            console.error("Inventory form elements not found for editing.");
        }
    }
}
// Xóa sản phẩm khỏi kho và các lịch sử liên quan
function deleteProduct(id) {
    showConfirmationModal('Xác nhận xóa sản phẩm', 'Bạn có chắc chắn muốn xóa sản phẩm này khỏi kho? Hành động này không thể hoàn tác.', () => {
        fetch('api_banhang.php?action=delete_product&id=' + id)
        .then(res => res.json())
        .then(() => {
            showMessage('Xóa sản phẩm thành công!', 'success');
            loadAllData().then(() => {
                renderInventory();
                renderSalesProducts();
                loadImportProductOptions();
                renderImportHistory();
                // Chỉ tải lịch sử đơn hàng nếu đang mở rộng
                const content = document.getElementById('salesHistoryContent');
                if (content && !content.classList.contains('hidden')) {
                    loadSalesHistoryOnExpand();
                }
                resetInventoryForm();
            });
        });
    });
}
// Reset form nhập sản phẩm về trạng thái mặc định
function resetInventoryForm() {
    const nameInput = document.getElementById('inventoryProductName');
    const priceInput = document.getElementById('inventoryProductPrice');
    const stockInput = document.getElementById('inventoryInitialStock');
    const addUpdateBtn = document.getElementById('addUpdateProductBtn');
    if (nameInput && priceInput && stockInput && addUpdateBtn) {
        nameInput.value = '';
        priceInput.value = '';
        stockInput.value = '';
        currentEditingProductId = null;
        addUpdateBtn.textContent = 'Thêm Sản Phẩm Mới';
    } else {
        console.error("Inventory form elements not found for reset.");
    }
}

