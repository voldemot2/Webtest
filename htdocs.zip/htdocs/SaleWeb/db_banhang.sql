-- SaleWeb Database Schema
-- Table: products
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `price` DECIMAL(15,2) NOT NULL,
  `stock` INT NOT NULL DEFAULT 0
);

-- Table: import_history
CREATE TABLE `import_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `quantity` INT NOT NULL,
  `import_price` DECIMAL(15,2) NOT NULL,
  `total_cost` DECIMAL(15,2) NOT NULL,
  `notes` VARCHAR(255),
  `timestamp` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- Table: sales_history
CREATE TABLE `sales_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `customer_name` VARCHAR(255) NOT NULL,
  `customer_phone` VARCHAR(50) NOT NULL,
  `total_amount` DECIMAL(15,2) NOT NULL,
  `timestamp` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table: sales_items
CREATE TABLE `sales_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sales_history_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `quantity` INT NOT NULL,
  `sale_price` DECIMAL(15,2) NOT NULL,
  `total_item_price` DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (`sales_history_id`) REFERENCES `sales_history`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);
