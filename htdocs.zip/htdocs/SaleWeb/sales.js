// Hiển thị danh sách sản phẩm để bán
function renderSalesProducts() {
    const container = document.getElementById('salesProductsList');
    if (!container) {
        console.error("Element with ID 'salesProductsList' not found.");
        return;
    }
    container.innerHTML = '';
    const noProductsMessage = document.getElementById('noSalesProductsMessage');
    if (noProductsMessage) {
        if (products.length === 0) {
            noProductsMessage.classList.remove('hidden');
        } else {
            noProductsMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noSalesProductsMessage' not found. This message should be present in HTML.");
    }
    if (products.length === 0) {
        return;
    }
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <div class="product-card-info">
                <div class="product-card-name">${product.name}</div>
                <div class="product-card-price">${Number(product.price).toLocaleString('vi-VN', { maximumFractionDigits: 0, minimumFractionDigits: 0 })} VNĐ (Tồn: ${product.stock})</div>
            </div>
            <div class="product-card-actions">
                <button class="add-to-cart-btn" onclick="addToCart('${product.id}')">Thêm vào giỏ</button>
            </div>
        `;
        container.appendChild(productCard);
    });
}
// Thêm sản phẩm vào giỏ hàng
function addToCart(productId) {
    const product = products.find(p => p.id == productId);
    if (!product) {
        showMessage('Sản phẩm không tồn tại.', 'error');
        return;
    }
    if (product.stock <= 0) {
        showMessage(`Sản phẩm "${product.name}" đã hết hàng.`, 'error');
        return;
    }
    const existingCartItem = cart.find(item => item.id == productId);
    if (existingCartItem) {
        if (existingCartItem.quantity < product.stock) {
            existingCartItem.quantity++;
            showMessage(`Đã thêm 1 "${product.name}" vào giỏ.`, 'info');
        } else {
            showMessage(`Không thể thêm thêm "${product.name}", đã đạt số lượng tồn kho tối đa.`, 'error');
        }
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
        showMessage(`Đã thêm "${product.name}" vào giỏ hàng.`, 'success');
    }
    renderCart();
}
// Cập nhật giá bán cho sản phẩm trong giỏ hàng
function updateCartItemPrice(inputElement, productId) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        const newPrice = parseFloat(inputElement.value);
        if (!isNaN(newPrice) && newPrice >= 0) {
            item.price = newPrice;
            const itemTotalSpan = document.getElementById(`cartItemTotal_${item.id}`);
            if (itemTotalSpan) {
                itemTotalSpan.textContent = (item.quantity * item.price).toLocaleString('vi-VN', { maximumFractionDigits: 0 });
            }
        } else {
            showMessage('Giá không hợp lệ. Vui lòng nhập số dương.', 'error');
            inputElement.value = item.price;
        }
    }
    updateCartTotalDisplay();
}
// Giảm số lượng hoặc xóa sản phẩm khỏi giỏ hàng
function removeFromCart(productId) {
    const itemIndex = cart.findIndex(item => item.id == productId);
    if (itemIndex !== -1) {
        if (cart[itemIndex].quantity > 1) {
            cart[itemIndex].quantity--;
            showMessage(`Đã giảm số lượng "${cart[itemIndex].name}" trong giỏ.`, 'info');
        } else {
            const removedItemName = cart[itemIndex].name;
            cart.splice(itemIndex, 1);
            showMessage(`Đã xóa "${removedItemName}" khỏi giỏ hàng.`, 'success');
        }
    }
    renderCart();
}
// Hiển thị giỏ hàng và tổng tiền
function renderCart() {
    const cartItemsContainer = document.getElementById('cartItems');
    if (!cartItemsContainer) {
        console.error("Element with ID 'cartItems' not found.");
        return;
    }
    cartItemsContainer.innerHTML = '';
    const emptyCartMessage = document.getElementById('emptyCartMessage');
    if (emptyCartMessage) {
        if (cart.length === 0) {
            emptyCartMessage.classList.remove('hidden');
        } else {
            emptyCartMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'emptyCartMessage' not found.");
    }
    cart.forEach(item => {
        const cartItemDiv = document.createElement('div');
        cartItemDiv.className = 'cart-item';
        cartItemDiv.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-details">
                    Số lượng: ${item.quantity} x
                    <input type="number" class="cart-item-price-input" id="cartItemPrice_${item.id}" value="${Number(item.price).toLocaleString('vi-VN', { maximumFractionDigits: 0, minimumFractionDigits: 0 })}">
                    VNĐ = <span id="cartItemTotal_${item.id}">${(item.quantity * item.price).toLocaleString('vi-VN', { maximumFractionDigits: 0, minimumFractionDigits: 0 })}</span> VNĐ
                </div>
            </div>
            <div class="cart-item-actions">
                <button class="remove-from-cart-btn" onclick="removeFromCart('${item.id}')">-</button>
                <button class="add-to-cart-btn" onclick="addToCart('${item.id}')">+</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItemDiv);
        const priceInput = document.getElementById(`cartItemPrice_${item.id}`);
        if (priceInput) {
            priceInput.oninput = (event) => {
                updateCartItemPrice(event.target, item.id);
            };
        }
    });
    updateCartTotalDisplay();
}
// Cập nhật tổng tiền giỏ hàng
function updateCartTotalDisplay() {
    let total = cart.reduce((sum, item) => sum + (item.quantity * item.price), 0);
    const cartTotalElement = document.getElementById('cartTotal');
    if (cartTotalElement) {
        cartTotalElement.textContent = total.toLocaleString('vi-VN', { maximumFractionDigits: 0 }) + ' VNĐ';
    } else {
        console.error("Element with ID 'cartTotal' not found.");
    }
}
// Hoàn tất đơn hàng, lưu lịch sử bán và cập nhật tồn kho
function completeSale() {
    if (cart.length === 0) {
        showMessage('Giỏ hàng trống. Vui lòng thêm sản phẩm để bán.', 'error');
        return;
    }
    const customerNameInput = document.getElementById('customerName');
    const customerPhoneInput = document.getElementById('customerPhone');
    const customerName = customerNameInput.value.trim();
    const customerPhone = customerPhoneInput.value.trim();
    if (!customerName) {
        showMessage('Vui lòng nhập tên khách hàng.', 'error');
        return;
    }
    if (!customerPhone) {
        showMessage('Vui lòng nhập số điện thoại khách hàng.', 'error');
        return;
    }
    showConfirmationModal('Xác nhận bán hàng', `Bạn có chắc chắn muốn hoàn tất đơn hàng này cho khách hàng ${customerName} (${customerPhone})?`, () => {
        // Chuẩn bị dữ liệu gửi lên backend
        const itemsForBackend = cart.map(item => ({
            product_id: item.id,
            quantity: item.quantity,
            sale_price: item.price,
            total_item_price: item.quantity * item.price
        }));
        const totalSaleAmount = cart.reduce((sum, item) => sum + (item.quantity * item.price), 0);
        fetch('api_banhang.php?action=add_sale', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                customer_name: customerName,
                customer_phone: customerPhone,
                total_amount: totalSaleAmount,
                items: itemsForBackend
            })
        })
        .then(res => res.json())
        .then(result => {
            if (result.success) {
                showMessage(`Đơn hàng hoàn tất cho ${customerName} (${customerPhone})! Tổng tiền: ${totalSaleAmount.toLocaleString('vi-VN')} VNĐ.`, 'success');
                cart = [];
                customerNameInput.value = '';
                customerPhoneInput.value = '';
                renderCart();
                loadAllData().then(() => {
                    renderSalesProducts();
                    renderInventory();
                    // Chỉ tải lịch sử đơn hàng nếu đang mở rộng
                    const content = document.getElementById('salesHistoryContent');
                    if (content && !content.classList.contains('hidden')) {
                        loadSalesHistoryOnExpand();
                    }
                });
            } else {
                showMessage('Lưu đơn hàng thất bại!', 'error');
            }
        })
        .catch(() => showMessage('Lỗi kết nối server!', 'error'));
    });
}
// Hiển thị lịch sử bán hàng
// Chỉ tải lịch sử đơn hàng khi mở rộng danh sách
window.salesHistoryLoaded = false;
function loadSalesHistoryOnExpand() {
    if (window.salesHistoryLoaded) return;
    window.salesHistoryLoaded = true;
    renderSalesHistory();
}

function renderSalesHistory() {
    const container = document.getElementById('salesHistoryList');
    if (!container) {
        console.error("Element with ID 'salesHistoryList' not found.");
        return;
    }
    container.innerHTML = '';
    fetch('api_banhang.php?action=get_sales_history')
        .then(res => res.json())
        .then(salesHistory => {
            // Đảm bảo salesHistory là mảng
            if (!Array.isArray(salesHistory)) {
                salesHistory = Object.values(salesHistory);
            }
            const countSpan = document.getElementById('salesHistoryCount');
            if (countSpan) {
                countSpan.textContent = salesHistory.length;
            }
            const noSalesHistoryMessage = document.getElementById('noSalesHistoryMessage');
            if (noSalesHistoryMessage) {
                if (salesHistory.length === 0) {
                    noSalesHistoryMessage.classList.remove('hidden');
                } else {
                    noSalesHistoryMessage.classList.add('hidden');
                }
            } else {
                console.error("Element with ID 'noSalesHistoryMessage' not found.");
            }
            if (salesHistory.length === 0) {
                return;
            }
            console.log('Sales history:', salesHistory);
            salesHistory.forEach(record => {
                const recordDiv = document.createElement('div');
                recordDiv.className = 'sales-record-item';
                let itemsHtml = '';
                if (Array.isArray(record.items)) {
                    itemsHtml = record.items.map(item => {
                        let productName = item.product_name;
                        if (!productName) {
                            const found = products.find(p => p.id == item.product_id);
                            productName = found ? found.name : 'Không xác định';
                        }
                        return `<li>${productName} (${item.quantity} x ${Number(item.sale_price).toLocaleString('vi-VN', { maximumFractionDigits: 0, minimumFractionDigits: 0 })} VNĐ)</li>`;
                    }).join('');
                } else {
                    itemsHtml = '<li>Không có thông tin sản phẩm</li>';
                }
                recordDiv.innerHTML = `
                    <div class="sales-record-info">
                        <div class="sales-record-customer">Khách hàng: ${record.customer_name} (${record.customer_phone})</div>
                        <div class="sales-record-details">
                            <strong>Tổng tiền: ${Number(record.total_amount).toLocaleString('vi-VN', { maximumFractionDigits: 0 })} VNĐ</strong><br>
                            Sản phẩm:<br>
                            <ul>${itemsHtml}</ul>
                            Thời gian: ${record.timestamp}
                        </div>
                    </div>
                    <button class="delete-sales-record-btn" onclick="deleteSalesRecord('${record.id}')">&#x2715;</button>
                `;
                container.appendChild(recordDiv);
                console.log('Appended:', recordDiv);
            });
        });
}
// Xóa một đơn bán hàng khỏi lịch sử
function deleteSalesRecord(id) {
    showConfirmationModal('Xác nhận xóa đơn hàng', 'Bạn có chắc chắn muốn xóa đơn hàng này khỏi lịch sử? Hành động này không thể hoàn tác.', () => {
        fetch(`api_banhang.php?action=delete_sale&id=${id}`, { method: 'POST' })
            .then(res => res.json())
            .then(result => {
                if (result.success) {
                    showMessage('Xóa đơn hàng thành công!', 'success');
                    // Xóa phần tử khỏi DOM ngay lập tức
                    const recordDiv = document.querySelector(`.sales-record-item button.delete-sales-record-btn[onclick*="${id}"]`);
                    if (recordDiv) {
                        const parent = recordDiv.closest('.sales-record-item');
                        if (parent) parent.remove();
                    }
                    // Cập nhật lại số lượng badge
                    const countSpan = document.getElementById('salesHistoryCount');
                    if (countSpan) {
                        let currentCount = parseInt(countSpan.textContent, 10);
                        if (!isNaN(currentCount) && currentCount > 0) {
                            countSpan.textContent = currentCount - 1;
                        }
                    }
                    // Nếu không còn đơn hàng, hiển thị thông báo
                    const container = document.getElementById('salesHistoryList');
                    if (container && container.children.length === 0) {
                        const noSalesHistoryMessage = document.getElementById('noSalesHistoryMessage');
                        if (noSalesHistoryMessage) {
                            noSalesHistoryMessage.classList.remove('hidden');
                        }
                    }
                    // Cập nhật lại sản phẩm và tồn kho
                    loadAllData().then(() => {
                        renderSalesProducts();
                        renderInventory();
                    });
                } else {
                    showMessage('Xóa đơn hàng thất bại!', 'error');
                }
            })
            .catch(() => showMessage('Lỗi kết nối server!', 'error'));
    });
}

