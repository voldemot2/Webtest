// storage.js: Chứa các hàm lưu trữ và tải dữ liệu từ localStorage
// storage.js: Chứa các hàm lưu trữ và tải dữ liệu từ backend PHP
async function saveAllData() {
    // Hàm này không còn lưu toàn bộ, từng thao tác sẽ gọi API tương ứng
    // Giữ lại để tương thích, nhưng không làm gì
    return true;
}

async function loadAllData() {
    // Tải dữ liệu từ backend
    // Lấy sản phẩm
    const resProducts = await fetch('api_banhang.php?action=get_products');
    products = await resProducts.json();

    // Lấy lịch sử nhập hàng
    const resImport = await fetch('api_banhang.php?action=get_import_history');
    importHistory = await resImport.json();

    // KHÔNG tải lịch sử bán hàng ở đây nữa, chỉ tải khi mở rộng lịch sử
}
