// Tải danh sách sản phẩm vào dropdown nhập hàng
function loadImportProductOptions() {
    const selectElement = document.getElementById('importProductId');
    if (!selectElement) {
        console.error("Element with ID 'importProductId' not found.");
        return;
    }
    selectElement.innerHTML = '<option value="">Chọn sản phẩm</option>';
    const noImportProductsMessage = document.getElementById('noImportProductsMessage');
    if (noImportProductsMessage) {
        if (products.length === 0) {
            noImportProductsMessage.classList.remove('hidden');
        } else {
            noImportProductsMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noImportProductsMessage' not found.");
    }
    if (products.length === 0) {
        return;
    }
    products.forEach(product => {
        const option = document.createElement('option');
        option.value = product.id;
        option.textContent = product.name;
        selectElement.appendChild(option);
    });
}
// Xử lý nhập hàng và lưu vào lịch sử nhập
function recordImport() {
    const productIdInput = document.getElementById('importProductId');
    const quantityInput = document.getElementById('importQuantity');
    const priceInput = document.getElementById('importPrice');
    const notesInput = document.getElementById('importNotes');
    if (!productIdInput || !quantityInput || !priceInput || !notesInput) {
        console.error("Import input elements not found.");
        return;
    }
    const productId = productIdInput.value;
    const quantity = parseInt(quantityInput.value);
    const importPrice = parseFloat(priceInput.value);
    const notes = notesInput.value.trim();
    if (!productId || isNaN(quantity) || quantity <= 0 || isNaN(importPrice) || importPrice < 0) {
        showMessage('Vui lòng chọn sản phẩm, nhập số lượng (> 0) và giá nhập (>= 0) hợp lệ.', 'error');
        return;
    }
    // Gọi API nhập hàng
    fetch('api_banhang.php?action=add_import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            product_id: productId,
            quantity,
            import_price: importPrice,
            total_cost: quantity * importPrice,
            notes
        })
    })
    .then(res => res.json())
    .then(() => {
        showMessage(`Nhập ${quantity} sản phẩm thành công.`, 'success');
        loadAllData().then(() => {
            productIdInput.value = '';
            quantityInput.value = '';
            priceInput.value = '';
            notesInput.value = '';
            renderImportHistory();
            renderInventory();
            renderSalesProducts();
        });
    });
}
// Hiển thị lịch sử nhập hàng
function renderImportHistory() {
    const container = document.getElementById('importHistoryList');
    if (!container) {
        console.error("Element with ID 'importHistoryList' not found.");
        return;
    }
    container.innerHTML = '';
    const noImportHistoryMessage = document.getElementById('noImportHistoryMessage');
    if (noImportHistoryMessage) {
        if (importHistory.length === 0) {
            noImportHistoryMessage.classList.remove('hidden');
        } else {
            noImportHistoryMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noImportHistoryMessage' not found.");
    }
    if (importHistory.length === 0) {
        return;
    }
    importHistory.forEach(record => {
        // Tìm tên sản phẩm từ danh sách products
        let productName = '';
        if (record.productName) {
            productName = record.productName;
        } else if (record.product_id) {
            const product = products.find(p => p.id == record.product_id);
            productName = product ? product.name : 'Không xác định';
        } else {
            productName = 'Không xác định';
        }
        const recordDiv = document.createElement('div');
        recordDiv.className = 'import-record-item';
        recordDiv.style.position = 'relative';
        recordDiv.innerHTML = `
            <div class="import-record-info">
                <div class="import-record-name"><strong>${productName}</strong> - ${record.quantity} sản phẩm</div>
                <div class="import-record-details">
                    Giá nhập: ${Number(record.import_price || 0).toLocaleString('vi-VN')} VNĐ/SP<br>
                    Tổng tiền: ${Number(record.total_cost || 0).toLocaleString('vi-VN')} VNĐ<br>
                    Ghi chú: ${record.notes || 'Không có'}<br>
                    Thời gian: ${record.timestamp}
                </div>
            </div>
            <button class="delete-import-record-btn" onclick="deleteImportRecord('${record.id}')">&#x2715;</button>
        `;
        container.appendChild(recordDiv);
    });
}
// Xóa một đơn nhập hàng khỏi lịch sử
function deleteImportRecord(id) {
    showConfirmationModal('Xác nhận xóa đơn nhập hàng', 'Bạn có chắc chắn muốn xóa đơn nhập này khỏi lịch sử? Hành động này không thể hoàn tác.', () => {
        fetch(`api_banhang.php?action=delete_import&id=${id}`, { method: 'POST' })
            .then(res => res.json())
            .then(result => {
                if (result.success) {
                    showMessage('Xóa đơn nhập hàng thành công!', 'success');
                    loadAllData().then(renderImportHistory);
                } else {
                    showMessage('Xóa đơn nhập hàng thất bại!', 'error');
                }
            })
            .catch(() => showMessage('Lỗi kết nối server!', 'error'));
    });
}

