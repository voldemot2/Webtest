let products = [];
let cart = [];
let importHistory = [];
let salesHistory = [];
let currentEditingProductId = null;

// --- Utility Functions ---
function showMessage(message, type = 'success') {
    const messageBox = document.getElementById('messageBox');
    const messageText = document.getElementById('messageText');
    if (messageBox && messageText) {
        messageText.textContent = message;
        messageBox.className = 'message-box';
        if (type === 'success') {
            messageBox.classList.add('bg-green-100', 'text-green-800');
        } else if (type === 'error') {
            messageBox.classList.add('bg-red-100', 'text-red-800');
        } else if (type === 'info') {
            messageBox.classList.add('bg-blue-100', 'text-blue-800');
        }
        messageBox.classList.add('show');
        setTimeout(hideMessage, 5000);
    } else {
        console.error("Message box elements not found.");
    }
}
function hideMessage() {
    const messageBox = document.getElementById('messageBox');
    if (messageBox) {
        messageBox.classList.remove('show');
        setTimeout(() => {
            messageBox.className = 'message-box';
        }, 500);
    }
}
function showConfirmationModal(title, message, onConfirm) {
    const modal = document.getElementById('confirmationModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalMessage = document.getElementById('modalMessage');
    const confirmBtn = document.getElementById('modalConfirmBtn');
    const cancelBtn = document.getElementById('modalCancelBtn');
    if (!modal || !modalTitle || !modalMessage || !confirmBtn || !cancelBtn) {
        console.error("Modal elements not found.");
        return;
    }
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    confirmBtn.onclick = null;
    cancelBtn.onclick = null;
    confirmBtn.onclick = () => {
        modal.style.display = 'none';
        onConfirm();
    };
    cancelBtn.onclick = () => {
        modal.style.display = 'none';
    };
    modal.style.display = 'flex';
}
function toggleCollapsible(contentId, iconId) {
    const content = document.getElementById(contentId);
    const icon = document.getElementById(iconId);
    if (content && icon) {
        content.classList.toggle('expanded');
        icon.classList.toggle('rotated');
    }
}
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById('tab' + sectionId.charAt(0).toUpperCase() + sectionId.slice(1)).classList.add('active');
    if (sectionId === 'sales') {
        renderSalesProducts();
        renderCart();
        renderSalesHistory();
    } else if (sectionId === 'import') {
        loadImportProductOptions();
        renderImportHistory();
    } else if (sectionId === 'inventory') {
        renderInventory();
        resetInventoryForm();
    }
}
// --- Sales Page Functions ---
function renderSalesProducts() {
    const container = document.getElementById('salesProductsList');
    if (!container) {
        console.error("Element with ID 'salesProductsList' not found.");
        return;
    }
    container.innerHTML = '';
    const noProductsMessage = document.getElementById('noSalesProductsMessage');
    if (noProductsMessage) {
        if (products.length === 0) {
            noProductsMessage.classList.remove('hidden');
        } else {
            noProductsMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noSalesProductsMessage' not found. This message should be present in HTML.");
    }
    if (products.length === 0) {
        return;
    }
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <div class="product-card-info">
                <div class="product-card-name">${product.name}</div>
                <div class="product-card-price">${product.price.toLocaleString('vi-VN')} VNĐ (Tồn: ${product.stock})</div>
            </div>
            <div class="product-card-actions">
                <button class="add-to-cart-btn" onclick="addToCart('${product.id}')">Thêm vào giỏ</button>
            </div>
        `;
        container.appendChild(productCard);
    });
}
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) {
        showMessage('Sản phẩm không tồn tại.', 'error');
        return;
    }
    if (product.stock <= 0) {
        showMessage(`Sản phẩm "${product.name}" đã hết hàng.`, 'error');
        return;
    }
    const existingCartItem = cart.find(item => item.id === productId);
    if (existingCartItem) {
        if (existingCartItem.quantity < product.stock) {
            existingCartItem.quantity++;
            showMessage(`Đã thêm 1 "${product.name}" vào giỏ.`, 'info');
        } else {
            showMessage(`Không thể thêm thêm "${product.name}", đã đạt số lượng tồn kho tối đa.`, 'error');
        }
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
        showMessage(`Đã thêm "${product.name}" vào giỏ hàng.`, 'success');
    }
    renderCart();
}
function updateCartItemPrice(inputElement, productId) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        const newPrice = parseFloat(inputElement.value);
        if (!isNaN(newPrice) && newPrice >= 0) {
            item.price = newPrice;
            const itemTotalSpan = document.getElementById(`cartItemTotal_${item.id}`);
            if (itemTotalSpan) {
                itemTotalSpan.textContent = (item.quantity * item.price).toLocaleString('vi-VN');
            }
        } else {
            showMessage('Giá không hợp lệ. Vui lòng nhập số dương.', 'error');
            inputElement.value = item.price;
        }
    }
    updateCartTotalDisplay();
}
function removeFromCart(productId) {
    const itemIndex = cart.findIndex(item => item.id === productId);
    if (itemIndex !== -1) {
        if (cart[itemIndex].quantity > 1) {
            cart[itemIndex].quantity--;
            showMessage(`Đã giảm số lượng "${cart[itemIndex].name}" trong giỏ.`, 'info');
        } else {
            const removedItemName = cart[itemIndex].name;
            cart.splice(itemIndex, 1);
            showMessage(`Đã xóa "${removedItemName}" khỏi giỏ hàng.`, 'success');
        }
    }
    renderCart();
}
function renderCart() {
    const cartItemsContainer = document.getElementById('cartItems');
    if (!cartItemsContainer) {
        console.error("Element with ID 'cartItems' not found.");
        return;
    }
    cartItemsContainer.innerHTML = '';
    const emptyCartMessage = document.getElementById('emptyCartMessage');
    if (emptyCartMessage) {
        if (cart.length === 0) {
            emptyCartMessage.classList.remove('hidden');
        } else {
            emptyCartMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'emptyCartMessage' not found.");
    }
    cart.forEach(item => {
        const cartItemDiv = document.createElement('div');
        cartItemDiv.className = 'cart-item';
        cartItemDiv.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-details">
                    Số lượng: ${item.quantity} x
                    <input type="number" class="cart-item-price-input" id="cartItemPrice_${item.id}" value="${item.price}">
                    VNĐ = <span id="cartItemTotal_${item.id}">${(item.quantity * item.price).toLocaleString('vi-VN')}</span> VNĐ
                </div>
            </div>
            <div class="cart-item-actions">
                <button class="remove-from-cart-btn" onclick="removeFromCart('${item.id}')">-</button>
                <button class="add-to-cart-btn" onclick="addToCart('${item.id}')">+</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItemDiv);
        const priceInput = document.getElementById(`cartItemPrice_${item.id}`);
        if (priceInput) {
            priceInput.oninput = (event) => {
                updateCartItemPrice(event.target, item.id);
            };
        }
    });
    updateCartTotalDisplay();
}
function updateCartTotalDisplay() {
    let total = cart.reduce((sum, item) => sum + (item.quantity * item.price), 0);
    const cartTotalElement = document.getElementById('cartTotal');
    if (cartTotalElement) {
        cartTotalElement.textContent = total.toLocaleString('vi-VN') + ' VNĐ';
    } else {
        console.error("Element with ID 'cartTotal' not found.");
    }
}
function completeSale() {
    if (cart.length === 0) {
        showMessage('Giỏ hàng trống. Vui lòng thêm sản phẩm để bán.', 'error');
        return;
    }
    const customerNameInput = document.getElementById('customerName');
    const customerPhoneInput = document.getElementById('customerPhone');
    const customerName = customerNameInput.value.trim();
    const customerPhone = customerPhoneInput.value.trim();
    if (!customerName) {
        showMessage('Vui lòng nhập tên khách hàng.', 'error');
        return;
    }
    if (!customerPhone) {
        showMessage('Vui lòng nhập số điện thoại khách hàng.', 'error');
        return;
    }
    showConfirmationModal('Xác nhận bán hàng', `Bạn có chắc chắn muốn hoàn tất đơn hàng này cho khách hàng ${customerName} (${customerPhone})?`, () => {
        let saleSuccessful = true;
        const soldItems = [];
        const itemsForHistory = [];
        for (const cartItem of cart) {
            const product = products.find(p => p.id === cartItem.id);
            if (product && product.stock >= cartItem.quantity) {
                product.stock -= cartItem.quantity;
                soldItems.push(`${cartItem.quantity} ${product.name} (Giá bán: ${cartItem.price.toLocaleString('vi-VN')} VNĐ)`);
                itemsForHistory.push({
                    productId: cartItem.id,
                    productName: cartItem.name,
                    quantity: cartItem.quantity,
                    salePrice: cartItem.price,
                    totalItemPrice: cartItem.quantity * cartItem.price
                });
            } else {
                showMessage(`Không đủ số lượng cho "${cartItem.name}". Tồn kho hiện tại: ${product ? product.stock : 'N/A'}`, 'error');
                saleSuccessful = false;
                break;
            }
        }
        if (saleSuccessful) {
            const totalSaleAmount = cart.reduce((sum, item) => sum + (item.quantity * item.price), 0);
            salesHistory.unshift({
                id: Date.now().toString(),
                customerName: customerName,
                customerPhone: customerPhone,
                items: itemsForHistory,
                totalAmount: totalSaleAmount,
                timestamp: new Date().toLocaleString('vi-VN')
            });
            showMessage(`Đơn hàng hoàn tất cho ${customerName} (${customerPhone})! Đã bán: ${soldItems.join(', ')}. Tổng tiền: ${totalSaleAmount.toLocaleString('vi-VN')} VNĐ.`, 'success');
            cart = [];
            customerNameInput.value = '';
            customerPhoneInput.value = '';
            saveAllData();
            renderCart();
            renderSalesProducts();
            renderInventory();
            renderSalesHistory();
        }
    });
}
function renderSalesHistory() {
    const container = document.getElementById('salesHistoryList');
    if (!container) {
        console.error("Element with ID 'salesHistoryList' not found.");
        return;
    }
    container.innerHTML = '';
    const noSalesHistoryMessage = document.getElementById('noSalesHistoryMessage');
    if (noSalesHistoryMessage) {
        if (salesHistory.length === 0) {
            noSalesHistoryMessage.classList.remove('hidden');
        } else {
            noSalesHistoryMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noSalesHistoryMessage' not found.");
    }
    if (salesHistory.length === 0) {
        return;
    }
    salesHistory.forEach(record => {
        const recordDiv = document.createElement('div');
        recordDiv.className = 'sales-record-item';
        let itemsHtml = record.items.map(item => `
            <li>${item.productName} (${item.quantity} x ${item.salePrice.toLocaleString('vi-VN')} VNĐ)</li>
        `).join('');
        recordDiv.innerHTML = `
            <div class="sales-record-info">
                <div class="sales-record-customer">Khách hàng: ${record.customerName} (${record.customerPhone})</div>
                <div class="sales-record-details">
                    <strong>Tổng tiền: ${record.totalAmount.toLocaleString('vi-VN')} VNĐ</strong><br>
                    Sản phẩm:<br>
                    <ul>${itemsHtml}</ul>
                    Thời gian: ${record.timestamp}
                </div>
            </div>
            <button class="delete-sales-record-btn" onclick="deleteSalesRecord('${record.id}')">&#x2715;</button>
        `;
        container.appendChild(recordDiv);
    });
}
function deleteSalesRecord(id) {
    showConfirmationModal('Xác nhận xóa đơn hàng', 'Bạn có chắc chắn muốn xóa đơn hàng này khỏi lịch sử? Hành động này không thể hoàn tác.', () => {
        salesHistory = salesHistory.filter(record => record.id !== id);
        showMessage('Xóa đơn hàng thành công!', 'success');
        saveAllData();
        renderSalesHistory();
    });
}
// --- Import Page Functions ---
function loadImportProductOptions() {
    const selectElement = document.getElementById('importProductId');
    if (!selectElement) {
        console.error("Element with ID 'importProductId' not found.");
        return;
    }
    selectElement.innerHTML = '<option value="">Chọn sản phẩm</option>';
    const noImportProductsMessage = document.getElementById('noImportProductsMessage');
    if (noImportProductsMessage) {
        if (products.length === 0) {
            noImportProductsMessage.classList.remove('hidden');
        } else {
            noImportProductsMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noImportProductsMessage' not found.");
    }
    if (products.length === 0) {
        return;
    }
    products.forEach(product => {
        const option = document.createElement('option');
        option.value = product.id;
        option.textContent = product.name;
        selectElement.appendChild(option);
    });
}
function recordImport() {
    const productIdInput = document.getElementById('importProductId');
    const quantityInput = document.getElementById('importQuantity');
    const priceInput = document.getElementById('importPrice');
    const notesInput = document.getElementById('importNotes');
    if (!productIdInput || !quantityInput || !priceInput || !notesInput) {
        console.error("Import input elements not found.");
        return;
    }
    const productId = productIdInput.value;
    const quantity = parseInt(quantityInput.value);
    const importPrice = parseFloat(priceInput.value);
    const notes = notesInput.value.trim();
    if (!productId || isNaN(quantity) || quantity <= 0 || isNaN(importPrice) || importPrice < 0) {
        showMessage('Vui lòng chọn sản phẩm, nhập số lượng (> 0) và giá nhập (>= 0) hợp lệ.', 'error');
        return;
    }
    const product = products.find(p => p.id === productId);
    if (product) {
        product.stock += quantity;
        importHistory.unshift({
            id: Date.now().toString(),
            productId: productId,
            productName: product.name,
            quantity: quantity,
            importPrice: importPrice,
            totalCost: quantity * importPrice,
            notes: notes,
            timestamp: new Date().toLocaleString('vi-VN')
        });
        showMessage(`Nhập ${quantity} "${product.name}" thành công. Tồn kho hiện tại: ${product.stock}`, 'success');
        saveAllData();
    } else {
        showMessage('Sản phẩm không tìm thấy.', 'error');
    }
    productIdInput.value = '';
    quantityInput.value = '';
    priceInput.value = '';
    notesInput.value = '';
    renderImportHistory();
    renderInventory();
    renderSalesProducts();
}
function renderImportHistory() {
    const container = document.getElementById('importHistoryList');
    if (!container) {
        console.error("Element with ID 'importHistoryList' not found.");
        return;
    }
    container.innerHTML = '';
    const noImportHistoryMessage = document.getElementById('noImportHistoryMessage');
    if (noImportHistoryMessage) {
        if (importHistory.length === 0) {
            noImportHistoryMessage.classList.remove('hidden');
        } else {
            noImportHistoryMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noImportHistoryMessage' not found.");
    }
    if (importHistory.length === 0) {
        return;
    }
    importHistory.forEach(record => {
        const recordDiv = document.createElement('div');
        recordDiv.className = 'import-record-item';
        recordDiv.style.position = 'relative';
        recordDiv.innerHTML = `
            <div class="import-record-info">
                <div class="import-record-name"><strong>${record.productName}</strong> - ${record.quantity} sản phẩm</div>
                <div class="import-record-details">
                    Giá nhập: ${record.importPrice.toLocaleString('vi-VN')} VNĐ/SP<br>
                    Tổng tiền: ${record.totalCost.toLocaleString('vi-VN')} VNĐ<br>
                    Ghi chú: ${record.notes || 'Không có'}<br>
                    Thời gian: ${record.timestamp}
                </div>
            </div>
            <button class="delete-import-record-btn" onclick="deleteImportRecord('${record.id}')">&#x2715;</button>
        `;
        container.appendChild(recordDiv);
    });
}
function deleteImportRecord(id) {
    showConfirmationModal('Xác nhận xóa đơn nhập hàng', 'Bạn có chắc chắn muốn xóa đơn nhập này khỏi lịch sử? Hành động này không thể hoàn tác.', () => {
        importHistory = importHistory.filter(record => record.id !== id);
        showMessage('Xóa đơn nhập hàng thành công!', 'success');
        saveAllData();
        renderImportHistory();
    });
}
// --- Inventory Management Functions ---
function renderInventory() {
    const container = document.getElementById('inventoryListContainer');
    if (!container) {
        console.error("Element with ID 'inventoryListContainer' not found.");
        return;
    }
    container.innerHTML = '';
    const noInventoryMessage = document.getElementById('noInventoryMessage');
    if (noInventoryMessage) {
        if (products.length === 0) {
            noInventoryMessage.classList.remove('hidden');
        } else {
            noInventoryMessage.classList.add('hidden');
        }
    } else {
        console.error("Element with ID 'noInventoryMessage' not found.");
    }
    if (products.length === 0) {
        return;
    }
    products.forEach(product => {
        const inventoryDiv = document.createElement('div');
        inventoryDiv.className = 'inventory-item';
        inventoryDiv.innerHTML = `
            <div class="inventory-info">
                <div class="inventory-name">${product.name}</div>
                <div class="inventory-stock">Giá: ${product.price.toLocaleString('vi-VN')} VNĐ | Tồn kho: <span class="font-bold text-blue-600">${product.stock}</span></div>
            </div>
            <div class="inventory-actions">
                <button class="edit-btn" onclick="editProduct('${product.id}')">Sửa</button>
                <button class="delete-btn" onclick="deleteProduct('${product.id}')">Xóa</button>
            </div>
        `;
        container.appendChild(inventoryDiv);
    });
}
function addUpdateProduct() {
    const nameInput = document.getElementById('inventoryProductName');
    const priceInput = document.getElementById('inventoryProductPrice');
    const stockInput = document.getElementById('inventoryInitialStock');
    if (!nameInput || !priceInput || !stockInput) {
        console.error("Inventory input elements not found.");
        return;
    }
    const name = nameInput.value.trim();
    const price = parseFloat(priceInput.value);
    const initialStock = parseInt(stockInput.value);
    if (!name || isNaN(price) || price <= 0 || isNaN(initialStock) || initialStock < 0) {
        showMessage('Vui lòng nhập đầy đủ và đúng định dạng thông tin sản phẩm (tên, giá > 0, tồn kho >= 0).', 'error');
        return;
    }
    if (currentEditingProductId) {
        const productIndex = products.findIndex(p => p.id === currentEditingProductId);
        if (productIndex !== -1) {
            products[productIndex].name = name;
            products[productIndex].price = price;
            products[productIndex].stock = initialStock;
            showMessage('Cập nhật sản phẩm thành công!', 'success');
        }
    } else {
        const newProduct = {
            id: Date.now().toString(),
            name: name,
            price: price,
            stock: initialStock
        };
        products.push(newProduct);
        showMessage('Thêm sản phẩm thành công!', 'success');
    }
    saveAllData();
    resetInventoryForm();
    renderInventory();
    renderSalesProducts();
    loadImportProductOptions();
}
function editProduct(id) {
    const productToEdit = products.find(p => p.id === id);
    if (productToEdit) {
        const nameInput = document.getElementById('inventoryProductName');
        const priceInput = document.getElementById('inventoryProductPrice');
        const stockInput = document.getElementById('inventoryInitialStock');
        const addUpdateBtn = document.getElementById('addUpdateProductBtn');
        if (nameInput && priceInput && stockInput && addUpdateBtn) {
            nameInput.value = productToEdit.name;
            priceInput.value = productToEdit.price;
            stockInput.value = productToEdit.stock;
            currentEditingProductId = id;
            addUpdateBtn.textContent = 'Cập Nhật Sản Phẩm';
            showMessage(`Đang sửa sản phẩm: "${productToEdit.name}"`, 'info');
        } else {
            console.error("Inventory form elements not found for editing.");
        }
    }
}
function deleteProduct(id) {
    showConfirmationModal('Xác nhận xóa sản phẩm', 'Bạn có chắc chắn muốn xóa sản phẩm này khỏi kho? Hành động này không thể hoàn tác.', () => {
        products = products.filter(product => product.id !== id);
        importHistory = importHistory.filter(record => record.productId !== id);
        salesHistory.forEach(sale => {
            sale.items = sale.items.filter(item => item.productId !== id);
        });
        salesHistory = salesHistory.filter(sale => sale.items.length > 0);
        showMessage('Xóa sản phẩm thành công!', 'success');
        saveAllData();
        renderInventory();
        renderSalesProducts();
        loadImportProductOptions();
        renderImportHistory();
        renderSalesHistory();
        resetInventoryForm();
    });
}
function resetInventoryForm() {
    const nameInput = document.getElementById('inventoryProductName');
    const priceInput = document.getElementById('inventoryProductPrice');
    const stockInput = document.getElementById('inventoryInitialStock');
    const addUpdateBtn = document.getElementById('addUpdateProductBtn');
    if (nameInput && priceInput && stockInput && addUpdateBtn) {
        nameInput.value = '';
        priceInput.value = '';
        stockInput.value = '';
        currentEditingProductId = null;
        addUpdateBtn.textContent = 'Thêm Sản Phẩm Mới';
    } else {
        console.error("Inventory form elements not found for reset.");
    }
}
document.addEventListener('DOMContentLoaded', () => {
    loadAllData();
    showSection('sales');
});
