// Mảng lưu danh sách sản phẩm
let products = [];
// Mảng lưu giỏ hàng hiện tại
let cart = [];
// Mảng lưu lịch sử nhập hàng
let importHistory = [];
// Mảng lưu lịch sử bán hàng
let salesHistory = [];
// Biến lưu id sản phẩm đang chỉnh sửa
let currentEditingProductId = null;

// Hiển thị thông báo lên message box
function showMessage(message, type = 'success') {
    const messageBox = document.getElementById('messageBox');
    const messageText = document.getElementById('messageText');
    if (messageBox && messageText) {
        messageText.textContent = message;
        messageBox.className = 'message-box';
        if (type === 'success') {
            messageBox.classList.add('bg-green-100', 'text-green-800');
        } else if (type === 'error') {
            messageBox.classList.add('bg-red-100', 'text-red-800');
        } else if (type === 'info') {
            messageBox.classList.add('bg-blue-100', 'text-blue-800');
        }
        messageBox.classList.add('show');
        setTimeout(hideMessage, 5000);
    } else {
        console.error("Message box elements not found.");
    }
}
// Ẩn message box sau khi hiển thị
function hideMessage() {
    const messageBox = document.getElementById('messageBox');
    if (messageBox) {
        messageBox.classList.remove('show');
        setTimeout(() => {
            messageBox.className = 'message-box';
        }, 500);
    }
}
// Hiển thị modal xác nhận với tiêu đề, nội dung và hàm xử lý khi xác nhận
function showConfirmationModal(title, message, onConfirm) {
    const modal = document.getElementById('confirmationModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalMessage = document.getElementById('modalMessage');
    const confirmBtn = document.getElementById('modalConfirmBtn');
    const cancelBtn = document.getElementById('modalCancelBtn');
    if (!modal || !modalTitle || !modalMessage || !confirmBtn || !cancelBtn) {
        console.error("Modal elements not found.");
        return;
    }
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    confirmBtn.onclick = null;
    cancelBtn.onclick = null;
    confirmBtn.onclick = () => {
        modal.style.display = 'none';
        onConfirm();
    };
    cancelBtn.onclick = () => {
        modal.style.display = 'none';
    };
    modal.style.display = 'flex';
}
// Đóng/mở vùng nội dung có thể thu gọn (collapsible)
function toggleCollapsible(contentId, iconId) {
    const content = document.getElementById(contentId);
    const icon = document.getElementById(iconId);
    if (content && icon) {
        content.classList.toggle('expanded');
        icon.classList.toggle('rotated');
    }
}
// Hiển thị tab chức năng tương ứng (bán hàng, nhập hàng, tồn kho)
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById('tab' + sectionId.charAt(0).toUpperCase() + sectionId.slice(1)).classList.add('active');
    if (sectionId === 'sales') {
        renderSalesProducts();
        renderCart();
        // Chỉ tải lịch sử đơn hàng nếu đang mở rộng
        const content = document.getElementById('salesHistoryContent');
        if (content && !content.classList.contains('hidden')) {
            loadSalesHistoryOnExpand();
        }
    } else if (sectionId === 'import') {
        loadImportProductOptions();
        renderImportHistory();
    } else if (sectionId === 'inventory') {
        renderInventory();
        resetInventoryForm();
    }
}
// Khởi tạo dữ liệu và hiển thị tab bán hàng khi trang vừa load
document.addEventListener('DOMContentLoaded', () => {
loadAllData().then(() => {
    showSection('sales');
});
});

