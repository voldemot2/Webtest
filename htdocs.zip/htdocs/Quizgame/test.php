<?php
// File test kết nối database và API
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Kết Nối - Quiz Game</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; }
        .test-box { background: white; padding: 20px; margin: 10px 0; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #27ae60; font-weight: bold; }
        .error { color: #e74c3c; font-weight: bold; }
        .info { color: #3498db; font-weight: bold; }
        .result { background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0; }
        pre { background: #2c3e50; color: white; padding: 10px; border-radius: 5px; overflow-x: auto; }
        button { background: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
        button:hover { background: #2980b9; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Test Kết Nối Quiz Game</h1>
        
        <div class="test-box">
            <h2>📊 Kiểm tra cấu hình PHP</h2>
            <div class="result">
                <strong>PHP Version:</strong> <?php echo phpversion(); ?><br>
                <strong>PDO MySQL:</strong> 
                <?php 
                if (extension_loaded('pdo_mysql')) {
                    echo '<span class="success">✓ Có sẵn</span>';
                } else {
                    echo '<span class="error">✗ Chưa cài đặt</span>';
                }
                ?><br>
                <strong>JSON:</strong> 
                <?php 
                if (function_exists('json_encode')) {
                    echo '<span class="success">✓ Có sẵn</span>';
                } else {
                    echo '<span class="error">✗ Chưa cài đặt</span>';
                }
                ?>
            </div>
        </div>

        <div class="test-box">
            <h2>🗄️ Test Kết Nối Database</h2>
            <?php
            try {
                // Include database config
                $config_path = __DIR__ . '/config/database.php';
                if (file_exists($config_path)) {
                    require_once $config_path;
                    $database = new Database();
                    $db = $database->connect();
                    
                    if ($db) {
                        echo '<div class="result success">✓ Kết nối database thành công!</div>';
                        
                        // Test query
                        $stmt = $db->query("SHOW TABLES");
                        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                        
                        echo '<div class="result">';
                        echo '<strong>Danh sách bảng:</strong><br>';
                        if (count($tables) > 0) {
                            foreach ($tables as $table) {
                                echo "- $table<br>";
                            }
                        } else {
                            echo '<span class="error">Không có bảng nào. Vui lòng import database.sql</span>';
                        }
                        echo '</div>';
                        
                    } else {
                        echo '<div class="result error">✗ Không thể kết nối database</div>';
                    }
                } else {
                    echo '<div class="result error">✗ Không tìm thấy file config/database.php</div>';
                }
            } catch (Exception $e) {
                echo '<div class="result error">✗ Lỗi: ' . $e->getMessage() . '</div>';
            }
            ?>
        </div>

        <div class="test-box">
            <h2>📁 Kiểm tra cấu trúc file</h2>
            <div class="result">
                <?php
                $files_to_check = [
                    'index.html',
                    'admin/dashboard.html',
                    'player/join.html', 
                    'host/control.html',
                    'api/quiz.php',
                    'config/database.php',
                    'css/style.css',
                    'js/common.js',
                    'database.sql'
                ];
                
                foreach ($files_to_check as $file) {
                    $path = __DIR__ . '/' . $file;
                    if (file_exists($path)) {
                        echo "✓ <span class='success'>$file</span><br>";
                    } else {
                        echo "✗ <span class='error'>$file (Thiếu)</span><br>";
                    }
                }
                ?>
            </div>
        </div>

        <div class="test-box">
            <h2>🧪 Test API Endpoints</h2>
            <div id="api-tests">
                <button onclick="testAPI()">Chạy Test API</button>
                <div id="api-results"></div>
            </div>
        </div>

        <div class="test-box">
            <h2>📱 Test JavaScript Functions</h2>
            <div id="js-tests">
                <button onclick="testJavaScript()">Test JavaScript</button>
                <div id="js-results"></div>
            </div>
        </div>

        <div class="test-box">
            <h2>🛠️ Hướng dẫn sửa lỗi</h2>
            <div class="result">
                <h4>Nếu không kết nối được database:</h4>
                <ol>
                    <li>Kiểm tra XAMPP/WAMP đã bật MySQL chưa</li>
                    <li>Kiểm tra thông tin trong <code>config/database.php</code></li>
                    <li>Tạo database tên <code>quiz_game</code></li>
                    <li>Import file <code>database.sql</code></li>
                </ol>
                
                <h4>Nếu API không hoạt động:</h4>
                <ol>
                    <li>Kiểm tra Apache đã bật chưa</li>
                    <li>Kiểm tra đường dẫn tương đối</li>
                    <li>Bật mod_rewrite nếu cần</li>
                    <li>Kiểm tra CORS settings</li>
                </ol>
            </div>
        </div>
    </div>

    <script>
        async function testAPI() {
            const resultsDiv = document.getElementById('api-results');
            resultsDiv.innerHTML = '<div class="info">Đang test API...</div>';
            
            const tests = [
                { name: 'GET /api/quiz.php/quizzes', url: 'api/quiz.php/quizzes' },
                { name: 'GET /api/quiz.php/quiz/1', url: 'api/quiz.php/quiz/1' }
            ];
            
            let results = '';
            
            for (let test of tests) {
                try {
                    const response = await fetch(test.url);
                    const data = await response.json();
                    
                    if (response.ok) {
                        results += `<div class="result success">✓ ${test.name}: OK</div>`;
                        results += `<pre>${JSON.stringify(data, null, 2)}</pre>`;
                    } else {
                        results += `<div class="result error">✗ ${test.name}: ${response.status}</div>`;
                    }
                } catch (error) {
                    results += `<div class="result error">✗ ${test.name}: ${error.message}</div>`;
                }
            }
            
            resultsDiv.innerHTML = results;
        }
        
        function testJavaScript() {
            const resultsDiv = document.getElementById('js-results');
            let results = '';
            
            // Test 1: Check if common.js loaded
            if (typeof QuizAPI !== 'undefined') {
                results += '<div class="result success">✓ QuizAPI class loaded</div>';
            } else {
                results += '<div class="result error">✗ QuizAPI class not found</div>';
            }
            
            // Test 2: Check if QuizManager loaded
            if (typeof QuizManager !== 'undefined') {
                results += '<div class="result success">✓ QuizManager class loaded</div>';
            } else {
                results += '<div class="result error">✗ QuizManager class not found</div>';
            }
            
            // Test 3: Check Timer class
            if (typeof Timer !== 'undefined') {
                results += '<div class="result success">✓ Timer class loaded</div>';
            } else {
                results += '<div class="result error">✗ Timer class not found</div>';
            }
            
            // Test 4: Test basic function
            try {
                const testTimer = new Timer(5, null, null);
                results += '<div class="result success">✓ Timer object created successfully</div>';
            } catch (error) {
                results += `<div class="result error">✗ Timer creation failed: ${error.message}</div>`;
            }
            
            resultsDiv.innerHTML = results;
        }
        
        // Auto load common.js for testing
        const script = document.createElement('script');
        script.src = 'js/common.js';
        script.onload = () => {
            console.log('common.js loaded for testing');
        };
        script.onerror = () => {
            console.error('Failed to load common.js');
        };
        document.head.appendChild(script);
    </script>
</body>
</html>
