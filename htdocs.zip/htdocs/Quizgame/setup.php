<?php
// File setup và sửa lỗi tự động
header('Content-Type: text/html; charset=utf-8');

$errors = [];
$fixes = [];
$status = [];

// Kiểm tra và sửa cấu hình database
function checkDatabaseConfig() {
    global $errors, $fixes, $status;
    
    $configPath = __DIR__ . '/config/database.php';
    
    if (!file_exists($configPath)) {
        $errors[] = 'File config/database.php không tồn tại';
        
        // Tạo file config mặc định
        $defaultConfig = '<?php
class Database {
    private $host = \'localhost\';
    private $db_name = \'quiz_game\';
    private $username = \'root\';
    private $password = \'\';
    private $conn;

    public function connect() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, 
                                $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            echo "Connection Error: " . $e->getMessage();
        }
        return $this->conn;
    }
}
?>';
        
        if (!is_dir(dirname($configPath))) {
            mkdir(dirname($configPath), 0755, true);
        }
        
        if (file_put_contents($configPath, $defaultConfig)) {
            $fixes[] = 'Đã tạo file config/database.php mặc định';
        } else {
            $errors[] = 'Không thể tạo file config/database.php';
        }
    } else {
        $status[] = 'File config/database.php đã tồn tại';
    }
}

// Kiểm tra kết nối database
function testDatabaseConnection() {
    global $errors, $fixes, $status;
    
    try {
        require_once __DIR__ . '/config/database.php';
        $database = new Database();
        $db = $database->connect();
        
        if ($db) {
            $status[] = 'Kết nối database thành công';
            
            // Kiểm tra bảng
            $stmt = $db->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $requiredTables = ['quizzes', 'questions', 'players', 'answers', 'game_sessions'];
            $missingTables = array_diff($requiredTables, $tables);
            
            if (!empty($missingTables)) {
                $errors[] = 'Thiếu bảng: ' . implode(', ', $missingTables);
                
                // Auto import database.sql nếu có
                $sqlFile = __DIR__ . '/database.sql';
                if (file_exists($sqlFile)) {
                    $sql = file_get_contents($sqlFile);
                    $statements = explode(';', $sql);
                    
                    try {
                        foreach ($statements as $statement) {
                            $statement = trim($statement);
                            if (!empty($statement)) {
                                $db->exec($statement);
                            }
                        }
                        $fixes[] = 'Đã import database.sql thành công';
                    } catch (Exception $e) {
                        $errors[] = 'Lỗi import database.sql: ' . $e->getMessage();
                    }
                } else {
                    $errors[] = 'File database.sql không tồn tại';
                }
            } else {
                $status[] = 'Tất cả bảng cần thiết đã có';
            }
            
        } else {
            $errors[] = 'Không thể kết nối database';
        }
    } catch (Exception $e) {
        $errors[] = 'Lỗi database: ' . $e->getMessage();
    }
}

// Kiểm tra cấu trúc file
function checkFileStructure() {
    global $errors, $fixes, $status;
    
    $requiredFiles = [
        'index.html',
        'admin/dashboard.html',
        'player/join.html',
        'host/control.html',
        'api/quiz.php',
        'css/style.css',
        'js/common.js'
    ];
    
    foreach ($requiredFiles as $file) {
        $path = __DIR__ . '/' . $file;
        if (file_exists($path)) {
            $status[] = "File $file đã có";
        } else {
            $errors[] = "File $file bị thiếu";
        }
    }
}

// Sửa lỗi API path
function fixAPIPath() {
    global $errors, $fixes, $status;
    
    $jsFile = __DIR__ . '/js/common.js';
    if (file_exists($jsFile)) {
        $content = file_get_contents($jsFile);
        
        // Kiểm tra API base URL
        if (strpos($content, "API_BASE_URL = 'api/quiz.php'") !== false) {
            $status[] = 'API path đã đúng';
        } else {
            // Sửa API path
            $content = preg_replace(
                "/const API_BASE_URL = '[^']*';/", 
                "const API_BASE_URL = 'api/quiz.php';", 
                $content
            );
            
            if (file_put_contents($jsFile, $content)) {
                $fixes[] = 'Đã sửa API path trong common.js';
            }
        }
    }
}

// Tạo .htaccess nếu cần
function createHtaccess() {
    global $errors, $fixes, $status;
    
    $htaccessPath = __DIR__ . '/.htaccess';
    if (!file_exists($htaccessPath)) {
        $htaccessContent = 'RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^api/(.*)$ api/quiz.php/$1 [QSA,L]

# CORS headers
Header always set Access-Control-Allow-Origin "*"
Header always set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
Header always set Access-Control-Allow-Headers "Content-Type"
';
        
        if (file_put_contents($htaccessPath, $htaccessContent)) {
            $fixes[] = 'Đã tạo file .htaccess';
        }
    } else {
        $status[] = 'File .htaccess đã có';
    }
}

// Chạy tất cả kiểm tra
checkDatabaseConfig();
testDatabaseConnection();
checkFileStructure();
fixAPIPath();
createHtaccess();

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup & Fix - Quiz Game</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; }
        .box { background: white; padding: 20px; margin: 10px 0; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #27ae60; background: #d4edda; padding: 10px; border-radius: 5px; margin: 5px 0; }
        .error { color: #e74c3c; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 5px 0; }
        .info { color: #3498db; background: #d1ecf1; padding: 10px; border-radius: 5px; margin: 5px 0; }
        .button { background: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; margin: 5px; }
        .button:hover { background: #2980b9; }
        .button.success { background: #27ae60; }
        .button.danger { background: #e74c3c; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Setup & Fix Quiz Game</h1>
        
        <div class="box">
            <h2>📊 Tình trạng hệ thống</h2>
            
            <?php if (!empty($status)): ?>
                <h3>✅ Trạng thái OK:</h3>
                <?php foreach ($status as $item): ?>
                    <div class="info"><?php echo $item; ?></div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <?php if (!empty($fixes)): ?>
                <h3>🔧 Đã sửa:</h3>
                <?php foreach ($fixes as $item): ?>
                    <div class="success"><?php echo $item; ?></div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <h3>❌ Lỗi cần khắc phục:</h3>
                <?php foreach ($errors as $item): ?>
                    <div class="error"><?php echo $item; ?></div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="box">
            <h2>🛠️ Hành động</h2>
            <a href="test.php" class="button">🧪 Chạy Test Toàn Diện</a>
            <a href="test-js.html" class="button">🔍 Test JavaScript</a>
            <a href="api/test.php" class="button">📡 Test API Trực Tiếp</a>
            <a href="index.html" class="button success">🚀 Vào Ứng Dụng</a>
        </div>
        
        <div class="box">
            <h2>📋 Hướng dẫn thủ công</h2>
            
            <h3>1. Nếu vẫn lỗi database:</h3>
            <div class="info">
                - Mở phpMyAdmin<br>
                - Tạo database tên "quiz_game"<br>
                - Import file database.sql<br>
                - Kiểm tra user/password trong config/database.php
            </div>
            
            <h3>2. Nếu API không hoạt động:</h3>
            <div class="info">
                - Kiểm tra Apache đang chạy<br>
                - Kiểm tra mod_rewrite enabled<br>
                - Thử truy cập trực tiếp: api/test.php<br>
                - Kiểm tra console browser (F12) xem lỗi gì
            </div>
            
            <h3>3. Nếu JavaScript error:</h3>
            <div class="info">
                - Mở Developer Tools (F12)<br>
                - Kiểm tra Console tab<br>
                - Kiểm tra Network tab xem API calls<br>
                - Đảm bảo file js/common.js load được
            </div>
        </div>
        
        <div class="box">
            <h2>🔄 Refresh Setup</h2>
            <a href="setup.php" class="button">🔄 Chạy lại Setup</a>
            <button onclick="clearBrowserCache()" class="button">🗑️ Clear Cache</button>
        </div>
    </div>
    
    <script>
        function clearBrowserCache() {
            if ('serviceWorker' in navigator) {
                navigator.serviceWorker.getRegistrations().then(function(registrations) {
                    for(let registration of registrations) {
                        registration.unregister();
                    }
                });
            }
            
            if ('caches' in window) {
                caches.keys().then(function(names) {
                    for (let name of names) {
                        caches.delete(name);
                    }
                });
            }
            
            localStorage.clear();
            sessionStorage.clear();
            
            alert('Cache đã được xóa! Vui lòng refresh trang.');
            window.location.reload(true);
        }
        
        // Auto refresh sau 2 giây nếu có fixes
        <?php if (!empty($fixes)): ?>
        setTimeout(() => {
            if (confirm('Đã có sửa đổi. Bạn có muốn chạy lại test không?')) {
                window.location.href = 'test.php';
            }
        }, 2000);
        <?php endif; ?>
    </script>
</body>
</html>
