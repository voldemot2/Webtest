<?php
// Test API trực tiếp với error handling tốt hơn
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Clean any previous output
ob_clean();

$response = [
    'status' => 'success',
    'message' => 'API Test Working',
    'timestamp' => date('Y-m-d H:i:s'),
    'php_version' => phpversion(),
    'server_info' => [
        'REQUEST_METHOD' => $_SERVER['REQUEST_METHOD'],
        'REQUEST_URI' => $_SERVER['REQUEST_URI'] ?? '',
        'PATH_INFO' => $_SERVER['PATH_INFO'] ?? 'Not set',
        'QUERY_STRING' => $_SERVER['QUERY_STRING'] ?? '',
        'DOCUMENT_ROOT' => $_SERVER['DOCUMENT_ROOT'] ?? '',
        'SCRIPT_FILENAME' => $_SERVER['SCRIPT_FILENAME'] ?? ''
    ]
];

// Test database connection
try {
    $config_path = __DIR__ . '/../config/database.php';
    if (!file_exists($config_path)) {
        $response['database'] = [
            'status' => 'error',
            'message' => 'Config file not found at: ' . $config_path
        ];
    } else {
        require_once $config_path;
        
        if (!class_exists('Database')) {
            $response['database'] = [
                'status' => 'error',
                'message' => 'Database class not found in config file'
            ];
        } else {
            $database = new Database();
            $db = $database->connect();
            
            if ($db) {
                // Test basic query
                $stmt = $db->query("SHOW TABLES");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                $response['database'] = [
                    'status' => 'connected',
                    'tables' => $tables,
                    'table_count' => count($tables)
                ];
                
                // Test quiz table specifically
                if (in_array('quizzes', $tables)) {
                    $stmt = $db->query("SELECT COUNT(*) as count FROM quizzes");
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    $response['database']['quiz_count'] = $result['count'];
                } else {
                    $response['database']['warning'] = 'quizzes table not found';
                }
            } else {
                $response['database'] = [
                    'status' => 'error',
                    'message' => 'Could not connect to database'
                ];
            }
        }
    }
} catch (Exception $e) {
    $response['database'] = [
        'status' => 'error',
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ];
}

// Test file structure
$response['files'] = [];
$files_to_check = ['../index.html', '../js/common.js', '../css/style.css', 'quiz.php'];
foreach ($files_to_check as $file) {
    $response['files'][$file] = file_exists(__DIR__ . '/' . $file);
}

echo json_encode($response, JSON_PRETTY_PRINT);
exit;
