<?php
// Prevent any output before JSON
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in JSON output

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Clean any previous output
ob_clean();

// Check if config file exists
$config_path = __DIR__ . '/../config/database.php';
if (!file_exists($config_path)) {
    echo json_encode(['error' => 'Database config file not found']);
    exit;
}

require_once $config_path;

$database = new Database();
$db = $database->connect();

// Check database connection
if (!$db) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$path_info = $_SERVER['PATH_INFO'] ?? '';
$request = explode('/', trim($path_info, '/'));

// Handle empty request
if (empty($request[0])) {
    echo json_encode(['error' => 'No endpoint specified']);
    exit;
}

try {
    switch ($method) {
    case 'GET':
        if ($request[0] == 'quizzes') {
            getQuizzes($db);
        } elseif ($request[0] == 'quiz' && isset($request[1])) {
            getQuiz($db, $request[1]);
        } elseif ($request[0] == 'questions' && isset($request[1])) {
            getQuestions($db, $request[1]);
        } elseif ($request[0] == 'players' && isset($request[1])) {
            getPlayers($db, $request[1]);
        } elseif ($request[0] == 'stats' && isset($request[1])) {
            getStats($db, $request[1]);
        }
        break;
    
    case 'POST':
        if ($request[0] == 'quiz') {
            createQuiz($db);
        } elseif ($request[0] == 'question') {
            createQuestion($db);
        } elseif ($request[0] == 'join') {
            joinGame($db);
        } elseif ($request[0] == 'answer') {
            submitAnswer($db);
        } elseif ($request[0] == 'start') {
            startGame($db);
        }
        break;
    
    case 'PUT':
        if ($request[0] == 'quiz' && isset($request[1])) {
            updateQuiz($db, $request[1]);
        } elseif ($request[0] == 'game' && isset($request[1])) {
            updateGameState($db, $request[1]);
        }
        break;
    
        case 'DELETE':
            if ($request[0] == 'quiz' && isset($request[1])) {
                deleteQuiz($db, $request[1]);
            } else {
                echo json_encode(['error' => 'Invalid DELETE endpoint']);
            }
            break;
            
        default:
            echo json_encode(['error' => 'Method not allowed']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}function getQuizzes($db) {
    try {
        $query = "SELECT * FROM quizzes ORDER BY created_at DESC";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($result ?: []);
    } catch (Exception $e) {
        echo json_encode(['error' => 'Failed to get quizzes: ' . $e->getMessage()]);
    }
}

function getQuiz($db, $id) {
    try {
        $query = "SELECT * FROM quizzes WHERE id = ? OR pin = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$id, $id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($result ?: ['error' => 'Quiz not found']);
    } catch (Exception $e) {
        echo json_encode(['error' => 'Failed to get quiz: ' . $e->getMessage()]);
    }
}

function getQuestions($db, $quiz_id) {
    $query = "SELECT * FROM questions WHERE quiz_id = ? ORDER BY question_order";
    $stmt = $db->prepare($query);
    $stmt->execute([$quiz_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

function getPlayers($db, $quiz_id) {
    $query = "SELECT * FROM players WHERE quiz_id = ? ORDER BY score DESC";
    $stmt = $db->prepare($query);
    $stmt->execute([$quiz_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

function getStats($db, $quiz_id) {
    $query = "SELECT q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_answer,
                     COUNT(a.id) as total_answers,
                     SUM(CASE WHEN a.selected_answer = 'a' THEN 1 ELSE 0 END) as option_a_count,
                     SUM(CASE WHEN a.selected_answer = 'b' THEN 1 ELSE 0 END) as option_b_count,
                     SUM(CASE WHEN a.selected_answer = 'c' THEN 1 ELSE 0 END) as option_c_count,
                     SUM(CASE WHEN a.selected_answer = 'd' THEN 1 ELSE 0 END) as option_d_count,
                     SUM(CASE WHEN a.is_correct = 1 THEN 1 ELSE 0 END) as correct_count
              FROM questions q
              LEFT JOIN answers a ON q.id = a.question_id
              WHERE q.quiz_id = ?
              GROUP BY q.id
              ORDER BY q.question_order";
    $stmt = $db->prepare($query);
    $stmt->execute([$quiz_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

function createQuiz($db) {
    $data = json_decode(file_get_contents("php://input"));
    $pin = sprintf("%06d", mt_rand(1, 999999));
    
    $query = "INSERT INTO quizzes (title, description, pin) VALUES (?, ?, ?)";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([$data->title, $data->description, $pin]);
    
    if ($result) {
        echo json_encode(['success' => true, 'id' => $db->lastInsertId(), 'pin' => $pin]);
    } else {
        echo json_encode(['success' => false]);
    }
}

function createQuestion($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    $query = "INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer, time_limit, question_order) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([
        $data->quiz_id, $data->question_text, $data->option_a, $data->option_b, 
        $data->option_c, $data->option_d, $data->correct_answer, $data->time_limit, $data->question_order
    ]);
    
    echo json_encode(['success' => $result]);
}

function joinGame($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    // Kiểm tra PIN có tồn tại không
    $query = "SELECT id FROM quizzes WHERE pin = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$data->pin]);
    $quiz = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($quiz) {
        // Thêm người chơi
        $query = "INSERT INTO players (quiz_id, name) VALUES (?, ?)";
        $stmt = $db->prepare($query);
        $result = $stmt->execute([$quiz['id'], $data->name]);
        
        if ($result) {
            echo json_encode(['success' => true, 'player_id' => $db->lastInsertId(), 'quiz_id' => $quiz['id']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Không thể tham gia']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'PIN không đúng']);
    }
}

function submitAnswer($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    // Lấy thông tin câu hỏi để kiểm tra đáp án
    $query = "SELECT correct_answer FROM questions WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$data->question_id]);
    $question = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $is_correct = ($data->selected_answer == $question['correct_answer']);
    
    // Lưu câu trả lời
    $query = "INSERT INTO answers (player_id, question_id, selected_answer, is_correct, response_time) 
              VALUES (?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([
        $data->player_id, $data->question_id, $data->selected_answer, $is_correct, $data->response_time
    ]);
    
    // Cập nhật điểm nếu đúng
    if ($is_correct) {
        $points = max(1000 - ($data->response_time * 10), 100); // Điểm giảm theo thời gian
        $query = "UPDATE players SET score = score + ? WHERE id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$points, $data->player_id]);
    }
    
    echo json_encode(['success' => $result, 'is_correct' => $is_correct]);
}

function startGame($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    $query = "UPDATE quizzes SET is_active = 1, current_question = 1 WHERE id = ?";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([$data->quiz_id]);
    
    echo json_encode(['success' => $result]);
}

function updateGameState($db, $quiz_id) {
    $data = json_decode(file_get_contents("php://input"));
    
    $query = "UPDATE quizzes SET current_question = ? WHERE id = ?";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([$data->current_question, $quiz_id]);
    
    echo json_encode(['success' => $result]);
}

function updateQuiz($db, $id) {
    $data = json_decode(file_get_contents("php://input"));
    
    $query = "UPDATE quizzes SET title = ?, description = ? WHERE id = ?";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([$data->title, $data->description, $id]);
    
    echo json_encode(['success' => $result]);
}

function deleteQuiz($db, $id) {
    $query = "DELETE FROM quizzes WHERE id = ?";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([$id]);
    
    echo json_encode(['success' => $result]);
}
?>
