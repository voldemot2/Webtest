// API Base URL - Tự động detect đường dẫn đúng
function getAPIBaseURL() {
    const path = window.location.pathname;
    const segments = path.split('/');
    
    // Tìm thư mục gốc của project
    let basePath = '';
    if (path.includes('/admin/')) {
        basePath = '../api/quiz.php';
    } else if (path.includes('/player/')) {
        basePath = '../api/quiz.php';
    } else if (path.includes('/host/')) {
        basePath = '../api/quiz.php';
    } else {
        basePath = 'api/quiz.php';
    }
    
    return basePath;
}

const API_BASE_URL = window.API_BASE_URL_OVERRIDE || getAPIBaseURL();

// Debug: Log API base URL
console.log('API Base URL detected:', API_BASE_URL);
console.log('Current location:', window.location.href);
console.log('Override used:', !!window.API_BASE_URL_OVERRIDE);

// Utility functions
class QuizAPI {
    static async request(endpoint, options = {}) {
        const url = `${API_BASE_URL}/${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
            },
            ...options
        };
        
        try {
            const response = await fetch(url, config);
            const text = await response.text();
            
            // Debug log
            console.log(`API Request: ${url}`, config);
            console.log(`API Response: ${response.status}`, text);
            
            // Nếu gặp 404, thử đường dẫn thay thế
            if (response.status === 404 && !url.includes('fallback')) {
                console.log('404 detected, trying fallback URL...');
                const fallbackURL = url.replace('../api/quiz.php', 'api/quiz.php').replace('api/quiz.php', '../api/quiz.php');
                return await this.request(endpoint + '?fallback=true', {
                    ...options,
                    headers: {
                        ...config.headers,
                        'X-Fallback-URL': fallbackURL
                    }
                });
            }
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${text}`);
            }
            
            try {
                return JSON.parse(text);
            } catch (jsonError) {
                console.error('JSON Parse Error:', jsonError);
                console.error('Raw response:', text);
                throw new Error(`Invalid JSON response: ${text.substring(0, 100)}...`);
            }
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
    
    static async get(endpoint) {
        return this.request(endpoint);
    }
    
    static async post(endpoint, data) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }
    
    static async put(endpoint, data) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }
    
    static async delete(endpoint) {
        return this.request(endpoint, {
            method: 'DELETE'
        });
    }
}

// Quiz management functions
class QuizManager {
    static async getAllQuizzes() {
        return await QuizAPI.get('quizzes');
    }
    
    static async getQuiz(id) {
        return await QuizAPI.get(`quiz/${id}`);
    }
    
    static async getQuestions(quizId) {
        return await QuizAPI.get(`questions/${quizId}`);
    }
    
    static async getPlayers(quizId) {
        return await QuizAPI.get(`players/${quizId}`);
    }
    
    static async getStats(quizId) {
        return await QuizAPI.get(`stats/${quizId}`);
    }
    
    static async createQuiz(data) {
        return await QuizAPI.post('quiz', data);
    }
    
    static async createQuestion(data) {
        return await QuizAPI.post('question', data);
    }
    
    static async joinGame(pin, name) {
        return await QuizAPI.post('join', { pin, name });
    }
    
    static async submitAnswer(data) {
        return await QuizAPI.post('answer', data);
    }
    
    static async startGame(quizId) {
        return await QuizAPI.post('start', { quiz_id: quizId });
    }
    
    static async updateGameState(quizId, currentQuestion) {
        return await QuizAPI.put(`game/${quizId}`, { current_question: currentQuestion });
    }
    
    static async updateQuiz(id, data) {
        return await QuizAPI.put(`quiz/${id}`, data);
    }
    
    static async deleteQuiz(id) {
        return await QuizAPI.delete(`quiz/${id}`);
    }
}

// Timer class
class Timer {
    constructor(duration, onTick, onComplete) {
        this.duration = duration;
        this.timeLeft = duration;
        this.onTick = onTick;
        this.onComplete = onComplete;
        this.interval = null;
    }
    
    start() {
        this.interval = setInterval(() => {
            this.timeLeft--;
            if (this.onTick) this.onTick(this.timeLeft);
            
            if (this.timeLeft <= 0) {
                this.stop();
                if (this.onComplete) this.onComplete();
            }
        }, 1000);
    }
    
    stop() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }
    
    reset() {
        this.stop();
        this.timeLeft = this.duration;
    }
}

// Utility functions
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} fade-in`;
    alertDiv.textContent = message;
    
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    document.body.insertBefore(alertDiv, document.body.firstChild);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

function showSpinner() {
    const spinner = document.createElement('div');
    spinner.className = 'spinner';
    spinner.id = 'loading-spinner';
    document.body.appendChild(spinner);
}

function hideSpinner() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) spinner.remove();
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// Local storage helpers
function saveToStorage(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

function getFromStorage(key) {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
}

function removeFromStorage(key) {
    localStorage.removeItem(key);
}

// Sound effects (optional)
class SoundManager {
    static playCorrect() {
        // Placeholder for correct answer sound
        console.log('🎵 Correct answer sound');
    }
    
    static playIncorrect() {
        // Placeholder for incorrect answer sound
        console.log('🎵 Incorrect answer sound');
    }
    
    static playTick() {
        // Placeholder for timer tick sound
        console.log('🎵 Timer tick sound');
    }
    
    static playGameStart() {
        // Placeholder for game start sound
        console.log('🎵 Game start sound');
    }
    
    static playGameEnd() {
        // Placeholder for game end sound
        console.log('🎵 Game end sound');
    }
}

// Animation helpers
function animateElement(element, animationClass) {
    element.classList.add(animationClass);
    element.addEventListener('animationend', () => {
        element.classList.remove(animationClass);
    }, { once: true });
}

function countUp(element, start, end, duration = 1000) {
    const range = end - start;
    const increment = range / (duration / 50);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = Math.round(current);
    }, 50);
}

// WebSocket connection for real-time updates (optional enhancement)
class RealtimeConnection {
    constructor() {
        this.ws = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
    }
    
    connect() {
        // Placeholder for WebSocket connection
        console.log('🔌 WebSocket connection (not implemented in this demo)');
    }
    
    disconnect() {
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
    }
    
    send(data) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(data));
        }
    }
}

// Export for use in other files
window.QuizAPI = QuizAPI;
window.QuizManager = QuizManager;
window.Timer = Timer;
window.SoundManager = SoundManager;
window.RealtimeConnection = RealtimeConnection;
