-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS quiz_game;
USE quiz_game;

-- Bảng quiz
CREATE TABLE IF NOT EXISTS quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    pin VARCHAR(6) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT FALSE,
    current_question INT DEFAULT 0
);

-- Bảng câu hỏi
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT,
    question_text TEXT NOT NULL,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_answer CHAR(1) NOT NULL,
    time_limit INT DEFAULT 30,
    question_order INT,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

-- Bảng người chơi
CREATE TABLE IF NOT EXISTS players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT,
    name VARCHAR(100) NOT NULL,
    score INT DEFAULT 0,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

-- Bảng câu trả lời
CREATE TABLE IF NOT EXISTS answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    player_id INT,
    question_id INT,
    selected_answer CHAR(1),
    is_correct BOOLEAN,
    answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    response_time INT,
    FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- Bảng phiên game
CREATE TABLE IF NOT EXISTS game_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT,
    status ENUM('waiting', 'active', 'finished') DEFAULT 'waiting',
    current_question_id INT,
    started_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

-- Thêm dữ liệu mẫu
INSERT INTO quizzes (title, description, pin) VALUES 
('Quiz Kiến thức tổng quát', 'Câu hỏi về kiến thức tổng quát', '123456'),
('Quiz Lịch sử Việt Nam', 'Câu hỏi về lịch sử Việt Nam', '234567');

INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer, question_order) VALUES
(1, 'Thủ đô của Việt Nam là gì?', 'Hà Nội', 'TP.HCM', 'Đà Nẵng', 'Huế', 'a', 1),
(1, 'Sông dài nhất Việt Nam là sông nào?', 'Sông Hồng', 'Sông Mê Kông', 'Sông Đồng Nai', 'Sông Cầu', 'b', 2),
(1, 'Việt Nam có bao nhiêu tỉnh thành?', '63', '64', '65', '66', 'a', 3),
(2, 'Việt Nam tuyên bố độc lập vào năm nào?', '1945', '1946', '1954', '1975', 'a', 1),
(2, 'Ai là người sáng lập ra Đảng Cộng sản Việt Nam?', 'Hồ Chí Minh', 'Võ Nguyên Giáp', 'Phạm Văn Đồng', 'Lê Duẩn', 'a', 2);
