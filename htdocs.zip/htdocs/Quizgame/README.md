# Quiz Game - Giống Kahoot

Một ứng dụng Quiz Game hoàn chỉnh được xây dựng bằng HTML, JavaScript và PHP, có cấu trúc giống Kahoot với 3 phần chính:

## 🎯 Tính năng chính

### 📊 Admin Dashboard (Quản lý)
- Tạo quiz mới với tiêu đề và mô tả
- Thêm câu hỏi với 4 lựa chọn A, B, C, D
- Quản lý danh sách quiz (xem, chỉnh sửa, xóa)
- Xem thống kê tổng quan
- Xuất kết quả game

### 🎤 Host Control (Quản trò)
- Chọn quiz để host
- Điều khiển game (bắt đầu, câu hỏi tiếp, kết thúc)
- Hiển thị câu hỏi và đếm ngược thời gian
- Xem thống kê trực tiếp (ai chọn đáp án gì)
- Quản lý danh sách người chơi
- Hiển thị bảng xếp hạng

### 🎮 Player Interface (Người chơi)
- Tham gia game bằng PIN
- Trả lời câu hỏi trong thời gian giới hạn
- Xem điểm số trực tiếp
- Xem kết quả và bảng xếp hạng cuối cùng

## 🚀 Cài đặt

### Yêu cầu hệ thống
- Web server (Apache/Nginx)
- PHP 7.4+ với PDO MySQL
- MySQL 5.7+ hoặc MariaDB
- Trình duyệt web hiện đại

### Bước 1: Cài đặt cơ sở dữ liệu
1. Tạo database MySQL:
```sql
CREATE DATABASE quiz_game;
```

2. Import file `database.sql` để tạo bảng và dữ liệu mẫu:
```bash
mysql -u username -p quiz_game < database.sql
```

### Bước 0: Test & Debug (QUAN TRỌNG!)
**Nếu gặp lỗi, chạy các file test này trước:**

1. **Setup tự động**: `http://localhost/Quiz-game/setup.php`
   - Tự động kiểm tra và sửa cấu hình
   - Tạo file thiếu, import database
   
2. **Test toàn diện**: `http://localhost/Quiz-game/test.php`
   - Kiểm tra PHP, database, file structure
   - Test API endpoints
   
3. **Test JavaScript**: `http://localhost/Quiz-game/test-js.html`
   - Kiểm tra frontend functions
   - Test API calls từ browser
   
4. **Test API trực tiếp**: `http://localhost/Quiz-game/api/test.php`
   - Kiểm tra backend API

### Bước 2: Cấu hình kết nối database
Chỉnh sửa file `config/database.php`:
```php
private $host = 'localhost';
private $db_name = 'quiz_game';
private $username = 'your_username';
private $password = 'your_password';
```

### Bước 3: Cài đặt web server

#### Với XAMPP:
1. Copy thư mục project vào `htdocs/`
2. Khởi động Apache và MySQL
3. Truy cập `http://localhost/Quiz-game/`

#### Với WAMP:
1. Copy thư mục project vào `www/`
2. Khởi động WAMP
3. Truy cập `http://localhost/Quiz-game/`

### Bước 4: Kiểm tra hoạt động
1. Truy cập trang chủ: `http://localhost/Quiz-game/`
2. Vào Admin để tạo quiz: `http://localhost/Quiz-game/admin/dashboard.html`
3. Host quiz: `http://localhost/Quiz-game/host/control.html`
4. Tham gia game: `http://localhost/Quiz-game/player/join.html`

## 📁 Cấu trúc thư mục

```
Quiz game/
│
├── index.html              # Trang chủ
├── database.sql           # Script tạo cơ sở dữ liệu
│
├── admin/                 # Phần quản lý
│   └── dashboard.html     # Dashboard admin
│
├── player/                # Phần người chơi
│   └── join.html         # Trang tham gia game
│
├── host/                  # Phần quản trò
│   └── control.html      # Bảng điều khiển host
│
├── api/                   # Backend API
│   └── quiz.php          # API endpoints
│
├── config/                # Cấu hình
│   └── database.php      # Kết nối database
│
├── css/                   # Stylesheets
│   └── style.css         # CSS chính
│
├── js/                    # JavaScript
│   └── common.js         # Functions chung
│
└── README.md             # Hướng dẫn này
```

## 🎮 Hướng dẫn sử dụng

### Cho Admin:
1. Truy cập Admin Dashboard
2. Tạo quiz mới với tiêu đề và mô tả
3. Thêm câu hỏi với 4 lựa chọn
4. Ghi nhớ PIN để chia sẻ với người chơi

### Cho Host:
1. Chọn quiz muốn host
2. Chia sẻ PIN với người chơi
3. Chờ người chơi tham gia
4. Bắt đầu game và điều khiển từng câu hỏi
5. Xem thống kê trực tiếp và kết quả cuối

### Cho Player:
1. Nhập tên và PIN game
2. Chờ host bắt đầu game
3. Trả lời câu hỏi trong thời gian giới hạn
4. Xem điểm số và thứ hạng

## 🛠 API Endpoints

### GET Requests:
- `GET /api/quiz.php/quizzes` - Lấy danh sách quiz
- `GET /api/quiz.php/quiz/{id}` - Lấy thông tin quiz
- `GET /api/quiz.php/questions/{quiz_id}` - Lấy câu hỏi của quiz
- `GET /api/quiz.php/players/{quiz_id}` - Lấy danh sách người chơi
- `GET /api/quiz.php/stats/{quiz_id}` - Lấy thống kê quiz

### POST Requests:
- `POST /api/quiz.php/quiz` - Tạo quiz mới
- `POST /api/quiz.php/question` - Thêm câu hỏi
- `POST /api/quiz.php/join` - Tham gia game
- `POST /api/quiz.php/answer` - Gửi câu trả lời
- `POST /api/quiz.php/start` - Bắt đầu game

### PUT Requests:
- `PUT /api/quiz.php/quiz/{id}` - Cập nhật quiz
- `PUT /api/quiz.php/game/{id}` - Cập nhật trạng thái game

### DELETE Requests:
- `DELETE /api/quiz.php/quiz/{id}` - Xóa quiz

## 🎨 Tính năng nổi bật

- **Giao diện đẹp**: Thiết kế hiện đại với gradient và hiệu ứng
- **Responsive**: Hoạt động tốt trên mọi thiết bị
- **Real-time**: Cập nhật trực tiếp thông tin game
- **Timer**: Đếm ngược thời gian cho mỗi câu hỏi
- **Scoring**: Hệ thống tính điểm dựa trên độ chính xác và tốc độ
- **Statistics**: Thống kê chi tiết cho host
- **Export**: Xuất kết quả ra file CSV

## 🔧 Tùy chỉnh

### Thay đổi thời gian câu hỏi:
Trong admin dashboard, bạn có thể đặt thời gian cho mỗi câu hỏi từ 5-120 giây.

### Tùy chỉnh giao diện:
Chỉnh sửa file `css/style.css` để thay đổi màu sắc, font chữ, layout.

### Thêm âm thanh:
Cập nhật class `SoundManager` trong `js/common.js` để thêm file âm thanh.

## 🐛 Xử lý lỗi

### ⚡ Quick Fix:
**Chạy ngay:** `http://localhost/Quiz-game/setup.php` - Tự động sửa hầu hết lỗi!

### Lỗi "Không thể tải dữ liệu dashboard":
1. **Chạy test**: `http://localhost/Quiz-game/test.php`
2. **Kiểm tra Console**: F12 → Console tab xem lỗi JavaScript
3. **Kiểm tra Network**: F12 → Network tab xem API calls
4. **Kiểm tra đường dẫn**: Đảm bảo đúng thư mục `htdocs/Quiz-game/`

### Lỗi kết nối database:
- Kiểm tra XAMPP/WAMP đã bật MySQL chưa
- Kiểm tra thông tin trong `config/database.php`
- Tạo database tên `quiz_game`
- Import file `database.sql`
- **Auto fix**: Chạy `setup.php` để sửa tự động

### Lỗi 404 API:
- Kiểm tra Apache đã bật chưa
- Kiểm tra URL: `http://localhost/Quiz-game/api/test.php`
- Bật mod_rewrite nếu cần
- **Auto fix**: `setup.php` sẽ tạo .htaccess

### Lỗi CORS:
```javascript
// Nếu thấy lỗi CORS trong Console
// Chạy setup.php để tạo .htaccess với CORS headers
```

### Lỗi JavaScript "QuizAPI not defined":
- Kiểm tra file `js/common.js` có load được không
- Mở `test-js.html` để test JavaScript
- Kiểm tra đường dẫn relative paths

### Game không sync:
- Kiểm tra kết nối internet
- Tăng tần số polling nếu cần
- Kiểm tra API hoạt động: `api/test.php`

## 📱 Tương thích trình duyệt

- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+
- ✅ Mobile browsers

## 🤝 Đóng góp

1. Fork project
2. Tạo feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📄 License

MIT License - xem file LICENSE để biết thêm chi tiết.

## 👨‍💻 Tác giả

Được phát triển với ❤️ để tạo ra trải nghiệm học tập thú vị như Kahoot.

---

**Chúc bạn có những giờ học vui vẻ! 🎉**
