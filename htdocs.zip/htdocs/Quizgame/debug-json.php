<?php
// Debug JSON response issues
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Debug JSON Response</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .debug-box { background: white; padding: 20px; margin: 10px 0; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 5px 0; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 5px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 5px 0; }
        pre { background: #2c3e50; color: white; padding: 10px; border-radius: 5px; overflow-x: auto; font-size: 12px; }
        button { background: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
    </style>
</head>
<body>
    <h1>🔍 Debug JSON Response Issues</h1>
    
    <div class="debug-box">
        <h2>API Response Raw Test</h2>
        <button onclick="testRawAPI()">Test Raw API Response</button>
        <div id="raw-results"></div>
    </div>
    
    <div class="debug-box">
        <h2>PHP Error Check</h2>
        <?php
        // Check for PHP errors in API file
        $api_file = __DIR__ . '/api/quiz.php';
        if (file_exists($api_file)) {
            echo '<div class="success">✓ API file exists</div>';
            
            // Check syntax
            $output = [];
            $return_code = 0;
            exec("php -l \"$api_file\" 2>&1", $output, $return_code);
            
            if ($return_code === 0) {
                echo '<div class="success">✓ PHP syntax is valid</div>';
            } else {
                echo '<div class="error">✗ PHP syntax error:</div>';
                echo '<pre>' . htmlspecialchars(implode("\n", $output)) . '</pre>';
            }
        } else {
            echo '<div class="error">✗ API file not found</div>';
        }
        
        // Check config file
        $config_file = __DIR__ . '/config/database.php';
        if (file_exists($config_file)) {
            echo '<div class="success">✓ Config file exists</div>';
            
            // Test require
            ob_start();
            try {
                require_once $config_file;
                if (class_exists('Database')) {
                    echo '<div class="success">✓ Database class loaded</div>';
                } else {
                    echo '<div class="error">✗ Database class not found</div>';
                }
            } catch (Exception $e) {
                echo '<div class="error">✗ Config error: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
            $output = ob_get_clean();
            
            if ($output) {
                echo '<div class="warning">Warning: Output from config file:</div>';
                echo '<pre>' . htmlspecialchars($output) . '</pre>';
            }
        } else {
            echo '<div class="error">✗ Config file not found</div>';
        }
        ?>
    </div>
    
    <div class="debug-box">
        <h2>Server Environment</h2>
        <pre><?php
        $env_info = [
            'PHP Version' => phpversion(),
            'Extensions' => get_loaded_extensions(),
            'Error Reporting' => error_reporting(),
            'Display Errors' => ini_get('display_errors'),
            'Output Buffering' => ini_get('output_buffering'),
            'Document Root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Not set',
            'Script Name' => $_SERVER['SCRIPT_NAME'] ?? 'Not set',
            'Request URI' => $_SERVER['REQUEST_URI'] ?? 'Not set'
        ];
        echo json_encode($env_info, JSON_PRETTY_PRINT);
        ?></pre>
    </div>
    
    <div class="debug-box">
        <h2>File Permissions</h2>
        <?php
        $files_to_check = [
            'api/quiz.php',
            'config/database.php', 
            'js/common.js',
            'index.html'
        ];
        
        foreach ($files_to_check as $file) {
            $path = __DIR__ . '/' . $file;
            if (file_exists($path)) {
                $perms = fileperms($path);
                $perms_string = substr(sprintf('%o', $perms), -4);
                echo "<div class='success'>✓ $file: $perms_string</div>";
            } else {
                echo "<div class='error'>✗ $file: Not found</div>";
            }
        }
        ?>
    </div>
    
    <script>
        async function testRawAPI() {
            const resultsDiv = document.getElementById('raw-results');
            resultsDiv.innerHTML = '<div style="color: blue;">Testing...</div>';
            
            const endpoints = [
                'api/test.php',
                'api/quiz.php/quizzes'
            ];
            
            let results = '';
            
            for (let endpoint of endpoints) {
                try {
                    const response = await fetch(endpoint);
                    const text = await response.text();
                    
                    results += `<h3>${endpoint}</h3>`;
                    results += `<div><strong>Status:</strong> ${response.status}</div>`;
                    results += `<div><strong>Content-Type:</strong> ${response.headers.get('content-type')}</div>`;
                    results += `<div><strong>Response Length:</strong> ${text.length}</div>`;
                    
                    // Show first and last 100 chars
                    results += `<div><strong>First 100 chars:</strong></div>`;
                    results += `<pre>${text.substring(0, 100)}</pre>`;
                    
                    if (text.length > 200) {
                        results += `<div><strong>Last 100 chars:</strong></div>`;
                        results += `<pre>${text.substring(text.length - 100)}</pre>`;
                    }
                    
                    // Try to parse JSON
                    try {
                        const data = JSON.parse(text);
                        results += `<div class="success">✓ Valid JSON</div>`;
                        results += `<pre>${JSON.stringify(data, null, 2)}</pre>`;
                    } catch (jsonError) {
                        results += `<div class="error">✗ JSON Error: ${jsonError.message}</div>`;
                        
                        // Find the problematic character
                        const match = jsonError.message.match(/position (\d+)/);
                        if (match) {
                            const pos = parseInt(match[1]);
                            results += `<div><strong>Problem at position ${pos}:</strong></div>`;
                            results += `<pre>${text.substring(Math.max(0, pos - 20), pos + 20)}</pre>`;
                            results += `<div>Character at position ${pos}: "${text.charAt(pos)}" (ASCII: ${text.charCodeAt(pos)})</div>`;
                        }
                    }
                    
                    results += '<hr>';
                    
                } catch (error) {
                    results += `<h3>${endpoint}</h3>`;
                    results += `<div class="error">Fetch Error: ${error.message}</div>`;
                    results += '<hr>';
                }
            }
            
            resultsDiv.innerHTML = results;
        }
        
        // Auto run test on load
        document.addEventListener('DOMContentLoaded', () => {
            testRawAPI();
        });
    </script>
</body>
</html>
